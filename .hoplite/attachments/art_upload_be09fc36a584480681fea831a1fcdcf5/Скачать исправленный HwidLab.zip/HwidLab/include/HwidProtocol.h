/*
 * HwidLab shared protocol - included by the kernel driver and the usermode loader.
 *
 * Contract kept for both sides:
 *  - fixed-width integer types only (UINT16 / UINT32 / UCHAR / CHAR)
 *  - all IOCTL transfers are METHOD_BUFFERED with fixed-size, self-contained
 *    structures: fixed char arrays, no pointers, no dynamic kernel memory
 *  - function codes 0x800-0xFFF are the reserved third-party IOCTL range
 *
 * Local lab use only.
 */
#pragma once

#ifdef _KERNEL_MODE
#include <ntddk.h>
#else
#include <windows.h>
#include <winioctl.h>
#endif

/* Fallbacks so the header also parses when the SDK/WDK macros are absent. */
#ifndef METHOD_BUFFERED
#define METHOD_BUFFERED 0
#endif
#ifndef FILE_ANY_ACCESS
#define FILE_ANY_ACCESS 0
#endif
#ifndef FILE_DEVICE_UNKNOWN
#define FILE_DEVICE_UNKNOWN 0x00000022
#endif
#ifndef CTL_CODE
#define CTL_CODE(DeviceType, Function, Method, Access) \
    (((DeviceType) << 16) | ((Access) << 14) | ((Function) << 2) | (Method))
#endif

#define HWID_DEVICE_TYPE FILE_DEVICE_UNKNOWN

#define HWID_IOCTL_SET_CONFIG 0x800
#define HWID_IOCTL_GET_CONFIG 0x801
#define HWID_IOCTL_RESTORE 0x802

#define IOCTL_HWID_SET_CONFIG \
    CTL_CODE(HWID_DEVICE_TYPE, HWID_IOCTL_SET_CONFIG, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_HWID_GET_CONFIG \
    CTL_CODE(HWID_DEVICE_TYPE, HWID_IOCTL_GET_CONFIG, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define IOCTL_HWID_RESTORE \
    CTL_CODE(HWID_DEVICE_TYPE, HWID_IOCTL_RESTORE, METHOD_BUFFERED, FILE_ANY_ACCESS)

/* Spoof flags (HwidConfig.Flags) - one bit per driver-side spoof.
 * MachineGuid and HardwareProfileId are usermode-only and have no flag bit. */
#define HWID_SPOOF_NONE 0x00000000UL
#define HWID_SPOOF_DISK 0x00000001UL
#define HWID_SPOOF_SMBIOS 0x00000002UL
#define HWID_SPOOF_MAC 0x00000004UL
#define HWID_SPOOF_VOLUME 0x00000008UL
#define HWID_SPOOF_ALL_DRIVER \
    (HWID_SPOOF_DISK | HWID_SPOOF_SMBIOS | HWID_SPOOF_MAC | HWID_SPOOF_VOLUME)

#define HWID_CONFIG_MAGIC 0x48574944UL /* "Hwid" */
#define HWID_CONFIG_VERSION 0x0002

/* Device and service names shared by driver and loader. */
#define HWID_SERVICE_NAME L"HwidLab"
#define HWID_SERVICE_DISPLAY L"HwidLab HWID Driver"
#define HWID_DEVICE_DOS_NAME L"\\\\.\\HwidLab"     /* usermode CreateFileW */
#define HWID_DEVICE_NT_NAME L"\\Device\\HwidLab"   /* driver IoCreateDevice */
#define HWID_DOS_DEVICE_NAME L"\\DosDevices\\HwidLab" /* driver symlink */

#pragma pack(push, 1)

/* All char fields are NUL-terminated ASCII fixed arrays; the kernel side must
 * treat them as bounded and never assume termination. Reserved must be zero. */
typedef struct {
    UINT32 Magic;      /* HWID_CONFIG_MAGIC */
    UINT16 Version;    /* HWID_CONFIG_VERSION */
    UINT16 StructSize; /* sizeof(HwidConfig) */
    UINT32 Flags;      /* HWID_SPOOF_* bits */
    CHAR SmBiosManufacturer[64];
    CHAR SmBiosSerial[64];
    UCHAR SmBiosUuid[16];  /* manufacturer-formatted UUID v4 layout */
    CHAR BiosSerial[64];
    UCHAR MacAddress[6];   /* locally administered unicast */
    CHAR DiskSerial[32];   /* ATA serial is 20 chars; slack included */
    CHAR VolumeId[16];     /* "XXXX-XXXX" volume serial */
    UINT32 Reserved[6];    /* must be zero */
    WCHAR DeviceName[128]; /* optional disk/volume DOS device selection */
} HwidConfig, *PHwidConfig;

/* IOCTL_HWID_RESTORE asks the driver to reapply the original values it
 * captured before the first SET_CONFIG of this boot. */
typedef struct {
    UINT32 Magic;      /* HWID_CONFIG_MAGIC */
    UINT16 Version;    /* HWID_CONFIG_VERSION */
    UINT16 StructSize; /* sizeof(HwidRestoreRequest) */
    UINT32 Reserved[4];
} HwidRestoreRequest, *PHwidRestoreRequest;

#pragma pack(pop)

#ifdef __cplusplus
static_assert(sizeof(HwidConfig) == 554, "unexpected HwidConfig size");
static_assert(sizeof(HwidRestoreRequest) == 24, "unexpected HwidRestoreRequest size");
#endif
