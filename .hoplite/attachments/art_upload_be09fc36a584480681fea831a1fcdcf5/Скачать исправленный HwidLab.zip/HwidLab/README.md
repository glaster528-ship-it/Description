# HwidLab

## 4.0 — Physical PC edition

Основная цель релиза — реальный Windows 10/11 x64 ПК. Добавлены hardware preflight, NVMe/SATA inventory, выбор физического диска и NIC, NVMe Identify Controller interception, PnP-уведомления для disk/volume интерфейсов, ABI v2, verify и сессионный rollback.

`ALL` больше не меняет MAC/GUID всех сетевых карт: сетевые операции выполняются только для выбранного адаптера. `storage-select <n>` выбирает PhysicalDrive, `storage-select ALL` возвращает режим всех дисков, `storage-list` показывает модель, bus type и serial.

ABI v1 несовместим с 4.0. Обновляйте `HwidCore.sys`, `HwidNdis.sys`, loader и GUI одним комплектом. SMBIOS kernel hook отключён; VBS/HVCI и Secure Boot отображаются preflight. Физический TPM не подменяется.

Готовые x64 драйверы `HwidCore.sys` и `HwidNdis.sys` находятся в `Bin`. Инструкция по их тестовой подписи и установке: [DRIVERS.md](DRIVERS.md).

## GUI quick start

Open `Bin/HwidLabGUI.exe` as administrator. The resizable, per-monitor DPI-aware Control Center provides a custom dark theme, sidebar navigation, animated hover/press states and page transitions, selectable identity modules, exact command preview, named selection profiles, apply/restore, driver service controls, operation history, and a copyable/exportable activity log. Animations follow the Windows client-area animation preference. Keep `HwidLoader.exe` beside the GUI. Commands run on a worker thread and report back to the UI thread.

The persistent operation panel separates **Requested**, **Completed**, and **Verified**. A zero exit code for Apply/Restore does not set Verified: run **Diagnostics → Verify actual result**. Verified requires both a successful loader exit code and a `VERIFY END failures=0` report. Read-only inventory operations show verification as not required. Physical TPM remains unsupported; the vTPM button is explicitly limited to local Hyper-V VMs. Driver binaries still need to be built and test-signed with Visual Studio and the WDK. — Windows 10/11 x64

## UEFI SMBIOS editor

Каталог `firmware/` содержит явно запускаемое UEFI Shell-приложение. Оно вызывает стандартный `EFI_SMBIOS_PROTOCOL::UpdateString` для Type 0/1/2 и `gRT->ResetSystem(EfiResetCold)` только после отдельной команды с `CONFIRM`. Это не прошивка SPI: поддержка изменения и сохранение после перезагрузки зависят от производителя firmware. Некоторые системы предоставляют read-only SMBIOS и возвращают `EFI_UNSUPPORTED`.

Сборка из корня EDK II после `edksetup.sh`:

```sh
cp -r /path/to/HwidLab/firmware HwidFirmwarePkg
build -p HwidFirmwarePkg/HwidFirmware.dsc -a X64 -t GCC -b RELEASE
```

На Windows используйте `VS2022` вместо `GCC5` в среде, настроенной по документации EDK II. Скопируйте полученный `HwidFirmware.efi` и отредактированный `hwid-values.example.ini` как `FS0:\hwid-values.ini` на FAT32 USB. Загрузитесь один раз в UEFI Shell через Boot Menu:

```text
FS0:
HwidFirmware.efi list
HwidFirmware.efi apply hwid-values.ini CONFIRM
HwidFirmware.efi reboot CONFIRM
```

INI должен быть UTF-16 LE с BOM (в том числе PowerShell `Out-File -Encoding unicode`). Требуются ASCII-ключи `bios=`, `system=`, `board=`; длина каждого значения не более 64 символов и ограничена firmware. Приложение не изменяет binary UUID Type 1, не прописывает boot entry и не запускается автоматически. Выполняйте только на собственной тестовой машине с возможностью восстановления BIOS.

Учебный лабораторный проект для собственной тестовой VM. Состоит из WDM upper filter (`HwidCore.sys`), отдельного NDIS 6 lightweight filter (`HwidNdis.sys`) и консольного загрузчика (`HwidLoader.exe`). Исходники разделены на Ring 0 и Ring 3; общий фиксированный ABI находится в `include/HwidProtocol.h`.

## Архитектура

- `kernel/HwidCore.cpp` создает `\Device\HwidLab` и символическую ссылку `\\.\HwidLab` с доступом только SYSTEM/Administrators. Обрабатывает `IRP_MJ_DEVICE_CONTROL`, `IOCTL_HWID_SET_CONFIG`, `GET_CONFIG` и `RESTORE`. Для конфигурации применяются `ERESOURCE` и queued spin lock.
- Disk filter присоединяется к существующим `\Device\HarddiskN\DR0`. Completion routine для `IOCTL_STORAGE_QUERY_PROPERTY / StorageDeviceProperty` без изменения размера ответа заменяет строку в `STORAGE_DEVICE_DESCRIPTOR::SerialNumberOffset`. `IO_REMOVE_LOCK` защищает выгрузку от активных IRP.
- Volume filter присоединяется к `\Device\HarddiskVolumeN`. Подмена Volume ID выполняется для `IRP_MJ_QUERY_VOLUME_INFORMATION / FileFsVolumeInformation` и `FSCTL_GET_NTFS_VOLUME_DATA`. `IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS` серийный номер тома **не возвращает**, поэтому не используется.
- `kernel/HwidNdis.cpp` регистрирует NDIS lightweight filter и отвечает на `OID_802_3_CURRENT_ADDRESS` и `OID_802_3_PERMANENT_ADDRESS`. Остальные OID клонируются через `NdisAllocateCloneOidRequest` и передаются ниже; send/receive callbacks транслируются без изменений.
- `kernel/SmbiosHook.cpp` содержит опциональный x64 hook экспортируемой `NtQuerySystemInformation`, класс `SystemFirmwareTableInformation` (76), провайдер `RSMB`. Обрабатывает Type 0 BIOS serial, Type 1 system serial/UUID и Type 2/3 serial, исправляет checksum formatted area. По умолчанию `HWID_ENABLE_SMBIOS_HOOK=0`: в обычной сборке устанавливаются только no-op stubs.
- `usermode/` управляет SCM-сервисом, отправляет конфигурацию через `DeviceIoControl`, генерирует UUID v4, ATA disk serial, Volume ID и MAC с OUI `00:15:5D`. Ошибки Win32 выводятся в `std::cerr`, ошибки драйвера — через `DbgPrint`.

MachineGuid изменяется в `HKLM\SOFTWARE\Microsoft\Cryptography\MachineGuid`. Hardware Profile GUID изменяется в `HKLM\SYSTEM\CurrentControlSet\Hardware Profiles\Current\HwProfileGuid`; `IDConfigDB\CurrentConfig` является DWORD-селектором профиля, а не GUID, поэтому не перезаписывается случайным GUID. Оригинальные строки сохраняются в `HKLM\SOFTWARE\HwidLab\Backups` перед первым изменением.

## Сборка

Нужны Visual Studio 2022 с **Desktop development with C++**, Windows 11 SDK и подходящий **WDK**. Проекты используют `WindowsKernelModeDriver10.0`, Release/x64.

Основные заголовки уже включены: `ntddk.h`, `wdmsec.h`, `ntddstor.h`, `ntddvol.h`, `ndis.h`; `ntddk.h` включает базовые определения WDM. Usermode собирается C++17 и линкуется с `advapi32`.

В Visual Studio откройте `kernel/HwidCore.vcxproj` и `kernel/HwidNdis.vcxproj`, выберите Release/x64 и Build. Либо из **Developer Command Prompt**:

```bat
cd HwidLab
build.cmd
```

Отдельно loader:

```bat
cmake -S usermode -B build\usermode -A x64
cmake --build build\usermode --config Release
```

## Тестовая подпись и запуск

Выполняйте на тестовой VM, предварительно создав snapshot. `test-sign.cmd` использует запрошенные `makecert`, `pvk2pfx`, `signtool`:

```bat
test-sign.cmd kernel\x64\Release\HwidCore.sys kernel\x64\Release\HwidNdis.sys
certmgr.msc
```

Импортируйте `HwidLabTest.cer` в **Trusted Root Certification Authorities** и **Trusted Publishers** локального компьютера, затем от администратора:

```bat
bcdedit /set testsigning on
shutdown /r /t 0
```

`makecert` устарел; для новой цепочки можно использовать `New-SelfSignedCertificate -Type CodeSigningCert`, экспортировать PFX и вызвать `signtool sign /fd SHA256 /f cert.pfx driver.sys`. Для production потребуется подпись через Microsoft Hardware Dev Center; тестовый режим не отключает HVCI и не делает kernel-text hook совместимым с PatchGuard.

Запуск после перезагрузки:

```bat
HwidLoader.exe install C:\full\path\HwidCore.sys
HwidLoader.exe start
pnputil /add-driver C:\full\path\HwidNdis.inf /install
HwidLoader.exe spoof ALL
HwidLoader.exe show
```

Выбор цели: `ALL`, `DISK`, `SMBIOS`, `MAC`, `VOLUME`, `MACHINEGUID`, `HWPROFILE`, `NETMAC`, `NETGUID`. Пример: `HwidLoader.exe spoof DISK`. NDIS считывает MAC/flags при attach модуля: после `spoof MAC` отключите и включите адаптер или перезагрузите VM. Изменения реестра и кешированные WMI/SNMP данные также могут требовать перезагрузки.

`NETMAC` записывает случайный locally-administered unicast MAC в `NetworkAddress` в ключах физических NIC под `HKLM\SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}`. `NETGUID` меняет `NetCfgInstanceId`. Обе команды перезапускают NIC через Configuration Manager; соединение может кратковременно пропасть. Оригиналы сохраняются один раз по постоянному ключу `00xx` адаптера в `SOFTWARE\HwidLab\Backups` и восстанавливаются командой `restore`. `ALL` включает обе сетевые операции.

```bat
HwidLoader.exe spoof NETMAC
HwidLoader.exe spoof NETGUID
HwidLoader.exe clear-logs
HwidLoader.exe tpm "Exact powered-off VM name"
```

`clear-logs` очищает Application, Security, Setup и System через Windows Event Log API. Это отдельная команда с подтверждением в GUI; spoof/restore не вызывают её автоматически.

`tpm` вызывает `tools/Reset-HyperVTpm.ps1` на локальном Hyper-V host. VM должна быть выключена. Скрипт создает checkpoint, меняет local key protector и пересоздает vTPM, оставляя VM выключенной. Сохраните ключи восстановления BitLocker заранее. Это ротация поддерживаемого Hyper-V vTPM, а не подмена физического TPM.

```bat
HwidLoader.exe restore
HwidLoader.exe stop
HwidLoader.exe uninstall
bcdedit /deletevalue testsigning
```

`restore` восстанавливает сохраненные значения реестра и отключает driver-side подмену; драйвер не может восстановить значения, которые были только перехвачены, а не записаны на устройство.

## SMBIOS и ограничения

Для экспериментального SMBIOS hook измените в `HwidCore.vcxproj` `HWID_ENABLE_SMBIOS_HOOK=0` на `1`. Поддерживается только проверенный 12-byte prologue целевой версии `ntoskrnl`; при несовпадении инициализация возвращает ошибку. **PatchGuard может завершить систему с bugcheck 0x109; при HVCI/VBS hook возвращает `STATUS_ACCESS_DENIED`.** Поэтому базовая конфигурация не включает hook, а команда `SMBIOS` без этой сборки только передает конфигурацию и не меняет firmware table.

Фильтры присоединяются к устройствам, существующим на момент загрузки; динамически добавленные позже диски/тома не отслеживаются. Подмена ответов не меняет физическую прошивку, содержимое диска, SMBIOS ROM или постоянный MAC. Реализация не содержит BYOVD, обход DSE, PatchGuard или HVCI. Для загрузки неподписанного драйвера на x64 требуется валидная тестовая подпись и `testsigning on`; отключение Secure Boot может потребоваться политикой конкретной VM, но не реализуется проектом.
