# Driver binaries

Version 4.0 uses configuration ABI v2. Do not mix its loader with older drivers.

The `Bin` directory contains x64 kernel binaries built with the Microsoft 10.0.26100 WDK:

- `HwidCore.sys`: storage/volume filter and control device used by the GUI/loader.
- `HwidNdis.sys`: NDIS 6 lightweight filter for configured MAC query responses.
- `HwidCore.inf`: optional service installation descriptor. The GUI installs the core service directly with `HwidLoader.exe`.
- `HwidNdis.inf`: required NDIS network-component installation descriptor.
- `HwidCore.cat` / `HwidNdis.cat`: signed SHA-256 driver-package catalogs.

The binaries are Authenticode test-signed, not Microsoft production-signed. They were cross-compiled and statically inspected, but have not been boot-tested on Windows in this environment. Test only in a recoverable VM snapshot.

## Test VM installation

1. Run `Install-TestCertificate.cmd` as administrator to trust the included local test certificate, or import `HwidLab-Test.cer` into Local Computer / Trusted Root Certification Authorities and Trusted Publishers.
2. Enable test signing explicitly: `bcdedit /set testsigning on`, then reboot the VM.
3. Run `Install-Drivers.cmd` as administrator. It installs/starts `HwidCore.sys` and invokes `netcfg` for `HwidNdis.inf`.
4. Start `HwidLabGUI.exe` as administrator and use **Refresh real status**.

For the NDIS filter alone, run `netcfg -v -l "<full path>\HwidNdis.inf" -c s -i HwidNdis`. Uninstall it through Network Connections or `netcfg -v -u HwidNdis`. The core service can be removed with `HwidLoader.exe uninstall`.

The SMBIOS kernel-text hook remains disabled (`HWID_ENABLE_SMBIOS_HOOK=0`). Driver loading and the standard registry MAC override do not bypass driver signing, PatchGuard or HVCI. Network connectivity can briefly drop when the NDIS filter or a network adapter restarts.
