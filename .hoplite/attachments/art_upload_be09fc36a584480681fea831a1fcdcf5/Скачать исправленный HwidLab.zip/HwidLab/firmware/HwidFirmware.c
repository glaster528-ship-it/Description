#include <Uefi.h>
#include <Protocol/Smbios.h>
#include <Protocol/SimpleFileSystem.h>
#include <Protocol/ShellParameters.h>
#include <Guid/FileInfo.h>
#include <IndustryStandard/SmBios.h>
#include <Library/BaseLib.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/PrintLib.h>
#include <Library/UefiApplicationEntryPoint.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>

typedef struct {
  UINT8 Type;
  UINTN StringNumber;
  CONST CHAR16 *Name;
} FIELD_MAP;

STATIC CONST FIELD_MAP mFields[] = {
  { 0, 7, L"BIOS serial" },
  { 1, 4, L"system serial" },
  { 1, 5, L"system UUID string (not the binary UUID field)" },
  { 2, 4, L"board serial" }
};

STATIC VOID PrintUsage(VOID)
{
  Print(L"HwidFirmware - explicit UEFI SMBIOS string editor\n");
  Print(L"Usage:\n");
  Print(L"  HwidFirmware.efi list\n");
  Print(L"  HwidFirmware.efi apply <valueFile> CONFIRM\n");
  Print(L"  HwidFirmware.efi reboot CONFIRM\n");
  Print(L"Value file (FS0:\\hwid-values.ini) contains one UTF-16 line per setting:\n");
  Print(L"  bios=<serial>\n  system=<serial>\n  board=<serial>\n");
  Print(L"All three keys are required. Type 1 UUID bytes are not modified.\n");
}

STATIC CHAR16 *SkipSpace(CHAR16 *Text)
{
  while (*Text == L' ' || *Text == L'\t') {
    ++Text;
  }
  return Text;
}

STATIC VOID TrimEnd(CHAR16 *Text)
{
  UINTN Length = StrLen(Text);
  while (Length > 0 && (Text[Length - 1] == L'\r' || Text[Length - 1] == L'\n' ||
         Text[Length - 1] == L' ' || Text[Length - 1] == L'\t')) {
    Text[--Length] = L'\0';
  }
}

STATIC EFI_STATUS LoadValues(CONST CHAR16 *Path, CHAR16 *Bios, UINTN BiosSize,
  CHAR16 *System, UINTN SystemSize, CHAR16 *Board, UINTN BoardSize)
{
  EFI_FILE_PROTOCOL *Root = NULL;
  EFI_FILE_PROTOCOL *File = NULL;
  EFI_SIMPLE_FILE_SYSTEM_PROTOCOL *Fs = NULL;
  EFI_STATUS Status;
  UINTN Size = 0;
  VOID *Buffer = NULL;
  BOOLEAN HaveBios = FALSE;
  BOOLEAN HaveSystem = FALSE;
  BOOLEAN HaveBoard = FALSE;

  Bios[0] = System[0] = Board[0] = L'\0';
  Status = gBS->LocateProtocol(&gEfiSimpleFileSystemProtocolGuid, NULL, (VOID **)&Fs);
  if (EFI_ERROR(Status)) {
    return Status;
  }
  Status = Fs->OpenVolume(Fs, &Root);
  if (EFI_ERROR(Status)) {
    return Status;
  }
  Status = Root->Open(Root, &File, (CHAR16 *)Path, EFI_FILE_MODE_READ, 0);
  if (EFI_ERROR(Status)) {
    goto Done;
  }
  Status = File->GetInfo(File, &gEfiFileInfoGuid, &Size, NULL);
  if (Status != EFI_BUFFER_TOO_SMALL) {
    goto Done;
  }
  EFI_FILE_INFO *Info = AllocatePool(Size);
  if (Info == NULL) {
    Status = EFI_OUT_OF_RESOURCES;
    goto Done;
  }
  Status = File->GetInfo(File, &gEfiFileInfoGuid, &Size, Info);
  if (EFI_ERROR(Status)) {
    FreePool(Info);
    goto Done;
  }
  if (Info->FileSize == 0 || Info->FileSize > 4096 || (Info->FileSize & 1) != 0) {
    FreePool(Info);
    Status = EFI_INVALID_PARAMETER;
    goto Done;
  }
  Size = (UINTN)Info->FileSize;
  FreePool(Info);
  Buffer = AllocateZeroPool(Size + sizeof(CHAR16));
  if (Buffer == NULL) {
    Status = EFI_OUT_OF_RESOURCES;
    goto Done;
  }
  Status = File->Read(File, &Size, Buffer);
  if (EFI_ERROR(Status) || Size < 2) {
    goto Done;
  }
  CHAR16 *Text = (CHAR16 *)Buffer;
  if (Text[0] == 0xFEFF) {
    ++Text;
  }
  for (CHAR16 *Line = Text; *Line != L'\0';) {
    CHAR16 *Next = Line;
    while (*Next != L'\0' && *Next != L'\n') {
      ++Next;
    }
    if (*Next == L'\n') {
      *Next++ = L'\0';
    }
    TrimEnd(Line);
    CHAR16 *Key = SkipSpace(Line);
    CHAR16 *Equal = StrStr(Key, L"=");
    if (Equal != NULL) {
      *Equal = L'\0';
      CHAR16 *Value = SkipSpace(Equal + 1);
      UINTN ValueSize = (StrSize(Value) <= 128 ? StrSize(Value) : 0);
      if (ValueSize != 0 && StrCmp(Key, L"bios") == 0) {
        Status = StrCpyS(Bios, BiosSize / sizeof(CHAR16), Value);
        HaveBios = TRUE;
      } else if (ValueSize != 0 && StrCmp(Key, L"system") == 0) {
        Status = StrCpyS(System, SystemSize / sizeof(CHAR16), Value);
        HaveSystem = TRUE;
      } else if (ValueSize != 0 && StrCmp(Key, L"board") == 0) {
        Status = StrCpyS(Board, BoardSize / sizeof(CHAR16), Value);
        HaveBoard = TRUE;
      }
      if (EFI_ERROR(Status)) {
        goto Done;
      }
    }
    Line = Next;
  }
  Status = (HaveBios && HaveSystem && HaveBoard) ? EFI_SUCCESS : EFI_INVALID_PARAMETER;

Done:
  if (Buffer != NULL) {
    FreePool(Buffer);
  }
  if (File != NULL) {
    File->Close(File);
  }
  if (Root != NULL) {
    Root->Close(Root);
  }
  return Status;
}

STATIC EFI_STATUS UpdateRecords(EFI_SMBIOS_PROTOCOL *Smbios, CONST FIELD_MAP *Field,
  CONST CHAR16 *Value, BOOLEAN Apply)
{
  EFI_SMBIOS_HANDLE Handle = SMBIOS_HANDLE_PI_RESERVED;
  EFI_SMBIOS_TYPE Type = Field->Type;
  EFI_SMBIOS_TABLE_HEADER *Record = NULL;
  UINTN Matches = 0;
  EFI_STATUS LastStatus = EFI_SUCCESS;

  for (;;) {
    EFI_STATUS Status = Smbios->GetNext(Smbios, &Handle, &Type, &Record, NULL);
    if (Status == EFI_NOT_FOUND) {
      break;
    }
    if (EFI_ERROR(Status)) {
      return Status;
    }
    ++Matches;
    if (!Apply) {
      Print(L"Type %u handle 0x%04x: %s\n", Field->Type, Handle, Field->Name);
      continue;
    }
    UINTN Number = Field->StringNumber;
    EFI_SMBIOS_HANDLE CurrentHandle = Handle;
    UINTN Bytes = StrSize(Value);
    CHAR8 *Ascii = AllocateZeroPool(Bytes);
    if (Ascii == NULL) {
      return EFI_OUT_OF_RESOURCES;
    }
    Status = UnicodeStrToAsciiStrS(Value, Ascii, Bytes);
    if (!EFI_ERROR(Status)) {
      Status = Smbios->UpdateString(Smbios, &CurrentHandle, &Number, Ascii);
    }
    FreePool(Ascii);
    if (EFI_ERROR(Status)) {
      Print(L"Type %u handle 0x%04x: %r\n", Field->Type, Handle, Status);
      LastStatus = Status;
    } else {
      Print(L"Updated type %u handle 0x%04x: %s\n", Field->Type, Handle, Field->Name);
    }
  }
  if (Matches == 0) {
    return EFI_NOT_FOUND;
  }
  return LastStatus;
}

EFI_STATUS EFIAPI UefiMain(IN EFI_HANDLE ImageHandle, IN EFI_SYSTEM_TABLE *SystemTable)
{
  EFI_SHELL_PARAMETERS_PROTOCOL *ShellParameters = NULL;
  EFI_STATUS Status = gBS->OpenProtocol(ImageHandle, &gEfiShellParametersProtocolGuid,
    (VOID **)&ShellParameters, ImageHandle, NULL, EFI_OPEN_PROTOCOL_GET_PROTOCOL);
  if (EFI_ERROR(Status) || ShellParameters->Argc < 2) {
    PrintUsage();
    return EFI_INVALID_PARAMETER;
  }

  if (ShellParameters->Argc == 3 && StrCmp(ShellParameters->Argv[1], L"reboot") == 0 &&
      StrCmp(ShellParameters->Argv[2], L"CONFIRM") == 0) {
    Print(L"Resetting now. Changes made by a previous apply are not rolled back.\n");
    gBS->Stall(3000000);
    gRT->ResetSystem(EfiResetCold, EFI_SUCCESS, 0, NULL);
    return EFI_DEVICE_ERROR;
  }

  EFI_SMBIOS_PROTOCOL *Smbios = NULL;
  Status = gBS->LocateProtocol(&gEfiSmbiosProtocolGuid, NULL, (VOID **)&Smbios);
  if (EFI_ERROR(Status)) {
    Print(L"EFI_SMBIOS_PROTOCOL is unavailable: %r\n", Status);
    return Status;
  }
  Print(L"SMBIOS protocol %u.%u\n", Smbios->MajorVersion, Smbios->MinorVersion);

  if (ShellParameters->Argc == 2 && StrCmp(ShellParameters->Argv[1], L"list") == 0) {
    for (UINTN i = 0; i < ARRAY_SIZE(mFields); ++i) {
      if (i == 2) {
        continue;
      }
      UpdateRecords(Smbios, &mFields[i], NULL, FALSE);
    }
    return EFI_SUCCESS;
  }

  if (ShellParameters->Argc == 4 && StrCmp(ShellParameters->Argv[1], L"apply") == 0 &&
      StrCmp(ShellParameters->Argv[3], L"CONFIRM") == 0) {
    CHAR16 Bios[65];
    CHAR16 System[65];
    CHAR16 Board[65];
    Status = LoadValues(ShellParameters->Argv[2], Bios, sizeof(Bios), System,
      sizeof(System), Board, sizeof(Board));
    if (EFI_ERROR(Status)) {
      Print(L"Cannot read complete values file: %r\n", Status);
      return Status;
    }
    CONST CHAR16 *Values[] = { Bios, System, Board };
    CONST UINTN FieldIndexes[] = { 0, 1, 3 };
    EFI_STATUS LastStatus = EFI_SUCCESS;
    for (UINTN i = 0; i < ARRAY_SIZE(FieldIndexes); ++i) {
      Status = UpdateRecords(Smbios, &mFields[FieldIndexes[i]], Values[i], TRUE);
      if (EFI_ERROR(Status)) {
        LastStatus = Status;
      }
    }
    Print(L"No automatic reboot. Inspect output, then run: HwidFirmware.efi reboot CONFIRM\n");
    return LastStatus;
  }

  PrintUsage();
  return EFI_INVALID_PARAMETER;
}
