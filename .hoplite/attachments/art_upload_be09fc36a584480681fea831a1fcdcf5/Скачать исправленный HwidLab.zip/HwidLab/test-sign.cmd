@echo off
setlocal
set NAME=HwidLabTest
set CERT=%~dp0%NAME%.pfx
if "%~1"=="" (
  echo Usage: test-sign.cmd path\to\HwidCore.sys [path\to\HwidNdis.sys]
  exit /b 1
)
where makecert >nul 2>nul || (echo makecert was not found. Install the Windows SDK.& exit /b 1)
where pvk2pfx >nul 2>nul || (echo pvk2pfx was not found.& exit /b 1)
where signtool >nul 2>nul || (echo signtool was not found.& exit /b 1)
makecert -r -pe -ss PrivateCertStore -n "CN=HwidLab Test" -eku 1.3.6.1.5.5.7.3.3 -sv "%~dp0%NAME%.pvk" "%~dp0%NAME%.cer" || exit /b 1
pvk2pfx -pvk "%~dp0%NAME%.pvk" -spc "%~dp0%NAME%.cer" -pfx "%CERT%" || exit /b 1
signtool sign /v /fd SHA256 /f "%CERT%" "%~1" || exit /b 1
if not "%~2"=="" signtool sign /v /fd SHA256 /f "%CERT%" "%~2" || exit /b 1
echo Import %~dp0%NAME%.cer into Trusted Root and Trusted Publishers on the TEST VM.
echo Then run: bcdedit /set testsigning on
echo Reboot the TEST VM. Do not distribute the generated private keys.
