/*
 * HwidLab - SmbiosHook.h
 *
 * Raw SMBIOS spoof hook for the test-lab WDM driver. Hooks the ntoskrnl
 * export NtQuerySystemInformation with a 12-byte absolute indirect jump
 * (mov rax, imm64 / jmp rax) backed by an executable trampoline, and rewrites
 * SystemFirmwareTableInformation (class 76, provider 'RSMB') responses in
 * place: SMBIOS Type 1 UUID and Type 1/2/3 serial strings.
 *
 * INCOMPATIBLE WITH PATCHGUARD (KPP): patching ntoskrnl .text is detected by
 * kernel PatchGuard and bugchecks (0x109, CRITICAL_STRUCTURE_CORRUPTION).
 * This module implements no DSE and no PatchGuard bypass.
 *
 * INCOMPATIBLE WITH HVCI/VBS: kernel text cannot be mapped writable when
 * hypervisor-protected code integrity enforces W^X. SmbiosHookInitialize()
 * pre-checks the code-integrity options and fails cleanly with
 * STATUS_ACCESS_DENIED instead of patching.
 *
 * Unsafe by default: HWID_ENABLE_SMBIOS_HOOK defaults to 0, so the base
 * build compiles only no-op stubs and never installs the hook. The module
 * never touches CR0.WP: kernel text is made writable exclusively through a
 * private MDL mapping held only for one 16-byte compare-exchange.
 *
 * Integration:
 *   DriverEntry: status = SmbiosHookInitialize(); // non-success = not hooked
 *   Unload:      SmbiosHookShutdown();
 *   Config:      register a PFN_HWID_CONFIG_QUERY via SmbiosHookSetProvider(),
 *                or mutate g_SmbiosHookConfig and call
 *                SmbiosHookPublishConfig(NULL); re-publish after every change.
 */
#pragma once

#ifndef _KERNEL_MODE
#define _KERNEL_MODE 1
#endif

#include "../include/HwidProtocol.h"

#ifndef HWID_ENABLE_SMBIOS_HOOK
#define HWID_ENABLE_SMBIOS_HOOK 0
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* Optional dynamic config source. Runs at DISPATCH_LEVEL under this module's
 * config spin lock: it must read only nonpaged state and must not block. */
typedef NTSTATUS (*PFN_HWID_CONFIG_QUERY)(_Out_ HwidConfig* Config, _In_opt_ PVOID Context);

/* Extern shared config: alternative to the callback provider. Defined in
 * SmbiosHook.cpp. Mutate it and call SmbiosHookPublishConfig(NULL) to make
 * the new values visible to the hook. */
extern HwidConfig g_SmbiosHookConfig;

/* Installs the hook. Returns STATUS_SUCCESS when hooked (or when the module
 * is compiled out); any other status means nothing was patched. */
NTSTATUS SmbiosHookInitialize(VOID);

/* Restores the original bytes. The trampoline is deliberately left allocated
 * (in-flight callers may still execute it); see SmbiosHook.cpp. */
VOID SmbiosHookShutdown(VOID);

VOID SmbiosHookSetProvider(_In_opt_ PFN_HWID_CONFIG_QUERY Callback, _In_opt_ PVOID Context);

/* Publishes a config snapshot to the hook: explicit Config, else the
 * registered provider, else g_SmbiosHookConfig. Invalid configs are logged
 * and ignored (the previous snapshot stays active). */
VOID SmbiosHookPublishConfig(_In_opt_ const HwidConfig* Config);

#ifdef __cplusplus
}
#endif
