#include <ndis.h>
#include <ntddk.h>
#include "../include/HwidProtocol.h"

#define HWID_NDIS_TAG 'diwH'

struct FilterContext {
    NDIS_HANDLE Handle;
    ULONG Flags;
    UCHAR Mac[6];
};

static NDIS_HANDLE g_DriverHandle;
static VOID FilterOidRequestComplete(NDIS_HANDLE, PNDIS_OID_REQUEST, NDIS_STATUS);
extern "C" VOID HwidNdisUnload(PDRIVER_OBJECT);

static VOID ReadConfiguration(FilterContext* context)
{
    UNICODE_STRING path;
    OBJECT_ATTRIBUTES attributes;
    HANDLE key;
    NTSTATUS status;
    UCHAR result[sizeof(KEY_VALUE_PARTIAL_INFORMATION) + 16];
    ULONG returned;

    context->Flags = 0;
    RtlFillMemory(context->Mac, sizeof(context->Mac), 0);
    RtlInitUnicodeString(&path,
        L"\\Registry\\Machine\\SYSTEM\\CurrentControlSet\\Services\\HwidLab\\Parameters");
    InitializeObjectAttributes(&attributes, &path,
        OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE, nullptr, nullptr);
    status = ZwOpenKey(&key, KEY_QUERY_VALUE, &attributes);
    if (!NT_SUCCESS(status))
        return;

    UNICODE_STRING value;
    RtlInitUnicodeString(&value, L"MacAddress");
    status = ZwQueryValueKey(key, &value, KeyValuePartialInformation,
        result, sizeof(result), &returned);
    auto information = reinterpret_cast<PKEY_VALUE_PARTIAL_INFORMATION>(result);
    if (NT_SUCCESS(status) && information->Type == REG_BINARY &&
        information->DataLength == sizeof(context->Mac))
        RtlCopyMemory(context->Mac, information->Data, sizeof(context->Mac));

    RtlInitUnicodeString(&value, L"Flags");
    status = ZwQueryValueKey(key, &value, KeyValuePartialInformation,
        result, sizeof(result), &returned);
    if (NT_SUCCESS(status) && information->Type == REG_DWORD &&
        information->DataLength == sizeof(ULONG))
        RtlCopyMemory(&context->Flags, information->Data, sizeof(ULONG));
    ZwClose(key);
}

static NDIS_STATUS FilterAttach(NDIS_HANDLE NdisFilterHandle, NDIS_HANDLE,
    PNDIS_FILTER_ATTACH_PARAMETERS)
{
    auto context = static_cast<FilterContext*>(NdisAllocateMemoryWithTagPriority(
        NdisFilterHandle, sizeof(FilterContext), HWID_NDIS_TAG, NormalPoolPriority));
    if (!context)
        return NDIS_STATUS_RESOURCES;
    RtlZeroMemory(context, sizeof(*context));
    context->Handle = NdisFilterHandle;
    ReadConfiguration(context);

    NDIS_FILTER_ATTRIBUTES attributes;
    NdisZeroMemory(&attributes, sizeof(attributes));
    attributes.Header.Revision = NDIS_FILTER_ATTRIBUTES_REVISION_1;
    attributes.Header.Size = sizeof(attributes);
    attributes.Header.Type = NDIS_OBJECT_TYPE_FILTER_ATTRIBUTES;
    attributes.Flags = 0;
    NDIS_STATUS status = NdisFSetAttributes(NdisFilterHandle, context, &attributes);
    if (status != NDIS_STATUS_SUCCESS) {
        NdisFreeMemory(context, sizeof(*context), 0);
        return status;
    }
    return NDIS_STATUS_SUCCESS;
}

static VOID FilterDetach(NDIS_HANDLE FilterModuleContext)
{
    auto context = static_cast<FilterContext*>(FilterModuleContext);
    NdisFreeMemory(context, sizeof(*context), 0);
}

static NDIS_STATUS FilterPause(NDIS_HANDLE, PNDIS_FILTER_PAUSE_PARAMETERS)
{
    return NDIS_STATUS_SUCCESS;
}

static NDIS_STATUS FilterRestart(NDIS_HANDLE, PNDIS_FILTER_RESTART_PARAMETERS)
{
    return NDIS_STATUS_SUCCESS;
}

static NDIS_STATUS FilterSetOptions(NDIS_HANDLE, NDIS_HANDLE)
{
    return NDIS_STATUS_SUCCESS;
}

static NDIS_STATUS AnswerMac(PNDIS_OID_REQUEST request, const FilterContext* context)
{
    auto& query = request->DATA.QUERY_INFORMATION;
    query.BytesNeeded = 6;
    if (query.InformationBufferLength < 6) {
        query.BytesWritten = 0;
        return NDIS_STATUS_BUFFER_TOO_SHORT;
    }
    if (!query.InformationBuffer)
        return NDIS_STATUS_INVALID_PARAMETER;
    NdisMoveMemory(query.InformationBuffer, context->Mac, 6);
    query.BytesWritten = 6;
    return NDIS_STATUS_SUCCESS;
}

static NDIS_STATUS FilterOidRequest(NDIS_HANDLE FilterModuleContext,
    PNDIS_OID_REQUEST request)
{
    auto context = static_cast<FilterContext*>(FilterModuleContext);
    ULONG oid = request->DATA.QUERY_INFORMATION.Oid;
    if ((context->Flags & HWID_SPOOF_MAC) &&
        (request->RequestType == NdisRequestQueryInformation ||
         request->RequestType == NdisRequestQueryStatistics) &&
        (oid == OID_802_3_CURRENT_ADDRESS || oid == OID_802_3_PERMANENT_ADDRESS))
        return AnswerMac(request, context);

    PNDIS_OID_REQUEST clone;
    NDIS_STATUS status = NdisAllocateCloneOidRequest(context->Handle, request,
        HWID_NDIS_TAG, &clone);
    if (status != NDIS_STATUS_SUCCESS) {
        switch (request->RequestType) {
        case NdisRequestSetInformation:
            request->DATA.SET_INFORMATION.BytesRead = 0;
            request->DATA.SET_INFORMATION.BytesNeeded = 0;
            break;
        case NdisRequestMethod:
            request->DATA.METHOD_INFORMATION.BytesRead = 0;
            request->DATA.METHOD_INFORMATION.BytesWritten = 0;
            request->DATA.METHOD_INFORMATION.BytesNeeded = 0;
            break;
        default:
            request->DATA.QUERY_INFORMATION.BytesWritten = 0;
            request->DATA.QUERY_INFORMATION.BytesNeeded = 0;
            break;
        }
        return status;
    }
    *reinterpret_cast<PVOID*>(clone->SourceReserved) = request;
    clone->RequestId = request->RequestId;
    status = NdisFOidRequest(context->Handle, clone);
    if (status == NDIS_STATUS_PENDING)
        return status;

    FilterOidRequestComplete(FilterModuleContext, clone, status);
    return NDIS_STATUS_PENDING;
}

static VOID FilterOidRequestComplete(NDIS_HANDLE FilterModuleContext,
    PNDIS_OID_REQUEST clone, NDIS_STATUS status)
{
    auto context = static_cast<FilterContext*>(FilterModuleContext);
    PNDIS_OID_REQUEST original = *reinterpret_cast<PNDIS_OID_REQUEST*>(clone->SourceReserved);
    switch (clone->RequestType) {
    case NdisRequestMethod:
        original->DATA.METHOD_INFORMATION.OutputBufferLength =
            clone->DATA.METHOD_INFORMATION.OutputBufferLength;
        original->DATA.METHOD_INFORMATION.BytesRead = clone->DATA.METHOD_INFORMATION.BytesRead;
        original->DATA.METHOD_INFORMATION.BytesNeeded = clone->DATA.METHOD_INFORMATION.BytesNeeded;
        original->DATA.METHOD_INFORMATION.BytesWritten = clone->DATA.METHOD_INFORMATION.BytesWritten;
        break;
    case NdisRequestSetInformation:
        original->DATA.SET_INFORMATION.BytesRead = clone->DATA.SET_INFORMATION.BytesRead;
        original->DATA.SET_INFORMATION.BytesNeeded = clone->DATA.SET_INFORMATION.BytesNeeded;
        break;
    default:
        original->DATA.QUERY_INFORMATION.BytesWritten = clone->DATA.QUERY_INFORMATION.BytesWritten;
        original->DATA.QUERY_INFORMATION.BytesNeeded = clone->DATA.QUERY_INFORMATION.BytesNeeded;
        break;
    }
    NdisFreeCloneOidRequest(context->Handle, clone);
    NdisFOidRequestComplete(context->Handle, original, status);
}

static VOID FilterSend(NDIS_HANDLE FilterModuleContext, PNET_BUFFER_LIST lists,
    NDIS_PORT_NUMBER port, ULONG flags)
{
    auto context = static_cast<FilterContext*>(FilterModuleContext);
    NdisFSendNetBufferLists(context->Handle, lists, port, flags);
}

static VOID FilterSendComplete(NDIS_HANDLE FilterModuleContext,
    PNET_BUFFER_LIST lists, ULONG flags)
{
    auto context = static_cast<FilterContext*>(FilterModuleContext);
    NdisFSendNetBufferListsComplete(context->Handle, lists, flags);
}

static VOID FilterReceive(NDIS_HANDLE FilterModuleContext, PNET_BUFFER_LIST lists,
    NDIS_PORT_NUMBER port, ULONG count, ULONG flags)
{
    auto context = static_cast<FilterContext*>(FilterModuleContext);
    NdisFIndicateReceiveNetBufferLists(context->Handle, lists, port, count, flags);
}

static VOID FilterReturn(NDIS_HANDLE FilterModuleContext, PNET_BUFFER_LIST lists,
    ULONG flags)
{
    auto context = static_cast<FilterContext*>(FilterModuleContext);
    NdisFReturnNetBufferLists(context->Handle, lists, flags);
}

extern "C" NTSTATUS DriverEntry(PDRIVER_OBJECT driver, PUNICODE_STRING registryPath)
{
    NDIS_FILTER_DRIVER_CHARACTERISTICS characteristics;
    NdisZeroMemory(&characteristics, sizeof(characteristics));
    characteristics.Header.Type = NDIS_OBJECT_TYPE_DEFAULT;
    characteristics.Header.Revision = NDIS_FILTER_CHARACTERISTICS_REVISION_1;
    characteristics.Header.Size = sizeof(characteristics);
    characteristics.MajorNdisVersion = 6;
    characteristics.MinorNdisVersion = 0;
    characteristics.FriendlyName = RTL_CONSTANT_STRING(L"HwidLab NDIS Filter");
    characteristics.UniqueName = RTL_CONSTANT_STRING(L"{7a6cb2ea-72f3-43b9-864b-c9f7da3e16b1}");
    characteristics.ServiceName = RTL_CONSTANT_STRING(L"HwidNdis");
    characteristics.SetOptionsHandler = FilterSetOptions;
    characteristics.AttachHandler = FilterAttach;
    characteristics.DetachHandler = FilterDetach;
    characteristics.PauseHandler = FilterPause;
    characteristics.RestartHandler = FilterRestart;
    characteristics.OidRequestHandler = FilterOidRequest;
    characteristics.OidRequestCompleteHandler = FilterOidRequestComplete;
    characteristics.SendNetBufferListsHandler = FilterSend;
    characteristics.SendNetBufferListsCompleteHandler = FilterSendComplete;
    characteristics.ReceiveNetBufferListsHandler = FilterReceive;
    characteristics.ReturnNetBufferListsHandler = FilterReturn;
    NDIS_STATUS status = NdisFRegisterFilterDriver(driver, registryPath,
        &characteristics, &g_DriverHandle);
    if (status != NDIS_STATUS_SUCCESS)
        DbgPrint("HwidNdis: registration failed 0x%08X\n", status);
    if (status == NDIS_STATUS_SUCCESS)
        driver->DriverUnload = HwidNdisUnload;
    return status;
}

extern "C" VOID HwidNdisUnload(PDRIVER_OBJECT)
{
    if (g_DriverHandle) {
        NdisFDeregisterFilterDriver(g_DriverHandle);
        g_DriverHandle = nullptr;
    }
}
