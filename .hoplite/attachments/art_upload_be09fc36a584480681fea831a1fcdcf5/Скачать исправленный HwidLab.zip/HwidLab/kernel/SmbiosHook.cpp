/*
 * HwidLab - SmbiosHook.cpp
 *
 * See SmbiosHook.h for scope, integration and hazards (PatchGuard/HVCI
 * incompatible; disabled unless HWID_ENABLE_SMBIOS_HOOK=1; no CR0.WP games;
 * no DSE/PatchGuard bypass).
 *
 * Keep this file out of paged sections: the hook handler and the trampoline
 * it calls run in the middle of system service dispatch, and the patch runs
 * against nonpaged kernel text.
 */

#include "SmbiosHook.h"

#if !defined(_M_X64)
#error "SmbiosHook is x64-only (12-byte absolute indirect jump)."
#endif

#if defined(__has_include)
#if __has_include(<intrin.h>)
#include <intrin.h>
#endif
#else
#include <intrin.h>
#endif
#include <stdarg.h>

HwidConfig g_SmbiosHookConfig = { 0 };

#if HWID_ENABLE_SMBIOS_HOOK

/* ------------------------------------------------------------------ */
/* Constants and kernel structures not exposed by ntddk.h              */
/* ------------------------------------------------------------------ */

#define SMBH_POOL_TAG 0x68626D53u /* 'Smbh' */

#define SMBH_CLASS_FIRMWARE_TABLE 76u   /* SystemFirmwareTableInformation */
#define SMBH_CLASS_CODE_INTEGRITY 103u  /* SystemCodeIntegrityInformation */

/* 0x4000 = HVCI (kernel-mode code integrity) enabled; option bit is not in
 * the public headers but is stable across Windows 10/11 builds. */
#define SMBH_CI_OPTION_HVCI_KMCI 0x4000UL

#define SMBH_RSMB ((ULONG)'R' | ((ULONG)'S' << 8) | ((ULONG)'M' << 16) | ((ULONG)'B' << 24))
#define SMBH_FW_ACTION_GET 1u

#define SMBH_PATCH_LENGTH 12u    /* mov rax, imm64 (2+8) + jmp rax (2)      */
#define SMBH_PROLOGUE_LENGTH 17u /* mov r10,rcx (4) + mov eax,ssn (5) + test moffs (8) */

typedef struct _SMBH_FIRMWARE_TABLE_INFORMATION {
    ULONG ProviderSignature;
    ULONG Action;
    ULONG Status;
    ULONG TableBufferLength;
    UCHAR TableBuffer[1];
} SMBH_FIRMWARE_TABLE_INFORMATION, *PSMBH_FIRMWARE_TABLE_INFORMATION;

typedef struct _SMBH_RAW_SMBIOS_DATA {
    UCHAR Used20Calling;
    UCHAR MajorVersion;
    UCHAR MinorVersion;
    UCHAR DmiRevision;
    ULONG Length;
    UCHAR TableData[1];
} SMBH_RAW_SMBIOS_DATA, *PSMBH_RAW_SMBIOS_DATA;

typedef struct _SMBH_CODEINTEGRITY_INFORMATION {
    ULONG Length;
    ULONG CodeIntegrityOptions;
} SMBH_CODEINTEGRITY_INFORMATION;

static_assert(FIELD_OFFSET(SMBH_FIRMWARE_TABLE_INFORMATION, TableBuffer) == 16,
              "unexpected firmware-table header layout");
static_assert(FIELD_OFFSET(SMBH_RAW_SMBIOS_DATA, TableData) == 8,
              "unexpected RAW_SMBIOS_DATA layout");

typedef NTSTATUS (NTAPI *SMBH_PT_QUERY_SYSTEM_INFORMATION)(ULONG SystemInformationClass,
                                                           PVOID SystemInformation,
                                                           ULONG SystemInformationLength,
                                                           PULONG ReturnLength);

/* ------------------------------------------------------------------ */
/* State                                                               */
/* ------------------------------------------------------------------ */

static FAST_MUTEX g_SmbhMutex;        /* serializes install/restore        */
static BOOLEAN g_SmbhActive = FALSE;  /* patched right now (under mutex)   */
static PVOID g_SmbhTarget = NULL;     /* ntoskrnl NtQuerySystemInformation */
static UCHAR g_SmbhOriginal[16];      /* original bytes 0..15              */
static UCHAR g_SmbhPatched[16];       /* exact 16 bytes currently patched  */
static PVOID g_SmbhTrampoline = NULL; /* executable copy of the prologue   */

static KSPIN_LOCK g_SmbhConfigLock;
static PFN_HWID_CONFIG_QUERY g_SmbhCallback = NULL;
static PVOID g_SmbhCallbackContext = NULL;

/* Immutable nonpaged snapshot the hook reads lock-free on every call.
 * Replaced by pointer on publish; the old snapshot is intentionally left
 * allocated because in-flight hook calls may still hold the pointer. */
static volatile PVOID g_SmbhSnapshot = NULL;

/* ------------------------------------------------------------------ */
/* Logging                                                             */
/* ------------------------------------------------------------------ */

static VOID SmbhLogV(PCSTR Format, va_list Args, ULONG Level)
{
    vDbgPrintExWithPrefix("[HwidLab][SmbiosHook] ", DPFLTR_IHVDRIVER_ID, Level, Format, Args);
}

static VOID __cdecl SmbhLog(PCSTR Format, ...)
{
    va_list args;
    va_start(args, Format);
    SmbhLogV(Format, args, DPFLTR_INFO_LEVEL);
    va_end(args);
}

static VOID __cdecl SmbhLogErr(PCSTR Format, ...)
{
    va_list args;
    va_start(args, Format);
    SmbhLogV(Format, args, DPFLTR_ERROR_LEVEL);
    va_end(args);
}

/* ------------------------------------------------------------------ */
/* Memory helpers                                                      */
/* ------------------------------------------------------------------ */

static PVOID SmbhAllocPool(SIZE_T Size, BOOLEAN Executable)
{
#if defined(POOL_FLAG_NON_PAGED_EXECUTABLE)
    POOL_FLAGS flags = Executable ? POOL_FLAG_NON_PAGED_EXECUTABLE : POOL_FLAG_NON_PAGED;
    return ExAllocatePool2(flags, Size, SMBH_POOL_TAG);
#else
    /* Older WDK: explicit executable type keeps the trampoline valid on
     * builds where nonpaged pool is non-executable by default. */
    POOL_TYPE type = Executable ? NonPagedPoolExecute : NonPagedPool;
    return ExAllocatePoolWithTag(type, Size, SMBH_POOL_TAG);
#endif
}

/* Maps kernel text writable through a private MDL alias. Never touches
 * CR0.WP, so nothing here disables write protection globally or leaks it
 * across calls. With HVCI the alias cannot get write access and this fails
 * with STATUS_ACCESS_DENIED. */
static NTSTATUS SmbhMapWritable(_In_ PVOID Target, _In_ ULONG Length,
                                _Out_ PMDL* OutMdl, _Out_ PVOID* OutWritable)
{
    PMDL mdl = IoAllocateMdl(Target, Length, FALSE, FALSE, NULL);
    if (!mdl)
        return STATUS_INSUFFICIENT_RESOURCES;

    __try {
        MmBuildMdlForNonPagedPool(mdl);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        IoFreeMdl(mdl);
        return GetExceptionCode();
    }

    PVOID writable = MmMapLockedPagesSpecifyCache(mdl, KernelMode, MmReadWrite, NULL,
                                                  FALSE, NormalPagePriority);
    if (!writable) {
        IoFreeMdl(mdl);
        return STATUS_ACCESS_DENIED;
    }
    *OutMdl = mdl;
    *OutWritable = writable;
    return STATUS_SUCCESS;
}

static VOID SmbhUnmapWritable(_In_ PMDL Mdl, _In_ PVOID Writable)
{
    MmUnmapLockedPages(Writable, Mdl);
    IoFreeMdl(Mdl);
}

/* Refuses to patch when HVCI is on, instead of faulting on the write. */
static NTSTATUS SmbhCheckHvci(VOID)
{
    SMBH_CODEINTEGRITY_INFORMATION ci;
    ULONG returned = 0;

    ci.Length = sizeof(ci);
    ci.CodeIntegrityOptions = 0;

    NTSTATUS status = ZwQuerySystemInformation((SYSTEM_INFORMATION_CLASS)SMBH_CLASS_CODE_INTEGRITY,
                                               &ci, sizeof(ci), &returned);
    if (!NT_SUCCESS(status)) {
        SmbhLogErr("code-integrity query failed 0x%08X; refusing to patch\n", (ULONG)status);
        return STATUS_ACCESS_DENIED;
    }
    if (ci.CodeIntegrityOptions & SMBH_CI_OPTION_HVCI_KMCI) {
        SmbhLogErr("HVCI is enabled; kernel text cannot be patched\n");
        return STATUS_ACCESS_DENIED;
    }
    return STATUS_SUCCESS;
}

/* ------------------------------------------------------------------ */
/* Patch install / restore                                             */
/* ------------------------------------------------------------------ */

/* 12-byte absolute indirect jump patch; bytes 12..15 of the 16-byte compare
 * window stay original (they are dead once the entry jumps away). */
static VOID SmbhBuildPatch16(_Out_ UCHAR Bytes[16], _In_ ULONG_PTR HookAddress)
{
    Bytes[0] = 0x48; /* mov rax, imm64  */
    Bytes[1] = 0xB8;
    RtlCopyMemory(Bytes + 2, &HookAddress, sizeof(HookAddress));
    Bytes[10] = 0xFF; /* jmp rax        */
    Bytes[11] = 0xE0;
    RtlCopyMemory(Bytes + 12, g_SmbhOriginal + 12, 4);
}

static NTSTATUS SmbhWrite16(_In_ PUCHAR Target, _In_ const UCHAR Expected[16],
                            _In_ const UCHAR Replacement[16])
{
    PMDL mdl = NULL;
    PVOID writable = NULL;

    NTSTATUS status = SmbhMapWritable(Target, 16, &mdl, &writable);
    if (!NT_SUCCESS(status))
        return status;

    /* cmpxchg16b keeps the patch atomic: no other thread can observe half a
     * patch. Requires 16-byte alignment, checked by the caller. */
    alignas(16) __int64 comparand[2];
    alignas(16) __int64 exchange[2];
    RtlCopyMemory(comparand, Expected, 16);
    RtlCopyMemory(exchange, Replacement, 16);

    UCHAR ok = _InterlockedCompareExchange128((volatile __int64*)writable,
                                              exchange[1], exchange[0], comparand);
    SmbhUnmapWritable(mdl, writable);

    if (!ok) {
        SmbhLogErr("target bytes changed concurrently; patch aborted\n");
        return STATUS_INVALID_DEVICE_STATE;
    }
    return STATUS_SUCCESS;
}

/* ------------------------------------------------------------------ */
/* Hook handler and SMBIOS rewriting                                   */
/* ------------------------------------------------------------------ */

static VOID SmbhFixChecksum(_In_ PUCHAR Structure, _In_ ULONG FormattedLength)
{
    /* The structure checksum covers only the formatted area, not strings. */
    UCHAR sum = 0;
    Structure[4] = 0;
    for (ULONG i = 0; i < FormattedLength; ++i)
        sum = (UCHAR)(sum + Structure[i]);
    Structure[4] = (UCHAR)(0 - sum);
}

/* Replaces a Type 1/2/3 serial string in place. Only same-or-shorter values
 * are accepted: the string area layout, the structure length and the table
 * offsets all stay untouched. Short replacements are NUL-padded. */
static BOOLEAN SmbhPatchString(_In_ PUCHAR StrArea, _In_ ULONG AreaLen, _In_ UCHAR Index,
                               _In_reads_(64) const CHAR* Value)
{
    if (Index == 0 || AreaLen == 0 || Value[0] == '\0')
        return FALSE;

    ULONG valueLen = 0;
    while (valueLen < 64 && Value[valueLen] != '\0')
        ++valueLen;
    if (valueLen >= 64)
        return FALSE; /* config string is not NUL-terminated */

    PUCHAR p = StrArea;
    PUCHAR end = StrArea + AreaLen;
    UCHAR current = 1;

    while (p + 1 < end) {
        if (current == Index) {
            ULONG oldLen = 0;
            while (p + oldLen < end && p[oldLen] != 0)
                ++oldLen;
            if (valueLen > oldLen)
                return FALSE; /* longer than original: refused by policy */
            RtlCopyMemory(p, Value, valueLen);
            RtlZeroMemory(p + valueLen, oldLen - valueLen);
            return TRUE;
        }
        while (p < end && *p != 0)
            ++p; /* end of this string */
        if (p + 1 < end && p[0] == 0 && p[1] == 0)
            break; /* double-NUL: end of string area */
        ++p;
        ++current;
    }
    return FALSE; /* requested string index does not exist */
}

static BOOLEAN SmbhPatchUuid(_Inout_updates_(16) PUCHAR UuidField,
                             _In_reads_(16) const UCHAR NewUuid[16])
{
    static const UCHAR zero[16] = { 0 };
    if (RtlCompareMemory(NewUuid, zero, 16) == 16)
        return FALSE; /* all-zero config UUID means "leave unchanged" */
    RtlCopyMemory(UuidField, NewUuid, 16);
    return TRUE;
}

static VOID SmbhPatchTable(_In_ PUCHAR Table, _In_ ULONG TableLength,
                           _In_ const HwidConfig* Cfg)
{
    PUCHAR p = Table;
    PUCHAR end = Table + TableLength;

    while (p + 4 <= end && p[0] != 127 /* End-of-Table */) {
        ULONG hdrLen = p[1]; /* formatted area length */
        if (hdrLen < 5 || p + hdrLen > end)
            break; /* malformed; stop instead of wandering */

        PUCHAR strArea = p + hdrLen;
        PUCHAR q = strArea;
        while (q + 1 < end && !(q[0] == 0 && q[1] == 0))
            ++q;
        PUCHAR next = (q + 2 <= end) ? (q + 2) : end;
        ULONG total = (ULONG)(next - p);
        BOOLEAN modified = FALSE;

        /* Serial string index is 4 for System (Type 1), Base Board (Type 2)
         * and Chassis (Type 3). Type 1 UUID lives at formatted offset 04h. */
        switch (p[0]) {
        case 0:
            if (hdrLen >= 0x12)
                modified |= SmbhPatchString(strArea, (ULONG)(next - strArea), 7, Cfg->BiosSerial);
            break;
        case 1:
            if (hdrLen >= 0x14)
                modified |= SmbhPatchUuid(p + 4, Cfg->SmBiosUuid);
            modified |= SmbhPatchString(strArea, (ULONG)(next - strArea), 4, Cfg->SmBiosSerial);
            break;
        case 2:
            modified |= SmbhPatchString(strArea, (ULONG)(next - strArea), 4, Cfg->SmBiosSerial);
            break;
        case 3:
            modified |= SmbhPatchString(strArea, (ULONG)(next - strArea), 4, Cfg->SmBiosSerial);
            break;
        default:
            break;
        }

        if (modified)
            SmbhFixChecksum(p, hdrLen);
        p = next;
    }
}

static VOID SmbhApplyConfig(_In_ PUCHAR Buffer, _In_ ULONG BufferLength)
{
    /* Immutable snapshot: no locking on the hot path. */
    const HwidConfig* cfg = (const HwidConfig*)g_SmbhSnapshot;
    if (!cfg || !(cfg->Flags & HWID_SPOOF_SMBIOS))
        return;

    __try {
        if (BufferLength < FIELD_OFFSET(SMBH_FIRMWARE_TABLE_INFORMATION, TableBuffer))
            return;

        PSMBH_FIRMWARE_TABLE_INFORMATION sfti = (PSMBH_FIRMWARE_TABLE_INFORMATION)Buffer;
        if (sfti->ProviderSignature != SMBH_RSMB || sfti->Action != SMBH_FW_ACTION_GET ||
            sfti->Status != 0)
            return;

        ULONG avail = sfti->TableBufferLength;
        ULONG maxAvail = BufferLength - FIELD_OFFSET(SMBH_FIRMWARE_TABLE_INFORMATION, TableBuffer);
        if (avail > maxAvail)
            avail = maxAvail;
        if (avail < 8)
            return;

        PSMBH_RAW_SMBIOS_DATA raw = (PSMBH_RAW_SMBIOS_DATA)sfti->TableBuffer;
        ULONG tableLen = raw->Length;
        if (tableLen > avail - 8)
            tableLen = avail - 8;
        if (tableLen == 0)
            return;

        SmbhPatchTable(raw->TableData, tableLen, cfg);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        SmbhLogErr("exception 0x%08X while spoofing RSMB buffer\n", (ULONG)GetExceptionCode());
    }
}

/* Replacement entry point patched over nt!NtQuerySystemInformation. Runs on
 * the normal x64 calling convention; must stay nonpaged and CFG-free. */
static NTSTATUS SmbhHook(ULONG SystemInformationClass, PVOID SystemInformation,
                         ULONG SystemInformationLength, PULONG ReturnLength)
{
    SMBH_PT_QUERY_SYSTEM_INFORMATION original = (SMBH_PT_QUERY_SYSTEM_INFORMATION)g_SmbhTrampoline;
    if (!original)
        return STATUS_INVALID_DEVICE_STATE;

    NTSTATUS status = original(SystemInformationClass, SystemInformation,
                               SystemInformationLength, ReturnLength);
    if (NT_SUCCESS(status) && SystemInformationClass == SMBH_CLASS_FIRMWARE_TABLE &&
        SystemInformation != NULL) {
        SmbhApplyConfig((PUCHAR)SystemInformation, SystemInformationLength);
    }
    return status;
}

/* ------------------------------------------------------------------ */
/* Config plumbing                                                     */
/* ------------------------------------------------------------------ */

VOID SmbiosHookSetProvider(_In_opt_ PFN_HWID_CONFIG_QUERY Callback, _In_opt_ PVOID Context)
{
    KIRQL oldIrql;
    KeAcquireSpinLock(&g_SmbhConfigLock, &oldIrql);
    g_SmbhCallback = Callback;
    g_SmbhCallbackContext = Context;
    KeReleaseSpinLock(&g_SmbhConfigLock, oldIrql);
}

VOID SmbiosHookPublishConfig(_In_opt_ const HwidConfig* Config)
{
    HwidConfig local;
    NTSTATUS status;
    KIRQL oldIrql;

    KeAcquireSpinLock(&g_SmbhConfigLock, &oldIrql);
    if (g_SmbhCallback) {
        status = g_SmbhCallback(&local, g_SmbhCallbackContext);
    } else if (Config) {
        RtlCopyMemory(&local, Config, sizeof(local));
        status = STATUS_SUCCESS;
    } else {
        RtlCopyMemory(&local, &g_SmbiosHookConfig, sizeof(local));
        status = STATUS_SUCCESS;
    }
    KeReleaseSpinLock(&g_SmbhConfigLock, oldIrql);

    if (!NT_SUCCESS(status)) {
        SmbhLogErr("config provider failed 0x%08X; keeping previous snapshot\n", (ULONG)status);
        return;
    }
    if (local.Magic != HWID_CONFIG_MAGIC || local.Version != HWID_CONFIG_VERSION ||
        local.StructSize != sizeof(HwidConfig)) {
        SmbhLogErr("rejecting config with bad magic/version/size\n");
        return;
    }

    HwidConfig* snap = (HwidConfig*)SmbhAllocPool(sizeof(HwidConfig), FALSE);
    if (!snap) {
        SmbhLogErr("config snapshot allocation failed\n");
        return;
    }
    RtlCopyMemory(snap, &local, sizeof(*snap));
    InterlockedExchangePointer(&g_SmbhSnapshot, snap); /* old snapshot leaked by design */
    SmbhLog("config published: flags=0x%08X\n", snap->Flags);
}

/* ------------------------------------------------------------------ */
/* Init / shutdown                                                     */
/* ------------------------------------------------------------------ */

NTSTATUS SmbiosHookInitialize(VOID)
{
    if (g_SmbhActive) {
        SmbhLogErr("already active\n");
        return STATUS_INVALID_DEVICE_STATE;
    }

    ExInitializeFastMutex(&g_SmbhMutex);
    KeInitializeSpinLock(&g_SmbhConfigLock);

    NTSTATUS status = SmbhCheckHvci();
    if (!NT_SUCCESS(status))
        return status;

    UNICODE_STRING name;
    RtlInitUnicodeString(&name, L"NtQuerySystemInformation");
    PUCHAR target = (PUCHAR)MmGetSystemRoutineAddress(&name);
    if (!target) {
        SmbhLogErr("NtQuerySystemInformation not exported\n");
        return STATUS_NOT_FOUND;
    }

    /* Only the standard Windows 10/11 Nt prologue is supported:
     *   4C 8B D1            mov r10, rcx
     *   B8 xx xx xx xx      mov eax, <ssn>
     *   F6 04 25 08 03 FE 7F 01   test byte ptr [SharedUserData+0x308], 1
     * 17 bytes copy cleanly (no RIP-relative operands) and end on an
     * instruction boundary. Anything else is left untouched. */
    static const UCHAR probe[4] = { 0x4C, 0x8B, 0xD1, 0xB8 };
    if (RtlCompareMemory(target, probe, sizeof(probe)) != sizeof(probe) ||
        target[9] != 0xF6 || target[10] != 0x04 || target[11] != 0x25) {
        SmbhLogErr("unexpected NtQuerySystemInformation prologue; not hooking\n");
        return STATUS_NOT_SUPPORTED;
    }
    if ((((ULONG_PTR)target) & 0xF) != 0) {
        SmbhLogErr("target %p is not 16-byte aligned; not hooking\n", (PVOID)target);
        return STATUS_DATATYPE_MISALIGNMENT;
    }

    RtlCopyMemory(g_SmbhOriginal, target, sizeof(g_SmbhOriginal));
    g_SmbhTarget = target;

    g_SmbhTrampoline = SmbhAllocPool(SMBH_PROLOGUE_LENGTH + SMBH_PATCH_LENGTH, TRUE);
    if (!g_SmbhTrampoline) {
        SmbhLogErr("trampoline allocation failed\n");
        return STATUS_INSUFFICIENT_RESOURCES;
    }

    PUCHAR tr = (PUCHAR)g_SmbhTrampoline;
    RtlCopyMemory(tr, target, SMBH_PROLOGUE_LENGTH);
    ULONG_PTR resume = (ULONG_PTR)target + SMBH_PROLOGUE_LENGTH;
    tr[SMBH_PROLOGUE_LENGTH + 0] = 0x48; /* mov rax, resume   */
    tr[SMBH_PROLOGUE_LENGTH + 1] = 0xB8;
    RtlCopyMemory(tr + SMBH_PROLOGUE_LENGTH + 2, &resume, sizeof(resume));
    tr[SMBH_PROLOGUE_LENGTH + 10] = 0xFF; /* jmp rax          */
    tr[SMBH_PROLOGUE_LENGTH + 11] = 0xE0;

    SmbiosHookPublishConfig(NULL);

    SmbhBuildPatch16(g_SmbhPatched, (ULONG_PTR)&SmbhHook);
    status = SmbhWrite16(target, g_SmbhOriginal, g_SmbhPatched);
    if (!NT_SUCCESS(status)) {
        ExFreePoolWithTag(g_SmbhTrampoline, SMBH_POOL_TAG);
        g_SmbhTrampoline = NULL;
        g_SmbhTarget = NULL;
        SmbhLogErr("patch installation failed 0x%08X\n", (ULONG)status);
        return status;
    }

    g_SmbhActive = TRUE;
    SmbhLog("hook installed: target %p trampoline %p (12-byte absolute indirect jump)\n",
            (PVOID)target, g_SmbhTrampoline);
    return STATUS_SUCCESS;
}

VOID SmbiosHookShutdown(VOID)
{
    if (!g_SmbhActive)
        return;

    ExAcquireFastMutex(&g_SmbhMutex);
    if (g_SmbhActive) {
        NTSTATUS status = SmbhWrite16((PUCHAR)g_SmbhTarget, g_SmbhPatched, g_SmbhOriginal);
        if (NT_SUCCESS(status)) {
            SmbhLog("original bytes restored\n");
        } else {
            SmbhLogErr("restore failed 0x%08X; clean state requires a reboot\n", (ULONG)status);
        }
        g_SmbhActive = FALSE;
        /* Trampoline deliberately not freed: in-flight hook calls may still
         * execute it after the restore. 29 bytes of nonpaged pool per
         * unload is the price of not crashing a racing caller. */
    }
    ExReleaseFastMutex(&g_SmbhMutex);
}

#else /* !HWID_ENABLE_SMBIOS_HOOK: base build never installs the hook */

NTSTATUS SmbiosHookInitialize(VOID)
{
    DbgPrintEx(DPFLTR_IHVDRIVER_ID, DPFLTR_INFO_LEVEL,
               "[HwidLab][SmbiosHook] compiled out (HWID_ENABLE_SMBIOS_HOOK=0)\n");
    return STATUS_SUCCESS;
}

VOID SmbiosHookShutdown(VOID)
{
}

VOID SmbiosHookSetProvider(_In_opt_ PFN_HWID_CONFIG_QUERY Callback, _In_opt_ PVOID Context)
{
    UNREFERENCED_PARAMETER(Callback);
    UNREFERENCED_PARAMETER(Context);
}

VOID SmbiosHookPublishConfig(_In_opt_ const HwidConfig* Config)
{
    UNREFERENCED_PARAMETER(Config);
}

#endif /* HWID_ENABLE_SMBIOS_HOOK */
