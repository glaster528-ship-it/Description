#include <ntddk.h>
#include <ntddstor.h>
#include <ntdddisk.h>
#include <ntddvol.h>
#include <wdmsec.h>
#include <ntstrsafe.h>
#include <wdmguid.h>
#include "../include/HwidProtocol.h"

extern "C" {
const GUID GUID_DEVINTERFACE_DISK = {0x53f56307, 0xb6bf, 0x11d0, {0x94, 0xf2, 0x00, 0xa0, 0xc9, 0x1e, 0xfb, 0x8b}};
const GUID GUID_DEVINTERFACE_VOLUME = {0x53f5630d, 0xb6bf, 0x11d0, {0x94, 0xf2, 0x00, 0xa0, 0xc9, 0x1e, 0xfb, 0x8b}};
const GUID GUID_DEVICE_INTERFACE_ARRIVAL = {0xcb3a4004, 0x46f0, 0x11d0, {0xb0, 0x8f, 0x00, 0x60, 0x97, 0x13, 0x05, 0x3f}};
}

#if HWID_ENABLE_SMBIOS_HOOK
#include "SmbiosHook.h"
#endif

#define HWID_TAG 'diwH'
#define HWID_CONTROL_NAME L"\\Device\\HwidLab"
#define HWID_CONTROL_LINK L"\\DosDevices\\HwidLab"

#ifndef FSCTL_GET_NTFS_VOLUME_DATA
#define FSCTL_GET_NTFS_VOLUME_DATA CTL_CODE(FILE_DEVICE_FILE_SYSTEM, 25, METHOD_BUFFERED, FILE_ANY_ACCESS)
#endif

enum FilterKind { FilterDisk, FilterVolume };

struct FilterExtension {
    PDEVICE_OBJECT LowerDevice;
    FilterKind Kind;
    IO_REMOVE_LOCK RemoveLock;
    LIST_ENTRY Link;
    WCHAR DeviceName[64];
};

extern "C" NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath);
DRIVER_UNLOAD HwidUnload;
DRIVER_DISPATCH HwidPassThrough;
DRIVER_DISPATCH HwidPower;
DRIVER_DISPATCH HwidPnp;
DRIVER_DISPATCH HwidControl;
DRIVER_DISPATCH HwidStorage;
DRIVER_DISPATCH HwidVolume;
IO_COMPLETION_ROUTINE HwidStorageComplete;
IO_COMPLETION_ROUTINE HwidVolumeComplete;
static NTSTATUS AttachFilter(PDRIVER_OBJECT DriverObject, PCWSTR deviceName, FilterKind kind);

static PDEVICE_OBJECT g_ControlDevice;
static ERESOURCE g_ConfigResource;
static KSPIN_LOCK g_ConfigLock;
static HwidConfig g_Config;
static UNICODE_STRING g_RegistryPath;
static LONG g_FilterCount;
static LIST_ENTRY g_FilterList;
static FAST_MUTEX g_FilterListLock;
static LONG g_AttachWorkerRunning;
static WORK_QUEUE_ITEM g_AttachWorkItem;
static PVOID g_DiskNotification;
static PVOID g_VolumeNotification;

static VOID AttachExistingDevices(PDRIVER_OBJECT DriverObject);
static VOID QueueAttach(PDRIVER_OBJECT driver);

static NTSTATUS StorageInterfaceChanged(PVOID notification, PVOID context)
{
    auto change = static_cast<PDEVICE_INTERFACE_CHANGE_NOTIFICATION>(notification);
    auto driver = static_cast<PDRIVER_OBJECT>(context);
    if (!change || !change->SymbolicLinkName) return STATUS_SUCCESS;
    if (change->Event == GUID_DEVICE_INTERFACE_ARRIVAL)
        QueueAttach(driver);
    return STATUS_SUCCESS;
}

static VOID AttachWorkRoutine(PVOID context)
{
    auto driver = static_cast<PDRIVER_OBJECT>(context);
    AttachExistingDevices(driver);
    InterlockedExchange(&g_AttachWorkerRunning, 0);
    ObDereferenceObject(driver);
}

static VOID QueueAttach(PDRIVER_OBJECT driver)
{
    if (InterlockedCompareExchange(&g_AttachWorkerRunning, 1, 0) == 0) {
        ObReferenceObject(driver);
        ExInitializeWorkItem(&g_AttachWorkItem, AttachWorkRoutine, driver);
        ExQueueWorkItem(&g_AttachWorkItem, DelayedWorkQueue);
    }
}

static ULONG ParseVolumeSerial(const CHAR text[16])
{
    ULONG value = 0;
    for (ULONG i = 0; i < 16 && text[i]; ++i) {
        CHAR c = text[i];
        ULONG digit;
        if (c >= '0' && c <= '9') digit = c - '0';
        else if (c >= 'A' && c <= 'F') digit = c - 'A' + 10;
        else if (c >= 'a' && c <= 'f') digit = c - 'a' + 10;
        else continue;
        value = (value << 4) | digit;
    }
    return value;
}

static VOID LockConfigRead(PKLOCK_QUEUE_HANDLE Handle)
{
    KeAcquireInStackQueuedSpinLock(&g_ConfigLock, Handle);
}

static VOID UnlockConfigRead(PKLOCK_QUEUE_HANDLE Handle)
{
    KeReleaseInStackQueuedSpinLock(Handle);
}

static BOOLEAN DeviceSelected(const FilterExtension* extension)
{
    KLOCK_QUEUE_HANDLE lock;
    BOOLEAN selected = TRUE;
    LockConfigRead(&lock);
    if (g_Config.DeviceName[0])
        selected = _wcsicmp(g_Config.DeviceName, extension->DeviceName) == 0;
    UnlockConfigRead(&lock);
    return selected;
}

static BOOLEAN AlreadyAttached(PCWSTR name)
{
    BOOLEAN found = FALSE;
    ExAcquireFastMutex(&g_FilterListLock);
    for (PLIST_ENTRY entry = g_FilterList.Flink; entry != &g_FilterList; entry = entry->Flink) {
        auto extension = CONTAINING_RECORD(entry, FilterExtension, Link);
        if (_wcsicmp(extension->DeviceName, name) == 0) {
            found = TRUE;
            break;
        }
    }
    ExReleaseFastMutex(&g_FilterListLock);
    return found;
}

static NTSTATUS SaveMacConfiguration()
{
    UNICODE_STRING path;
    OBJECT_ATTRIBUTES attributes;
    HANDLE key = nullptr;
    NTSTATUS status;
    USHORT bytes;
    HwidConfig snapshot;
    KLOCK_QUEUE_HANDLE lock;

    if (!g_RegistryPath.Buffer)
        return STATUS_DEVICE_NOT_READY;

    bytes = g_RegistryPath.Length + sizeof(L"\\Parameters");
    path.Buffer = static_cast<PWSTR>(ExAllocatePoolWithTag(PagedPool, bytes, HWID_TAG));
    if (!path.Buffer)
        return STATUS_INSUFFICIENT_RESOURCES;
    path.Length = 0;
    path.MaximumLength = bytes;
    RtlCopyUnicodeString(&path, &g_RegistryPath);
    RtlAppendUnicodeToString(&path, L"\\Parameters");
    InitializeObjectAttributes(&attributes, &path,
        OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE, nullptr, nullptr);
    status = ZwCreateKey(&key, KEY_SET_VALUE, &attributes, 0, nullptr,
        REG_OPTION_NON_VOLATILE, nullptr);
    if (NT_SUCCESS(status)) {
        UNICODE_STRING value;
        LockConfigRead(&lock);
        RtlCopyMemory(&snapshot, &g_Config, sizeof(snapshot));
        UnlockConfigRead(&lock);
        RtlInitUnicodeString(&value, L"MacAddress");
        status = ZwSetValueKey(key, &value, 0, REG_BINARY,
            snapshot.MacAddress, sizeof(snapshot.MacAddress));
        if (NT_SUCCESS(status)) {
            RtlInitUnicodeString(&value, L"Flags");
            status = ZwSetValueKey(key, &value, 0, REG_DWORD,
                &snapshot.Flags, sizeof(snapshot.Flags));
        }
        ZwClose(key);
    }
    RtlFreeUnicodeString(&path);
    return status;
}

static BOOLEAN ValidConfig(const HwidConfig* config)
{
    return config->Magic == HWID_CONFIG_MAGIC &&
        config->Version == HWID_CONFIG_VERSION &&
        config->StructSize == sizeof(HwidConfig) &&
        (config->Flags & ~HWID_SPOOF_ALL_DRIVER) == 0 &&
        (config->MacAddress[0] & 1) == 0;
}

NTSTATUS HwidControl(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    if (DeviceObject != g_ControlDevice)
        return HwidPassThrough(DeviceObject, Irp);

    PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(Irp);
    ULONG code = stack->Parameters.DeviceIoControl.IoControlCode;
    NTSTATUS status = STATUS_INVALID_DEVICE_REQUEST;
    ULONG_PTR information = 0;

    if (stack->MajorFunction == IRP_MJ_CREATE || stack->MajorFunction == IRP_MJ_CLOSE) {
        status = STATUS_SUCCESS;
    } else if (stack->MajorFunction == IRP_MJ_DEVICE_CONTROL) {
        ULONG inLength = stack->Parameters.DeviceIoControl.InputBufferLength;
        ULONG outLength = stack->Parameters.DeviceIoControl.OutputBufferLength;
        if (code == IOCTL_HWID_SET_CONFIG) {
            if (inLength != sizeof(HwidConfig) || !Irp->AssociatedIrp.SystemBuffer) {
                status = STATUS_BUFFER_TOO_SMALL;
            } else {
                auto input = static_cast<HwidConfig*>(Irp->AssociatedIrp.SystemBuffer);
                if (!ValidConfig(input)) {
                    status = STATUS_INVALID_PARAMETER;
                } else {
                    KIRQL oldIrql;
                    KeEnterCriticalRegion();
                    ExAcquireResourceExclusiveLite(&g_ConfigResource, TRUE);
                    KeAcquireSpinLock(&g_ConfigLock, &oldIrql);
                    RtlCopyMemory(&g_Config, input, sizeof(g_Config));
                    g_Config.DiskSerial[sizeof(g_Config.DiskSerial) - 1] = 0;
                    g_Config.SmBiosSerial[sizeof(g_Config.SmBiosSerial) - 1] = 0;
                    g_Config.BiosSerial[sizeof(g_Config.BiosSerial) - 1] = 0;
                    g_Config.VolumeId[sizeof(g_Config.VolumeId) - 1] = 0;
                    g_Config.DeviceName[RTL_NUMBER_OF(g_Config.DeviceName) - 1] = 0;
                    KeReleaseSpinLock(&g_ConfigLock, oldIrql);
                    ExReleaseResourceLite(&g_ConfigResource);
                    KeLeaveCriticalRegion();
#if HWID_ENABLE_SMBIOS_HOOK
                    SmbiosHookPublishConfig(&g_Config);
#endif
                    status = SaveMacConfiguration();
                    information = sizeof(HwidConfig);
                }
            }
        } else if (code == IOCTL_HWID_GET_CONFIG) {
            if (outLength < sizeof(HwidConfig) || !Irp->AssociatedIrp.SystemBuffer) {
                status = STATUS_BUFFER_TOO_SMALL;
            } else {
                KLOCK_QUEUE_HANDLE lock;
                LockConfigRead(&lock);
                RtlCopyMemory(Irp->AssociatedIrp.SystemBuffer, &g_Config, sizeof(g_Config));
                UnlockConfigRead(&lock);
                information = sizeof(g_Config);
                status = STATUS_SUCCESS;
            }
        } else if (code == IOCTL_HWID_RESTORE) {
            if (inLength != sizeof(HwidRestoreRequest) ||
                outLength < sizeof(HwidConfig)) {
                status = STATUS_BUFFER_TOO_SMALL;
            } else {
                auto request = static_cast<HwidRestoreRequest*>(Irp->AssociatedIrp.SystemBuffer);
                if (request->Magic != HWID_CONFIG_MAGIC ||
                    request->StructSize != sizeof(HwidRestoreRequest)) {
                    status = STATUS_INVALID_PARAMETER;
                } else {
                    KLOCK_QUEUE_HANDLE lock;
                    LockConfigRead(&lock);
                    g_Config.Flags = HWID_SPOOF_NONE;
                    RtlCopyMemory(Irp->AssociatedIrp.SystemBuffer, &g_Config, sizeof(g_Config));
                    UnlockConfigRead(&lock);
#if HWID_ENABLE_SMBIOS_HOOK
                    SmbiosHookPublishConfig(&g_Config);
#endif
                    SaveMacConfiguration();
                    information = sizeof(HwidConfig);
                    status = STATUS_SUCCESS;
                }
            }
        }
    }

    Irp->IoStatus.Status = status;
    Irp->IoStatus.Information = information;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return status;
}

NTSTATUS HwidPassThrough(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    if (DeviceObject == g_ControlDevice) {
        Irp->IoStatus.Status = STATUS_INVALID_DEVICE_REQUEST;
        Irp->IoStatus.Information = 0;
        IoCompleteRequest(Irp, IO_NO_INCREMENT);
        return STATUS_INVALID_DEVICE_REQUEST;
    }
    auto extension = static_cast<FilterExtension*>(DeviceObject->DeviceExtension);
    NTSTATUS status = IoAcquireRemoveLock(&extension->RemoveLock, Irp);
    if (!NT_SUCCESS(status)) {
        Irp->IoStatus.Status = status;
        IoCompleteRequest(Irp, IO_NO_INCREMENT);
        return status;
    }
    IoSkipCurrentIrpStackLocation(Irp);
    status = IoCallDriver(extension->LowerDevice, Irp);
    IoReleaseRemoveLock(&extension->RemoveLock, Irp);
    return status;
}

NTSTATUS HwidPower(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    if (DeviceObject == g_ControlDevice) {
        Irp->IoStatus.Status = STATUS_NOT_SUPPORTED;
        IoCompleteRequest(Irp, IO_NO_INCREMENT);
        return STATUS_NOT_SUPPORTED;
    }
    auto extension = static_cast<FilterExtension*>(DeviceObject->DeviceExtension);
    NTSTATUS status = IoAcquireRemoveLock(&extension->RemoveLock, Irp);
    if (!NT_SUCCESS(status)) {
        Irp->IoStatus.Status = status;
        IoCompleteRequest(Irp, IO_NO_INCREMENT);
        return status;
    }
    PoStartNextPowerIrp(Irp);
    IoSkipCurrentIrpStackLocation(Irp);
    status = PoCallDriver(extension->LowerDevice, Irp);
    IoReleaseRemoveLock(&extension->RemoveLock, Irp);
    return status;
}

NTSTATUS HwidPnp(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(Irp);
    if (DeviceObject == g_ControlDevice) {
        Irp->IoStatus.Status = STATUS_INVALID_DEVICE_REQUEST;
        Irp->IoStatus.Information = 0;
        IoCompleteRequest(Irp, IO_NO_INCREMENT);
        return STATUS_INVALID_DEVICE_REQUEST;
    }
    auto extension = static_cast<FilterExtension*>(DeviceObject->DeviceExtension);
    if (stack->MinorFunction != IRP_MN_REMOVE_DEVICE)
        return HwidPassThrough(DeviceObject, Irp);

    NTSTATUS status = IoAcquireRemoveLock(&extension->RemoveLock, Irp);
    if (!NT_SUCCESS(status))
        return HwidPassThrough(DeviceObject, Irp);
    IoSkipCurrentIrpStackLocation(Irp);
    status = IoCallDriver(extension->LowerDevice, Irp);
    IoReleaseRemoveLockAndWait(&extension->RemoveLock, Irp);
    ExAcquireFastMutex(&g_FilterListLock);
    RemoveEntryList(&extension->Link);
    ExReleaseFastMutex(&g_FilterListLock);
    IoDetachDevice(extension->LowerDevice);
    IoDeleteDevice(DeviceObject);
    InterlockedDecrement(&g_FilterCount);
    return status;
}

static VOID RewriteSerial(PSTORAGE_DEVICE_DESCRIPTOR descriptor, ULONG length,
    const HwidConfig& config)
{
    if (!(config.Flags & HWID_SPOOF_DISK) ||
        descriptor->SerialNumberOffset == 0 ||
        descriptor->SerialNumberOffset >= length)
        return;

    PCHAR serial = reinterpret_cast<PCHAR>(descriptor) + descriptor->SerialNumberOffset;
    SIZE_T available = length - descriptor->SerialNumberOffset;
    SIZE_T originalLength = strnlen(serial, available);
    if (originalLength == available)
        return;
    SIZE_T replacementLength = strnlen(config.DiskSerial, sizeof(config.DiskSerial));
    SIZE_T copyLength = originalLength < replacementLength ? originalLength : replacementLength;
    if (copyLength == 0)
        return;
    RtlCopyMemory(serial, config.DiskSerial, copyLength);
    if (copyLength < originalLength)
        RtlFillMemory(serial + copyLength, originalLength - copyLength, ' ');
}

NTSTATUS HwidStorageComplete(PDEVICE_OBJECT DeviceObject, PIRP Irp, PVOID context)
{
    if (Irp->PendingReturned)
        IoMarkIrpPending(Irp);

    if (NT_SUCCESS(Irp->IoStatus.Status) && Irp->AssociatedIrp.SystemBuffer) {
        auto extension = static_cast<FilterExtension*>(DeviceObject->DeviceExtension);
        if (!DeviceSelected(extension)) {
            IoReleaseRemoveLock(&extension->RemoveLock, Irp);
            return STATUS_SUCCESS;
        }
        auto descriptor = static_cast<PSTORAGE_DEVICE_DESCRIPTOR>(Irp->AssociatedIrp.SystemBuffer);
        PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(Irp);
        ULONG length = stack->Parameters.DeviceIoControl.OutputBufferLength;
        if (length >= sizeof(STORAGE_DEVICE_DESCRIPTOR)) {
            KLOCK_QUEUE_HANDLE lock;
            LockConfigRead(&lock);
            ULONG resultLength = (ULONG)Irp->IoStatus.Information;
            if (stack->Parameters.DeviceIoControl.IoControlCode == IOCTL_STORAGE_QUERY_PROPERTY) {
                if ((g_Config.Flags & HWID_SPOOF_DISK) &&
                    PtrToUlong(context) == StorageDeviceProtocolSpecificProperty &&
                    resultLength >= sizeof(STORAGE_PROTOCOL_DATA_DESCRIPTOR)) {
                    auto protocol = static_cast<PSTORAGE_PROTOCOL_DATA_DESCRIPTOR>(Irp->AssociatedIrp.SystemBuffer);
                    auto specific = &protocol->ProtocolSpecificData;
                    SIZE_T base = reinterpret_cast<PUCHAR>(specific) -
                        reinterpret_cast<PUCHAR>(Irp->AssociatedIrp.SystemBuffer);
                    if (specific->DataType == NVMeDataTypeIdentify &&
                        specific->ProtocolDataRequestValue == 1 &&
                        specific->ProtocolDataOffset >= sizeof(STORAGE_PROTOCOL_SPECIFIC_DATA) &&
                        specific->ProtocolDataLength >= 24 &&
                        specific->ProtocolDataOffset <= resultLength - base &&
                        specific->ProtocolDataLength <= resultLength - base - specific->ProtocolDataOffset) {
                        PUCHAR identify = reinterpret_cast<PUCHAR>(specific) + specific->ProtocolDataOffset;
                        for (ULONG i = 0; i < 20; ++i) identify[4 + i] = i < 20 ? g_Config.DiskSerial[i] : ' ';
                    }
                } else {
                    RewriteSerial(descriptor, length < resultLength ? length : resultLength, g_Config);
                }
            }
            UnlockConfigRead(&lock);
        }
    }
    auto extension = static_cast<FilterExtension*>(DeviceObject->DeviceExtension);
    IoReleaseRemoveLock(&extension->RemoveLock, Irp);
    return STATUS_SUCCESS;
}

NTSTATUS HwidStorage(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    if (DeviceObject == g_ControlDevice)
        return HwidControl(DeviceObject, Irp);
    auto extension = static_cast<FilterExtension*>(DeviceObject->DeviceExtension);
    PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(Irp);
    if (stack->Parameters.DeviceIoControl.IoControlCode != IOCTL_STORAGE_QUERY_PROPERTY ||
        stack->Parameters.DeviceIoControl.InputBufferLength < sizeof(STORAGE_PROPERTY_QUERY))
        return HwidPassThrough(DeviceObject, Irp);

    auto query = static_cast<PSTORAGE_PROPERTY_QUERY>(Irp->AssociatedIrp.SystemBuffer);
    if (!query || (query->PropertyId != StorageDeviceProperty &&
                   query->PropertyId != StorageDeviceProtocolSpecificProperty) ||
        query->QueryType != PropertyStandardQuery)
        return HwidPassThrough(DeviceObject, Irp);

    NTSTATUS status = IoAcquireRemoveLock(&extension->RemoveLock, Irp);
    if (!NT_SUCCESS(status)) {
        Irp->IoStatus.Status = status;
        IoCompleteRequest(Irp, IO_NO_INCREMENT);
        return status;
    }
    IoCopyCurrentIrpStackLocationToNext(Irp);
    IoSetCompletionRoutine(Irp, HwidStorageComplete, UlongToPtr(query->PropertyId), TRUE, TRUE, TRUE);
    return IoCallDriver(extension->LowerDevice, Irp);
}

NTSTATUS HwidVolumeComplete(PDEVICE_OBJECT DeviceObject, PIRP Irp, PVOID context)
{
    auto extension = static_cast<FilterExtension*>(DeviceObject->DeviceExtension);
    if (Irp->PendingReturned)
        IoMarkIrpPending(Irp);
    if (!NT_SUCCESS(Irp->IoStatus.Status) || !Irp->AssociatedIrp.SystemBuffer) {
        IoReleaseRemoveLock(&extension->RemoveLock, Irp);
        return STATUS_SUCCESS;
    }

    const BOOLEAN selected = DeviceSelected(extension);
    KLOCK_QUEUE_HANDLE lock;
    LockConfigRead(&lock);
    if ((g_Config.Flags & HWID_SPOOF_VOLUME) && selected) {
        ULONG code = PtrToUlong(context);
        if (code == IRP_MJ_QUERY_VOLUME_INFORMATION) {
            PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(Irp);
            if (stack->Parameters.QueryVolume.FsInformationClass == FileFsVolumeInformation &&
                Irp->IoStatus.Information >= FIELD_OFFSET(FILE_FS_VOLUME_INFORMATION, VolumeLabel)) {
                auto info = static_cast<PFILE_FS_VOLUME_INFORMATION>(Irp->AssociatedIrp.SystemBuffer);
                info->VolumeSerialNumber = ParseVolumeSerial(g_Config.VolumeId);
            }
        } else if (Irp->IoStatus.Information >= sizeof(LARGE_INTEGER)) {
            // VolumeSerialNumber is the first field of NTFS_VOLUME_DATA_BUFFER.
            auto info = static_cast<PLARGE_INTEGER>(Irp->AssociatedIrp.SystemBuffer);
            info->QuadPart = ParseVolumeSerial(g_Config.VolumeId);
        }
    }
    UnlockConfigRead(&lock);
    IoReleaseRemoveLock(&extension->RemoveLock, Irp);
    return STATUS_SUCCESS;
}

NTSTATUS HwidVolume(PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
    auto extension = static_cast<FilterExtension*>(DeviceObject->DeviceExtension);
    PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(Irp);
    ULONG code = stack->MajorFunction;
    if (stack->MajorFunction == IRP_MJ_DEVICE_CONTROL)
        code = stack->Parameters.DeviceIoControl.IoControlCode;
    else if (stack->MajorFunction == IRP_MJ_QUERY_VOLUME_INFORMATION &&
        stack->Parameters.QueryVolume.FsInformationClass != FileFsVolumeInformation)
        return HwidPassThrough(DeviceObject, Irp);
    else if (stack->MajorFunction != IRP_MJ_QUERY_VOLUME_INFORMATION)
        return HwidPassThrough(DeviceObject, Irp);

    if (code != IRP_MJ_QUERY_VOLUME_INFORMATION && code != FSCTL_GET_NTFS_VOLUME_DATA)
        return HwidPassThrough(DeviceObject, Irp);

    NTSTATUS status = IoAcquireRemoveLock(&extension->RemoveLock, Irp);
    if (!NT_SUCCESS(status)) {
        Irp->IoStatus.Status = status;
        IoCompleteRequest(Irp, IO_NO_INCREMENT);
        return status;
    }
    IoCopyCurrentIrpStackLocationToNext(Irp);
    IoSetCompletionRoutine(Irp, HwidVolumeComplete,
        UlongToPtr(code), TRUE, TRUE, TRUE);
    return IoCallDriver(extension->LowerDevice, Irp);
}

static NTSTATUS AttachFilter(PDRIVER_OBJECT DriverObject, PCWSTR deviceName,
    FilterKind kind)
{
    UNICODE_STRING name;
    PFILE_OBJECT fileObject;
    PDEVICE_OBJECT target;
    PDEVICE_OBJECT filter;
    NTSTATUS status;

    RtlInitUnicodeString(&name, deviceName);
    status = IoGetDeviceObjectPointer(&name, FILE_READ_ATTRIBUTES, &fileObject, &target);
    if (!NT_SUCCESS(status))
        return status;
    if (AlreadyAttached(deviceName)) {
        ObDereferenceObject(fileObject);
        return STATUS_SUCCESS;
    }
    // A notification can race the initial scan or a previous notification.
    if (target->AttachedDevice && target->AttachedDevice->DriverObject == DriverObject) {
        ObDereferenceObject(fileObject);
        return STATUS_SUCCESS;
    }
    status = IoCreateDevice(DriverObject, sizeof(FilterExtension), nullptr,
        target->DeviceType, 0, FALSE, &filter);
    if (NT_SUCCESS(status)) {
        filter->Flags |= target->Flags & (DO_BUFFERED_IO | DO_DIRECT_IO | DO_POWER_PAGABLE);
        auto extension = static_cast<FilterExtension*>(filter->DeviceExtension);
        extension->Kind = kind;
        RtlStringCchCopyW(extension->DeviceName, RTL_NUMBER_OF(extension->DeviceName), deviceName);
        IoInitializeRemoveLock(&extension->RemoveLock, HWID_TAG, 0, 0);
        status = IoAttachDeviceToDeviceStackSafe(filter, target, &extension->LowerDevice);
        if (NT_SUCCESS(status)) {
            ExAcquireFastMutex(&g_FilterListLock);
            InsertTailList(&g_FilterList, &extension->Link);
            ExReleaseFastMutex(&g_FilterListLock);
            filter->Flags &= ~DO_DEVICE_INITIALIZING;
            InterlockedIncrement(&g_FilterCount);
        } else {
            IoDeleteDevice(filter);
        }
    }
    ObDereferenceObject(fileObject);
    return status;
}

static VOID AttachExistingDevices(PDRIVER_OBJECT DriverObject)
{
    WCHAR name[64];
    for (ULONG disk = 0; disk < 32; ++disk) {
        RtlStringCchPrintfW(name, RTL_NUMBER_OF(name), L"\\Device\\Harddisk%u\\DR0", disk);
        NTSTATUS status = AttachFilter(DriverObject, name, FilterDisk);
        if (!NT_SUCCESS(status) && status != STATUS_OBJECT_NAME_NOT_FOUND)
            DbgPrint("HwidLab: disk attach %u failed 0x%08X\n", disk, status);
    }
    for (ULONG volume = 1; volume <= 64; ++volume) {
        RtlStringCchPrintfW(name, RTL_NUMBER_OF(name), L"\\Device\\HarddiskVolume%u", volume);
        NTSTATUS status = AttachFilter(DriverObject, name, FilterVolume);
        if (!NT_SUCCESS(status) && status != STATUS_OBJECT_NAME_NOT_FOUND)
            DbgPrint("HwidLab: volume attach %u failed 0x%08X\n", volume, status);
    }
}

VOID HwidUnload(PDRIVER_OBJECT DriverObject)
{
    if (g_DiskNotification) {
        IoUnregisterPlugPlayNotification(g_DiskNotification);
        g_DiskNotification = nullptr;
    }
    if (g_VolumeNotification) {
        IoUnregisterPlugPlayNotification(g_VolumeNotification);
        g_VolumeNotification = nullptr;
    }
    while (InterlockedCompareExchange(&g_AttachWorkerRunning, 0, 0)) {
        LARGE_INTEGER delay;
        delay.QuadPart = -100000;
        KeDelayExecutionThread(KernelMode, FALSE, &delay);
    }
    while (TRUE) {
        ExAcquireFastMutex(&g_FilterListLock);
        if (IsListEmpty(&g_FilterList)) {
            ExReleaseFastMutex(&g_FilterListLock);
            break;
        }
        PLIST_ENTRY entry = RemoveHeadList(&g_FilterList);
        ExReleaseFastMutex(&g_FilterListLock);
        auto extension = CONTAINING_RECORD(entry, FilterExtension, Link);
        PDEVICE_OBJECT device = CONTAINING_RECORD(extension, DEVICE_OBJECT, DeviceExtension);
        IoAcquireRemoveLock(&extension->RemoveLock, device);
        IoReleaseRemoveLockAndWait(&extension->RemoveLock, device);
        IoDetachDevice(extension->LowerDevice);
        IoDeleteDevice(device);
    }
#if HWID_ENABLE_SMBIOS_HOOK
    SmbiosHookShutdown();
#endif
    UNICODE_STRING link;
    RtlInitUnicodeString(&link, HWID_CONTROL_LINK);
    IoDeleteSymbolicLink(&link);
    if (g_ControlDevice)
        IoDeleteDevice(g_ControlDevice);
    if (g_RegistryPath.Buffer)
        ExFreePool(g_RegistryPath.Buffer);
    ExDeleteResourceLite(&g_ConfigResource);
    UNREFERENCED_PARAMETER(DriverObject);
}

extern "C" NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath)
{
    NTSTATUS status;
    UNICODE_STRING name;
    UNICODE_STRING link;
    UNICODE_STRING sddl;

    RtlZeroMemory(&g_Config, sizeof(g_Config));
    g_Config.Magic = HWID_CONFIG_MAGIC;
    g_Config.Version = HWID_CONFIG_VERSION;
    g_Config.StructSize = sizeof(g_Config);
    InitializeListHead(&g_FilterList);
    ExInitializeFastMutex(&g_FilterListLock);
    KeInitializeSpinLock(&g_ConfigLock);
    status = ExInitializeResourceLite(&g_ConfigResource);
    if (!NT_SUCCESS(status))
        return status;

    g_RegistryPath.Length = 0;
    g_RegistryPath.MaximumLength = RegistryPath->Length + sizeof(WCHAR);
    g_RegistryPath.Buffer = static_cast<PWSTR>(ExAllocatePoolWithTag(
        PagedPool, g_RegistryPath.MaximumLength, HWID_TAG));
    if (!g_RegistryPath.Buffer) {
        ExDeleteResourceLite(&g_ConfigResource);
        return STATUS_INSUFFICIENT_RESOURCES;
    }
    RtlCopyUnicodeString(&g_RegistryPath, RegistryPath);

    RtlInitUnicodeString(&name, HWID_CONTROL_NAME);
    RtlInitUnicodeString(&sddl, L"D:P(A;;GA;;;SY)(A;;GA;;;BA)");
    status = IoCreateDeviceSecure(DriverObject, 0, &name, FILE_DEVICE_UNKNOWN,
        FILE_DEVICE_SECURE_OPEN, FALSE, &sddl, nullptr, &g_ControlDevice);
    if (!NT_SUCCESS(status)) {
        DbgPrint("HwidLab: control device creation failed 0x%08X\n", status);
        HwidUnload(DriverObject);
        return status;
    }
    RtlInitUnicodeString(&link, HWID_CONTROL_LINK);
    status = IoCreateSymbolicLink(&link, &name);
    if (!NT_SUCCESS(status)) {
        HwidUnload(DriverObject);
        return status;
    }

    for (ULONG i = 0; i <= IRP_MJ_MAXIMUM_FUNCTION; ++i)
        DriverObject->MajorFunction[i] = HwidPassThrough;
    DriverObject->MajorFunction[IRP_MJ_CREATE] = HwidControl;
    DriverObject->MajorFunction[IRP_MJ_CLOSE] = HwidControl;
    DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = HwidStorage;
    DriverObject->MajorFunction[IRP_MJ_QUERY_VOLUME_INFORMATION] = HwidVolume;
    DriverObject->MajorFunction[IRP_MJ_PNP] = HwidPnp;
    DriverObject->MajorFunction[IRP_MJ_POWER] = HwidPower;
    DriverObject->DriverUnload = HwidUnload;

    g_ControlDevice->Flags |= DO_BUFFERED_IO;
    g_ControlDevice->Flags &= ~DO_DEVICE_INITIALIZING;
    AttachExistingDevices(DriverObject);
    IoRegisterPlugPlayNotification(EventCategoryDeviceInterfaceChange,
        PNPNOTIFY_DEVICE_INTERFACE_INCLUDE_EXISTING_INTERFACES,
        const_cast<GUID*>(&GUID_DEVINTERFACE_DISK), DriverObject, StorageInterfaceChanged,
        DriverObject, &g_DiskNotification);
    IoRegisterPlugPlayNotification(EventCategoryDeviceInterfaceChange,
        PNPNOTIFY_DEVICE_INTERFACE_INCLUDE_EXISTING_INTERFACES,
        const_cast<GUID*>(&GUID_DEVINTERFACE_VOLUME), DriverObject, StorageInterfaceChanged,
        DriverObject, &g_VolumeNotification);
#if HWID_ENABLE_SMBIOS_HOOK
    status = SmbiosHookInitialize();
    if (!NT_SUCCESS(status)) {
        DbgPrint("HwidLab: SMBIOS hook initialization failed 0x%08X\n", status);
        HwidUnload(DriverObject);
        return status;
    }
#endif
    DbgPrint("HwidLab: loaded with %ld filters\n", g_FilterCount);
    return STATUS_SUCCESS;
}
