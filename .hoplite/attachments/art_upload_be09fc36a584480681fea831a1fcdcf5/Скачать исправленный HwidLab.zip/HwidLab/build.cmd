@echo off
setlocal
if "%VSINSTALLDIR%"=="" (
  echo Run this script from a Developer Command Prompt for Visual Studio.
  exit /b 1
)
msbuild "%~dp0kernel\HwidCore.vcxproj" /p:Configuration=Release /p:Platform=x64 /p:OutDir="%~dp0build\drivers\\" /m || exit /b 1
msbuild "%~dp0kernel\HwidNdis.vcxproj" /p:Configuration=Release /p:Platform=x64 /p:OutDir="%~dp0build\drivers\\" /m || exit /b 1
cmake -S "%~dp0usermode" -B "%~dp0build\usermode" -A x64 || exit /b 1
cmake --build "%~dp0build\usermode" --config Release || exit /b 1
if not exist "%~dp0Bin" mkdir "%~dp0Bin"
copy /y "%~dp0build\drivers\HwidCore.sys" "%~dp0Bin\" >nul || exit /b 1
copy /y "%~dp0build\drivers\HwidNdis.sys" "%~dp0Bin\" >nul || exit /b 1
copy /y "%~dp0build\usermode\Release\HwidLabGUI.exe" "%~dp0Bin\" >nul || exit /b 1
copy /y "%~dp0build\usermode\Release\HwidLoader.exe" "%~dp0Bin\" >nul || exit /b 1
copy /y "%~dp0kernel\HwidCore.inf" "%~dp0Bin\" >nul
copy /y "%~dp0kernel\HwidNdis.inf" "%~dp0Bin\" >nul
if not exist "%~dp0Bin\tools" mkdir "%~dp0Bin\tools"
copy /y "%~dp0tools\Reset-HyperVTpm.ps1" "%~dp0Bin\tools\" >nul
echo Build completed: %~dp0build
