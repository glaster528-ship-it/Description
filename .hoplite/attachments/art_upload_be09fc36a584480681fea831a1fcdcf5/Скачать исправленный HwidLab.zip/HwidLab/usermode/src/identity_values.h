#pragma once

#include <string>

namespace hwid {

bool ReadIdentityValue(const std::wstring& name, std::wstring* value);
bool WriteIdentityValue(const std::wstring& name, const std::wstring& value);
bool DeleteIdentityValue(const std::wstring& name);
std::wstring NormalizeMac(const std::wstring& value);

}  // namespace hwid
