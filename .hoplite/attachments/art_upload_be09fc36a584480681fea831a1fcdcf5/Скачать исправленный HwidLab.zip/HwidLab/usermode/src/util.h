#pragma once

#include <windows.h>

#include <iostream>
#include <string>

namespace hwid {

template <typename HandleT, auto Closer>
class UniqueHandle {
 public:
  UniqueHandle() = default;
  explicit UniqueHandle(HandleT handle) : handle_(handle) {}
  ~UniqueHandle() { reset(); }
  UniqueHandle(const UniqueHandle&) = delete;
  UniqueHandle& operator=(const UniqueHandle&) = delete;
  UniqueHandle(UniqueHandle&& other) noexcept : handle_(other.release()) {}
  UniqueHandle& operator=(UniqueHandle&& other) noexcept {
    if (this != &other) {
      reset();
      handle_ = other.release();
    }
    return *this;
  }

  HandleT get() const { return handle_; }
  bool valid() const { return handle_ != kInvalid(); }
  HandleT release() {
    HandleT tmp = handle_;
    handle_ = kInvalid();
    return tmp;
  }
  void reset(HandleT handle = kInvalid()) {
    if (handle_ != kInvalid()) Closer(handle_);
    handle_ = handle;
  }

 private:
  static HandleT kInvalid() { return nullptr; }
  HandleT handle_ = kInvalid();
};

using UniqueWinHandle = UniqueHandle<HANDLE, CloseHandle>;
using UniqueSvcHandle = UniqueHandle<SC_HANDLE, CloseServiceHandle>;

inline void CloseRegKey(HKEY key) { RegCloseKey(key); }
using UniqueRegKey = UniqueHandle<HKEY, CloseRegKey>;

inline std::string Narrow(const std::wstring& wide) {
  if (wide.empty()) return {};
  const int size = WideCharToMultiByte(CP_UTF8, 0, wide.c_str(),
                                       static_cast<int>(wide.size()), nullptr, 0,
                                       nullptr, nullptr);
  std::string out(static_cast<size_t>(size), '\0');
  if (size > 0) {
    WideCharToMultiByte(CP_UTF8, 0, wide.c_str(), static_cast<int>(wide.size()),
                        &out[0], size, nullptr, nullptr);
  }
  return out;
}

inline std::string Narrow(const wchar_t* wide) { return Narrow(std::wstring(wide)); }

inline std::wstring Widen(const std::string& narrow) {
  if (narrow.empty()) return {};
  const int size = MultiByteToWideChar(CP_UTF8, 0, narrow.c_str(),
                                       static_cast<int>(narrow.size()), nullptr, 0);
  std::wstring out(static_cast<size_t>(size), L'\0');
  if (size > 0) {
    MultiByteToWideChar(CP_UTF8, 0, narrow.c_str(), static_cast<int>(narrow.size()),
                        &out[0], size);
  }
  return out;
}

inline std::string WinErrorText(DWORD code) {
  LPSTR buffer = nullptr;
  const DWORD size = FormatMessageA(
      FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |
          FORMAT_MESSAGE_IGNORE_INSERTS,
      nullptr, code, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
      reinterpret_cast<LPSTR>(&buffer), 0, nullptr);
  std::string text = (size > 0 && buffer) ? std::string(buffer, size) : std::string();
  if (buffer) LocalFree(buffer);
  while (!text.empty() &&
         (text.back() == '\n' || text.back() == '\r' || text.back() == ' ')) {
    text.pop_back();
  }
  return text;
}

inline void ReportWinError(const char* what) {
  const DWORD code = GetLastError();
  std::cerr << "[!] " << what << " failed (" << code << "): " << WinErrorText(code)
            << "\n";
}

inline bool IsElevated() {
  HANDLE raw = nullptr;
  if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &raw)) return false;
  UniqueWinHandle token(raw);
  TOKEN_ELEVATION elevation{};
  DWORD returned = 0;
  if (!GetTokenInformation(token.get(), TokenElevation, &elevation, sizeof(elevation),
                           &returned)) {
    return false;
  }
  return elevation.TokenIsElevated != FALSE;
}

inline bool RequireElevated() {
  if (IsElevated()) return true;
  std::cerr << "[!] Administrator privileges required for this command\n";
  return false;
}

}  // namespace hwid
