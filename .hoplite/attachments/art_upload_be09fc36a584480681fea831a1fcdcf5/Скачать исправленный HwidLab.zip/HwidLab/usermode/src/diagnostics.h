#pragma once

namespace hwid {

int RunPreflight();
int RunVerify();
int RunSetValue(const char* name, const char* value);
int RunRegenerateValues();

}  // namespace hwid
