#include "extra_ops.h"

#include "util.h"

#include <windows.h>
#include <winevt.h>

#include <array>
#include <iostream>
#include <string>
#include <vector>

namespace hwid {
namespace {

std::wstring ExecutableDirectory() {
  std::vector<wchar_t> path(1024);
  for (;;) {
    const DWORD size = GetModuleFileNameW(nullptr, path.data(), path.size());
    if (!size) return L"";
    if (size < path.size() - 1) {
      std::wstring result(path.data(), size);
      return result.substr(0, result.find_last_of(L"\\/"));
    }
    path.resize(path.size() * 2);
  }
}

std::wstring FindTpmScript() {
  const std::wstring dir = ExecutableDirectory();
  const std::wstring paths[] = {dir + L"\\tools\\Reset-HyperVTpm.ps1",
                                dir + L"\\..\\tools\\Reset-HyperVTpm.ps1",
                                dir + L"\\..\\..\\tools\\Reset-HyperVTpm.ps1"};
  for (const auto& path : paths) {
    const DWORD attributes = GetFileAttributesW(path.c_str());
    if (attributes != INVALID_FILE_ATTRIBUTES && !(attributes & FILE_ATTRIBUTE_DIRECTORY)) {
      return path;
    }
  }
  return L"";
}

std::wstring QuoteArgument(const std::wstring& value) {
  std::wstring result = L"\"";
  size_t slashes = 0;
  for (wchar_t c : value) {
    if (c == L'\\') {
      ++slashes;
    } else if (c == L'\"') {
      result.append(slashes * 2 + 1, L'\\');
      result += c;
      slashes = 0;
    } else {
      result.append(slashes, L'\\');
      result += c;
      slashes = 0;
    }
  }
  result.append(slashes * 2, L'\\');
  result += L'\"';
  return result;
}

}  // namespace

int RunClearEventLogs() {
  if (!RequireElevated()) return 1;
  int cleared = 0, errors = 0;
  for (const wchar_t* channel : {L"Application", L"Security", L"Setup", L"System"}) {
    if (EvtClearLog(nullptr, channel, nullptr, 0)) {
      std::cout << "[+] Cleared event log: " << Narrow(channel) << "\n";
      ++cleared;
    } else {
      const DWORD error = GetLastError();
      std::cerr << "[!] Could not clear " << Narrow(channel) << ": "
                << WinErrorText(error) << "\n";
      ++errors;
    }
  }
  std::cout << "[i] Event log cleanup finished: " << cleared << " cleared, "
            << errors << " failed\n";
  return errors ? 1 : 0;
}

int RunResetVirtualTpm(const std::wstring& vmName) {
  if (!RequireElevated()) return 1;
  if (vmName.empty() || vmName.size() > 256 || vmName.find_first_of(L"\"\r\n") != std::wstring::npos) {
    std::cerr << "[!] Invalid Hyper-V virtual machine name\n";
    return 1;
  }
  const std::wstring script = FindTpmScript();
  if (script.empty()) {
    std::cerr << "[!] tools\\Reset-HyperVTpm.ps1 not found beside HwidLoader.exe\n";
    return 1;
  }
  const std::wstring arguments = L"-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File " +
      QuoteArgument(script) + L" -VMName " + QuoteArgument(vmName);
  std::wcout << L"[i] Hyper-V host command: " << arguments << L"\n";
  std::wstring command = L"powershell.exe " + arguments;
  std::vector<wchar_t> mutableCommand(command.begin(), command.end());
  mutableCommand.push_back(0);
  STARTUPINFOW startup{};
  startup.cb = sizeof(startup);
  startup.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
  startup.wShowWindow = SW_HIDE;
  startup.hStdInput = GetStdHandle(STD_INPUT_HANDLE);
  startup.hStdOutput = GetStdHandle(STD_OUTPUT_HANDLE);
  startup.hStdError = GetStdHandle(STD_ERROR_HANDLE);
  PROCESS_INFORMATION processInfo{};
  if (!CreateProcessW(nullptr, mutableCommand.data(), nullptr, nullptr, TRUE,
                      CREATE_NO_WINDOW, nullptr, nullptr, &startup, &processInfo)) {
    ReportWinError("start Hyper-V TPM reset");
    return 1;
  }
  UniqueWinHandle process(processInfo.hProcess), thread(processInfo.hThread);
  WaitForSingleObject(process.get(), INFINITE);
  DWORD exitCode = 1;
  GetExitCodeProcess(process.get(), &exitCode);
  if (exitCode != 0) {
    std::cerr << "[!] vTPM reset failed; VM remains off. Read the PowerShell error above.\n";
    return static_cast<int>(exitCode) ? static_cast<int>(exitCode) : 1;
  }
  std::cout << "[+] Hyper-V vTPM reset completed; VM remains powered off\n";
  return 0;
}

int RunVmwareSnapshot(const std::wstring& vmx, const std::wstring& name, bool revert) {
  if (!RequireElevated() || vmx.empty() || vmx.size() > MAX_PATH || name.size() > 80) return 1;
  const wchar_t* roots[] = {L"C:\\Program Files (x86)\\VMware\\VMware Workstation\\vmrun.exe",
                            L"C:\\Program Files\\VMware\\VMware Workstation\\vmrun.exe"};
  std::wstring vmrun;
  for (const wchar_t* path : roots) if (GetFileAttributesW(path) != INVALID_FILE_ATTRIBUTES) {
    vmrun = path;
    break;
  }
  if (vmrun.empty()) {
    std::cerr << "[!] VMware Workstation vmrun.exe was not found\n";
    return 1;
  }
  std::wstring command = QuoteArgument(vmrun) + L" -T ws " +
      (revert ? L"revertToSnapshot " : L"snapshot ") + QuoteArgument(vmx) + L" " + QuoteArgument(name);
  std::vector<wchar_t> mutableCommand(command.begin(), command.end());
  mutableCommand.push_back(0);
  STARTUPINFOW startup{};
  startup.cb = sizeof(startup);
  startup.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
  startup.wShowWindow = SW_HIDE;
  startup.hStdInput = GetStdHandle(STD_INPUT_HANDLE);
  startup.hStdOutput = GetStdHandle(STD_OUTPUT_HANDLE);
  startup.hStdError = GetStdHandle(STD_ERROR_HANDLE);
  PROCESS_INFORMATION info{};
  if (!CreateProcessW(nullptr, mutableCommand.data(), nullptr, nullptr, TRUE, CREATE_NO_WINDOW,
                      nullptr, nullptr, &startup, &info)) {
    ReportWinError("vmrun");
    return 1;
  }
  UniqueWinHandle process(info.hProcess), thread(info.hThread);
  WaitForSingleObject(process.get(), INFINITE);
  DWORD code = 1;
  GetExitCodeProcess(process.get(), &code);
  return code;
}

int RunHyperVCheckpoint(const std::wstring& vmName, const std::wstring& name, bool revert) {
  if (!RequireElevated() || vmName.empty() || name.empty() || vmName.size() > 256 || name.size() > 80) return 1;
  std::wstring ps = L"$v=Get-VM -Name '" + vmName + L"'; ";
  ps += revert ? L"Restore-VMCheckpoint -VM $v -Name '" + name + L"' -Confirm:$false"
               : L"Checkpoint-VM -VM $v -SnapshotName '" + name + L"'";
  std::wstring command = L"powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command " + QuoteArgument(ps);
  std::vector<wchar_t> mutableCommand(command.begin(), command.end());
  mutableCommand.push_back(0);
  STARTUPINFOW startup{};
  startup.cb = sizeof(startup);
  startup.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
  startup.wShowWindow = SW_HIDE;
  startup.hStdInput = GetStdHandle(STD_INPUT_HANDLE);
  startup.hStdOutput = GetStdHandle(STD_OUTPUT_HANDLE);
  startup.hStdError = GetStdHandle(STD_ERROR_HANDLE);
  PROCESS_INFORMATION info{};
  if (!CreateProcessW(nullptr, mutableCommand.data(), nullptr, nullptr, TRUE, CREATE_NO_WINDOW,
                      nullptr, nullptr, &startup, &info)) return 1;
  UniqueWinHandle process(info.hProcess), thread(info.hThread);
  WaitForSingleObject(process.get(), INFINITE);
  DWORD code = 1;
  GetExitCodeProcess(process.get(), &code);
  return code;
}

int RunNdisSetup(bool install) {
  if (!RequireElevated()) return 1;
  std::wstring arguments;
  if (install) {
    const std::wstring inf = ExecutableDirectory() + L"\\HwidNdis.inf";
    if (GetFileAttributesW(inf.c_str()) == INVALID_FILE_ATTRIBUTES) {
      std::cerr << "[!] HwidNdis.inf was not found beside HwidLoader.exe\n";
      return 1;
    }
    arguments = L"-v -l " + QuoteArgument(inf) + L" -c s -i HwidNdis";
  } else {
    arguments = L"-v -u HwidNdis";
  }
  wchar_t systemDirectory[MAX_PATH]{};
  if (!GetSystemDirectoryW(systemDirectory, MAX_PATH)) return 1;
  const std::wstring netcfg = std::wstring(systemDirectory) + L"\\netcfg.exe";
  std::wstring command = QuoteArgument(netcfg) + L" " + arguments;
  std::vector<wchar_t> mutableCommand(command.begin(), command.end());
  mutableCommand.push_back(0);
  STARTUPINFOW startup{};
  startup.cb = sizeof(startup);
  startup.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
  startup.wShowWindow = SW_HIDE;
  startup.hStdInput = GetStdHandle(STD_INPUT_HANDLE);
  startup.hStdOutput = GetStdHandle(STD_OUTPUT_HANDLE);
  startup.hStdError = GetStdHandle(STD_ERROR_HANDLE);
  PROCESS_INFORMATION info{};
  if (!CreateProcessW(nullptr, mutableCommand.data(), nullptr, nullptr, TRUE, CREATE_NO_WINDOW,
                      nullptr, nullptr, &startup, &info)) {
    ReportWinError("netcfg");
    return 1;
  }
  UniqueWinHandle process(info.hProcess), thread(info.hThread);
  WaitForSingleObject(process.get(), INFINITE);
  DWORD code = 1;
  GetExitCodeProcess(process.get(), &code);
  if (code == 0) std::cout << (install ? "[+] NDIS filter installed\n" : "[+] NDIS filter removed\n");
  return static_cast<int>(code);
}

}  // namespace hwid
