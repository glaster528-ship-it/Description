#pragma once

#include <windows.h>

#include <string>

namespace hwid {

// Live locations of the values the loader spoofs in usermode.
constexpr wchar_t kMachineGuidKey[] = L"SOFTWARE\\Microsoft\\Cryptography";
constexpr wchar_t kMachineGuidValue[] = L"MachineGuid";
constexpr wchar_t kHwProfileKey[] = L"SYSTEM\\CurrentControlSet\\Hardware Profiles\\Current";
constexpr wchar_t kHwProfileValue[] = L"HwProfileGuid";

// Loader-managed storage: original values (Backups) and generated state (State).
constexpr wchar_t kBackupKey[] = L"SOFTWARE\\HwidLab\\Backups";
constexpr wchar_t kStateKey[] = L"SOFTWARE\\HwidLab\\State";

bool ReadSz(HKEY root, const wchar_t* subkey, const wchar_t* value, std::wstring* out);
bool ReadQword(HKEY root, const wchar_t* subkey, const wchar_t* value,
               unsigned long long* out);
bool WriteSz(const wchar_t* subkey, const wchar_t* value, const std::wstring& data);
bool WriteQword(const wchar_t* subkey, const wchar_t* value, unsigned long long data);
bool DeleteValue(const wchar_t* subkey, const wchar_t* valueName);

// Copies the current REG_SZ value into kBackupKey once; later calls keep the
// stored original so repeated spoof runs cannot overwrite the real value.
bool BackupString(const wchar_t* srcSubKey, const wchar_t* valueName,
                  const wchar_t* backupName = nullptr);

enum class RestoreResult { Restored, NoBackup, Error };
RestoreResult RestoreString(const wchar_t* dstSubKey, const wchar_t* valueName,
                            const wchar_t* backupName = nullptr);

}  // namespace hwid
