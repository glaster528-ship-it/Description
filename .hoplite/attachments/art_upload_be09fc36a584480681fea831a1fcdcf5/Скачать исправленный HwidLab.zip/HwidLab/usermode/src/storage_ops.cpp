#include "storage_ops.h"

#include "identity_values.h"
#include "registry_ops.h"
#include "util.h"

#include <windows.h>
#include <winioctl.h>

#include <iostream>
#include <string>
#include <vector>

namespace hwid {
namespace {

const wchar_t* BusName(STORAGE_BUS_TYPE bus) {
  switch (bus) {
    case BusTypeNvme: return L"NVMe";
    case BusTypeSata: return L"SATA";
    case BusTypeSas: return L"SAS";
    case BusTypeUsb: return L"USB";
    case BusTypeRAID: return L"RAID";
    default: return L"OTHER";
  }
}

std::wstring BoundedString(const char* data, size_t size) {
  size_t length = 0;
  while (length < size && data[length]) ++length;
  while (length && data[length - 1] == ' ') --length;
  return Widen(std::string(data, length));
}

}  // namespace

int RunStorageList() {
  for (DWORD i = 0; i < 128; ++i) {
    const std::wstring path = L"\\\\.\\PhysicalDrive" + std::to_wstring(i);
    HANDLE raw = CreateFileW(path.c_str(), 0, FILE_SHARE_READ | FILE_SHARE_WRITE,
                             nullptr, OPEN_EXISTING, 0, nullptr);
    if (raw == INVALID_HANDLE_VALUE) continue;
    UniqueWinHandle disk(raw);
    STORAGE_PROPERTY_QUERY query{};
    query.PropertyId = StorageDeviceProperty;
    query.QueryType = PropertyStandardQuery;
    std::vector<unsigned char> buffer(4096);
    DWORD returned = 0;
    if (!DeviceIoControl(disk.get(), IOCTL_STORAGE_QUERY_PROPERTY, &query, sizeof(query),
                         buffer.data(), buffer.size(), &returned, nullptr)) continue;
    auto descriptor = reinterpret_cast<PSTORAGE_DEVICE_DESCRIPTOR>(buffer.data());
    std::wstring vendor, product, serial;
    auto text = [&](ULONG offset) -> std::wstring {
      if (!offset || offset >= returned) return L"";
      return BoundedString(reinterpret_cast<const char*>(buffer.data() + offset), returned - offset);
    };
    vendor = text(descriptor->VendorIdOffset);
    product = text(descriptor->ProductIdOffset);
    serial = text(descriptor->SerialNumberOffset);
    std::wcout << L"DEVICE " << i << L" | model=" << vendor << L" " << product
               << L" | bus=" << BusName(descriptor->BusType) << L" | serial=" << serial
               << L" | path=\\\\Device\\Harddisk" << i << L"\\DR0\n";
  }
  return 0;
}

void SelectStorageDevice(const std::wstring& deviceName) {
  WriteIdentityValue(L"StorageDevice", deviceName);
}

void PrintStorageStatus() {
  std::wcout << L"\nPHYSICAL STORAGE INVENTORY\n";
  RunStorageList();
}

}  // namespace hwid
