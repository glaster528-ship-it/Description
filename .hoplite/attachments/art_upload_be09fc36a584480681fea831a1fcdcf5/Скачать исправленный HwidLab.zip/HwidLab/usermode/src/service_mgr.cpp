#include "service_mgr.h"

#include "HwidProtocol.h"
#include "util.h"

#include <iostream>

namespace hwid {
namespace {

constexpr DWORD kStatusTimeoutMs = 8000;

bool WaitPending(SC_HANDLE service, DWORD pendingState, DWORD doneState) {
  SERVICE_STATUS status{};
  DWORD waited = 0;
  while (waited <= kStatusTimeoutMs) {
    if (!QueryServiceStatus(service, &status)) return false;
    if (status.dwCurrentState == doneState) return true;
    if (status.dwCurrentState != pendingState) return false;
    Sleep(250);
    waited += 250;
  }
  return false;
}

}  // namespace

int RunInstall(const std::wstring& sysPathArg) {
  if (!RequireElevated()) return 1;

  wchar_t fullPath[MAX_PATH];
  const DWORD length = GetFullPathNameW(sysPathArg.c_str(), MAX_PATH, fullPath, nullptr);
  if (length == 0 || length >= MAX_PATH) {
    std::cerr << "[!] Invalid driver path\n";
    return 1;
  }
  if (GetFileAttributesW(fullPath) == INVALID_FILE_ATTRIBUTES) {
    std::cerr << "[!] Driver file not found: " << Narrow(fullPath) << "\n";
    return 1;
  }

  UniqueSvcHandle scm(OpenSCManagerW(nullptr, nullptr, SC_MANAGER_CREATE_SERVICE));
  if (!scm.valid()) {
    ReportWinError("OpenSCManagerW");
    return 1;
  }

  UniqueSvcHandle service(CreateServiceW(
      scm.get(), HWID_SERVICE_NAME, HWID_SERVICE_DISPLAY, SERVICE_ALL_ACCESS,
      SERVICE_KERNEL_DRIVER, SERVICE_DEMAND_START, SERVICE_ERROR_IGNORE, fullPath,
      nullptr, nullptr, nullptr, nullptr, nullptr));
  if (!service.valid()) {
    if (GetLastError() == ERROR_SERVICE_EXISTS) {
      service.reset(OpenServiceW(scm.get(), HWID_SERVICE_NAME,
          SERVICE_CHANGE_CONFIG | SERVICE_QUERY_STATUS | SERVICE_STOP));
      if (!service.valid()) {
        ReportWinError("OpenServiceW(update)");
        return 1;
      }
      SERVICE_STATUS status{};
      if (QueryServiceStatus(service.get(), &status) && status.dwCurrentState != SERVICE_STOPPED) {
        SERVICE_STATUS stopped{};
        if (!ControlService(service.get(), SERVICE_CONTROL_STOP, &stopped) ||
            !WaitPending(service.get(), SERVICE_STOP_PENDING, SERVICE_STOPPED)) {
          std::cerr << "[!] Stop the old driver before updating it; reboot if it remains loaded\n";
          return 1;
        }
      }
      if (!ChangeServiceConfigW(service.get(), SERVICE_NO_CHANGE, SERVICE_NO_CHANGE,
              SERVICE_NO_CHANGE, fullPath, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr)) {
        ReportWinError("ChangeServiceConfigW");
        return 1;
      }
      std::cout << "[+] Existing driver service updated -> " << Narrow(fullPath) << "\n";
      return 0;
    }
    ReportWinError("CreateServiceW");
    return 1;
  }
  std::cout << "[+] Service " << Narrow(HWID_SERVICE_NAME) << " created -> "
            << Narrow(fullPath) << "\n";
  std::cout << "[i] Start it with: HwidLoader.exe start\n";
  return 0;
}

int RunStart() {
  if (!RequireElevated()) return 1;

  UniqueSvcHandle scm(OpenSCManagerW(nullptr, nullptr, SC_MANAGER_CONNECT));
  if (!scm.valid()) {
    ReportWinError("OpenSCManagerW");
    return 1;
  }
  UniqueSvcHandle service(
      OpenServiceW(scm.get(), HWID_SERVICE_NAME, SERVICE_START | SERVICE_QUERY_STATUS));
  if (!service.valid()) {
    if (GetLastError() == ERROR_SERVICE_DOES_NOT_EXIST) {
      std::cerr << "[i] Service not installed (run: HwidLoader.exe install <path.sys>)\n";
      return 1;
    }
    ReportWinError("OpenServiceW");
    return 1;
  }

  SERVICE_STATUS status{};
  if (QueryServiceStatus(service.get(), &status) &&
      status.dwCurrentState == SERVICE_RUNNING) {
    std::cout << "[i] Service already running\n";
    return 0;
  }
  if (!StartServiceW(service.get(), 0, nullptr)) {
    ReportWinError("StartServiceW");
    return 1;
  }
  if (!WaitPending(service.get(), SERVICE_START_PENDING, SERVICE_RUNNING)) {
    std::cerr << "[!] Service did not reach RUNNING state in time\n";
    return 1;
  }
  std::cout << "[+] Service started\n";
  return 0;
}

int RunStop() {
  if (!RequireElevated()) return 1;

  UniqueSvcHandle scm(OpenSCManagerW(nullptr, nullptr, SC_MANAGER_CONNECT));
  if (!scm.valid()) {
    ReportWinError("OpenSCManagerW");
    return 1;
  }
  UniqueSvcHandle service(
      OpenServiceW(scm.get(), HWID_SERVICE_NAME, SERVICE_STOP | SERVICE_QUERY_STATUS));
  if (!service.valid()) {
    if (GetLastError() == ERROR_SERVICE_DOES_NOT_EXIST) {
      std::cerr << "[i] Service not installed\n";
      return 1;
    }
    ReportWinError("OpenServiceW");
    return 1;
  }

  SERVICE_STATUS status{};
  if (QueryServiceStatus(service.get(), &status) &&
      status.dwCurrentState == SERVICE_STOPPED) {
    std::cout << "[i] Service already stopped\n";
    return 0;
  }
  if (!ControlService(service.get(), SERVICE_CONTROL_STOP, &status)) {
    const DWORD err = GetLastError();
    if (err != ERROR_SERVICE_NOT_ACTIVE) {
      SetLastError(err);
      ReportWinError("ControlService");
      return 1;
    }
  }
  if (!WaitPending(service.get(), SERVICE_STOP_PENDING, SERVICE_STOPPED)) {
    std::cerr << "[!] Service did not reach STOPPED state in time\n";
    return 1;
  }
  std::cout << "[+] Service stopped\n";
  return 0;
}

int RunUninstall() {
  if (!RequireElevated()) return 1;

  UniqueSvcHandle scm(OpenSCManagerW(nullptr, nullptr, SC_MANAGER_CONNECT));
  if (!scm.valid()) {
    ReportWinError("OpenSCManagerW");
    return 1;
  }
  UniqueSvcHandle service(OpenServiceW(
      scm.get(), HWID_SERVICE_NAME, SERVICE_QUERY_STATUS | SERVICE_STOP | DELETE));
  if (!service.valid()) {
    if (GetLastError() == ERROR_SERVICE_DOES_NOT_EXIST) {
      std::cout << "[i] Service not installed\n";
      return 0;
    }
    ReportWinError("OpenServiceW");
    return 1;
  }

  SERVICE_STATUS status{};
  if (QueryServiceStatus(service.get(), &status) &&
      status.dwCurrentState != SERVICE_STOPPED) {
    if (!ControlService(service.get(), SERVICE_CONTROL_STOP, &status)) {
      const DWORD err = GetLastError();
      if (err != ERROR_SERVICE_NOT_ACTIVE) {
        SetLastError(err);
        ReportWinError("ControlService");
      }
    } else if (!WaitPending(service.get(), SERVICE_STOP_PENDING, SERVICE_STOPPED)) {
      std::cerr << "[!] Service did not stop in time; deletion may need a reboot\n";
    }
  }

  if (!DeleteService(service.get())) {
    ReportWinError("DeleteServiceW");
    return 1;
  }
  std::cout << "[+] Service deleted (a reboot may be needed to unload the driver)\n";
  return 0;
}

}  // namespace hwid
