#include "service_mgr.h"
#include "extra_ops.h"
#include "diagnostics.h"
#include "network_ops.h"
#include "session_ops.h"
#include "storage_ops.h"
#include "spoof.h"
#include "util.h"

#include <iostream>
#include <string>

namespace {

void PrintUsage() {
  std::cerr << "HwidLab usermode loader (local lab use only)\n"
            << "\n"
            << "Usage:\n"
            << "  HwidLoader.exe install <path\\to\\driver.sys>   Create the HwidLab kernel service\n"
            << "  HwidLoader.exe start                           Start the driver service\n"
            << "  HwidLoader.exe stop                            Stop the driver service\n"
            << "  HwidLoader.exe uninstall                       Stop if needed, then delete the service\n"
            << "  HwidLoader.exe spoof ALL|DISK|SMBIOS|MAC|VOLUME|MACHINEGUID|HWPROFILE|NETMAC|NETGUID\n"
            << "  HwidLoader.exe clear-logs                     Clear Application, Security, Setup and System logs\n"
            << "  HwidLoader.exe tpm <VMName>                   Checkpoint and rotate a powered-off Hyper-V VM vTPM\n"
            << "  HwidLoader.exe preflight                    Check Windows, VMware, elevation and driver state\n"
            << "  HwidLoader.exe verify                       Compare live driver/registry state with recorded values\n"
            << "  HwidLoader.exe net-mac|net-guid [GUID]      Spoof all adapters or one NetCfgInstanceId\n"
            << "  HwidLoader.exe restore-net-mac|restore-net-guid <GUID>\n"
            << "  HwidLoader.exe set-value <field> <value>    Save a custom identity value\n"
            << "  HwidLoader.exe regenerate                   Generate new values on next apply\n"
            << "  HwidLoader.exe sessions | rollback-session <id>\n"
            << "  HwidLoader.exe vmware-snapshot|vmware-revert <VMX> <name>\n"
            << "  HwidLoader.exe storage-list                 List physical disks and bus types\n"
            << "  HwidLoader.exe storage-select <n|ALL>       Select a physical disk for driver filtering\n"
            << "  HwidLoader.exe show                            Show service status, spoof state and backups\n"
            << "  HwidLoader.exe restore                         Restore original registry values and ask the driver to restore\n";
}

}  // namespace

int main(int argc, char** argv) {
  if (argc < 2) {
    PrintUsage();
    return 1;
  }
  const std::string command = argv[1];

  if (command == "install" && argc == 3) {
    return hwid::RunInstall(hwid::Widen(argv[2]));
  }
  if (command == "start" && argc == 2) return hwid::RunStart();
  if (command == "stop" && argc == 2) return hwid::RunStop();
  if (command == "uninstall" && argc == 2) return hwid::RunUninstall();
  if (command == "spoof" && argc == 3) {
    hwid::SpoofTarget target;
    if (!hwid::ParseSpoofTarget(argv[2], &target)) {
      std::cerr << "[!] Unknown spoof target: " << argv[2] << "\n";
      PrintUsage();
      return 1;
    }
    return hwid::RunSpoof(target);
  }
  if (command == "show" && argc == 2) return hwid::RunShow();
  if (command == "restore" && argc == 2) return hwid::RunRestore();
  if (command == "clear-logs" && argc == 2) return hwid::RunClearEventLogs();
  if (command == "ndis-install" && argc == 2) return hwid::RunNdisSetup(true);
  if (command == "ndis-remove" && argc == 2) return hwid::RunNdisSetup(false);
  if (command == "tpm" && argc == 3) return hwid::RunResetVirtualTpm(hwid::Widen(argv[2]));
  if (command == "preflight" && argc == 2) return hwid::RunPreflight();
  if (command == "storage-list" && argc == 2) return hwid::RunStorageList();
  if (command == "storage-select" && argc == 3) {
    std::wstring name = hwid::Widen(argv[2]);
    if (name != L"ALL") name = L"\\\\Device\\Harddisk" + name + L"\\DR0";
    hwid::SelectStorageDevice(name == L"ALL" ? L"" : name);
    return 0;
  }
  if (command == "verify" && argc == 2) return hwid::RunVerify();
  if (command == "net-mac" && (argc == 2 || argc == 3)) return hwid::RunNetworkSpoof(hwid::NetworkTarget::Mac, argc == 3 ? hwid::Widen(argv[2]) : L"");
  if (command == "net-guid" && (argc == 2 || argc == 3)) return hwid::RunNetworkSpoof(hwid::NetworkTarget::InstanceGuid, argc == 3 ? hwid::Widen(argv[2]) : L"");
  if (command == "restore-net-mac" && argc == 3) return hwid::RunNetworkRestore(hwid::NetworkTarget::Mac, hwid::Widen(argv[2]));
  if (command == "restore-net-guid" && argc == 3) return hwid::RunNetworkRestore(hwid::NetworkTarget::InstanceGuid, hwid::Widen(argv[2]));
  if (command == "set-value" && argc == 4) return hwid::RunSetValue(argv[2], argv[3]);
  if (command == "regenerate" && argc == 2) return hwid::RunRegenerateValues();
  if (command == "sessions" && argc == 2) return hwid::RunSessionList();
  if (command == "rollback-session" && argc == 3) return hwid::RunSessionRollback(argv[2]);
  if ((command == "vmware-snapshot" || command == "vmware-revert") && argc == 4)
    return hwid::RunVmwareSnapshot(hwid::Widen(argv[2]), hwid::Widen(argv[3]), command == "vmware-revert");

  std::cerr << "[!] Invalid command or arguments\n";
  PrintUsage();
  return 1;
}
