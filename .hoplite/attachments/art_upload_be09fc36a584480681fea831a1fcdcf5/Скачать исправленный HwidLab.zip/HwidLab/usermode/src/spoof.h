#pragma once

#include <string>

namespace hwid {

enum class SpoofTarget { All, Disk, SmBios, Mac, Volume, MachineGuid, HwProfile, NetworkMac, NetworkGuid };

bool ParseSpoofTarget(const std::string& name, SpoofTarget* out);

int RunSpoof(SpoofTarget target);
int RunShow();
int RunRestore();

}  // namespace hwid
