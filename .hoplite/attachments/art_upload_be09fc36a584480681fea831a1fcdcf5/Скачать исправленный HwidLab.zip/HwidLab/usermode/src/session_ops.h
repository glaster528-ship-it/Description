#pragma once

#include <string>

namespace hwid {

int RunSessionList();
int RunSessionRollback(const char* id);
void RecordSession(const char* target, bool driver, bool machineGuid, bool hwProfile,
                   const std::wstring& previousDriver, const std::wstring& networkId = L"",
                   bool networkMac = false, bool networkGuid = false);

}  // namespace hwid
