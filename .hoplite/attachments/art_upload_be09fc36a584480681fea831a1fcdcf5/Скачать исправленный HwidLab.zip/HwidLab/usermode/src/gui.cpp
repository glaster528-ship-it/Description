#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <commdlg.h>
#include <shellapi.h>
#include <uxtheme.h>
#include <objidl.h>
#include <gdiplus.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <fstream>
#include <memory>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

namespace {

constexpr UINT kWorkerMessage = WM_APP + 20;
constexpr UINT kRefreshMessage = WM_APP + 21;
constexpr UINT_PTR kAnimationTimer = 7;
constexpr int kPageX = 260;
constexpr int kPageY = 116;
constexpr int kPageSlideDistance = 8;
constexpr COLORREF kBackground = RGB(9, 13, 20);
constexpr COLORREF kSurface = RGB(14, 20, 30);
constexpr COLORREF kCard = RGB(20, 29, 43);
constexpr COLORREF kBorder = RGB(39, 53, 73);
constexpr COLORREF kText = RGB(239, 244, 252);
constexpr COLORREF kMuted = RGB(142, 157, 180);
constexpr COLORREF kAccent = RGB(139, 105, 255);
constexpr COLORREF kCyan = RGB(50, 205, 234);
constexpr COLORREF kMint = RGB(64, 211, 164);
constexpr COLORREF kRed = RGB(248, 113, 128);
constexpr COLORREF kAmber = RGB(245, 184, 91);

enum ControlId {
  kSelectAll = 1000, kPreview, kApply, kRestore, kInstall, kStart, kStop,
  kRefresh, kClearLogs, kResetTpm, kProfileName, kSaveProfile, kLoadProfile,
  kProfiles, kDeleteProfile, kHistory, kLog, kClearActivity, kExportLog,
  kCopyLog, kPageTabs, kPreflight, kVerify, kAdapterList, kAdapterRefresh,
  kAdapterMac, kAdapterGuid, kAdapterRestoreMac, kAdapterRestoreGuid,
  kCustomField, kCustomValue, kCustomSave, kRegenerate, kSessions,
  kRollbackSession, kRollbackFailed, kVmxPath, kSnapshotName, kVmwareSnapshot,
  kVmwareRevert, kNdisInstall, kNdisRemove, kTargetBase = 1100,
  kStorageList, kStorageSelect, kStorageAll,
  kNavBase = 4000, kStageBase = 4100,
};

struct Target {
  const wchar_t* title;
  const wchar_t* description;
  const wchar_t* command;
  bool selected;
  HWND checkbox;
};

struct WorkerResult {
  std::wstring command;
  std::wstring output;
  DWORD exitCode;
  bool completed;
};

struct QueueData {
  std::mutex mutex;
  std::vector<std::unique_ptr<WorkerResult>> results;
  std::vector<std::wstring> history;
};

struct FontSet {
  HFONT regular = nullptr;
  HFONT medium = nullptr;
  HFONT title = nullptr;
  HFONT small = nullptr;
  HFONT mono = nullptr;
  HFONT display = nullptr;
  HFONT icon = nullptr;
};

enum class VisualKind { Nav, Button, Target, Stage };
enum class StageState { Idle, Active, Done, Warning, Failed };
struct Visual {
  HWND hwnd = nullptr;
  VisualKind kind = VisualKind::Button;
  std::wstring title;
  std::wstring subtitle;
  std::wstring icon;
  bool primary = false;
  bool danger = false;
  bool hovered = false;
  bool pressed = false;
  float hover = 0;
  float press = 0;
};

HWND g_window;
FontSet g_font;
HBRUSH g_backgroundBrush;
HBRUSH g_surfaceBrush;
HBRUSH g_cardBrush;
UINT g_dpi = 96;
std::atomic<bool> g_busy{false};
std::atomic<bool> g_closing{false};
std::thread g_worker;
QueueData g_queue;
std::wstring g_loader;
std::wstring g_service = L"Checking...";
std::wstring g_activity;
std::wstring g_lastSession;
std::vector<std::wstring> g_adapterIds;
HWND g_pages[5], g_preview, g_history, g_log, g_progress;
HWND g_adapterList, g_customField, g_customValue, g_sessions, g_diagnostics;
HWND g_vmxPath, g_snapshotName;
HWND g_storageList;
std::vector<std::wstring> g_storagePaths;
HWND g_serviceLabel, g_loaderLabel, g_statusLabel, g_profileName, g_profiles;
HWND g_operationTitle, g_operationHint, g_selectionLabel, g_pageTitle, g_pageSubtitle;
ULONG_PTR g_gdiplus = 0;
UINT_PTR g_animationTimer = 0;
std::vector<Visual> g_visuals;
int g_page = 0;
float g_pageSlide = 0;
bool g_reduceMotion = false;
StageState g_stages[3] = {StageState::Idle, StageState::Idle, StageState::Idle};
std::wstring g_stageText[3] = {L"Ready", L"Not run", L"Not run"};
bool g_hasVerification = false;
bool g_verificationPassed = false;
bool g_verificationExpected = false;
std::vector<Target> g_targets = {
    {L"Disk serial", L"Filter reported storage serial", L"DISK", true, nullptr},
    {L"SMBIOS", L"System, board and BIOS identity", L"SMBIOS", true, nullptr},
    {L"MAC (driver)", L"NDIS filter reported address", L"MAC", true, nullptr},
    {L"Volume ID", L"Filter reported volume serial", L"VOLUME", true, nullptr},
    {L"Machine GUID", L"Windows cryptography identity", L"MACHINEGUID", true, nullptr},
    {L"Hardware profile", L"Current hardware profile GUID", L"HWPROFILE", true, nullptr},
    {L"Registry MAC", L"NetworkAddress + NIC restart", L"NETMAC", false, nullptr},
    {L"Adapter GUID", L"NetCfgInstanceId + NIC restart", L"NETGUID", false, nullptr},
};

int Scale(int value) { return MulDiv(value, static_cast<int>(g_dpi), 96); }

Visual* FindVisual(HWND hwnd) {
  auto it = std::find_if(g_visuals.begin(), g_visuals.end(),
                         [hwnd](const Visual& visual) { return visual.hwnd == hwnd; });
  return it == g_visuals.end() ? nullptr : &*it;
}

void StartAnimation() {
  if (g_window && !g_animationTimer)
    g_animationTimer = SetTimer(g_window, kAnimationTimer, 16, nullptr);
}

void InvalidateVisual(Visual* visual) {
  if (visual) InvalidateRect(visual->hwnd, nullptr, FALSE);
}

LRESULT CALLBACK VisualProc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam,
                            UINT_PTR, DWORD_PTR) {
  Visual* visual = FindVisual(hwnd);
  if (!visual) return DefSubclassProc(hwnd, message, wparam, lparam);
  switch (message) {
    case WM_MOUSEMOVE:
      if (!visual->hovered) {
        TRACKMOUSEEVENT track{sizeof(track), TME_LEAVE, hwnd, 0};
        TrackMouseEvent(&track);
      }
      visual->hovered = true;
      StartAnimation();
      break;
    case WM_MOUSELEAVE:
      visual->hovered = false;
      visual->pressed = false;
      StartAnimation();
      break;
    case WM_LBUTTONDOWN:
      visual->pressed = true;
      StartAnimation();
      break;
    case WM_LBUTTONUP:
      visual->pressed = false;
      StartAnimation();
      break;
    case WM_SETFOCUS:
    case WM_KILLFOCUS:
      InvalidateVisual(visual);
      break;
    case WM_KEYUP:
      if (wparam == VK_SPACE || wparam == VK_RETURN) {
        SendMessageW(GetParent(hwnd), WM_COMMAND,
            MAKEWPARAM(GetDlgCtrlID(hwnd), STN_CLICKED), reinterpret_cast<LPARAM>(hwnd));
        return 0;
      }
      break;
    case WM_NCDESTROY:
      RemoveWindowSubclass(hwnd, VisualProc, 0);
      break;
  }
  return DefSubclassProc(hwnd, message, wparam, lparam);
}

void AddRoundRect(Gdiplus::GraphicsPath* path, const Gdiplus::RectF& rect, float radius) {
  const float d = radius * 2;
  path->AddArc(rect.X, rect.Y, d, d, 180, 90);
  path->AddArc(rect.GetRight() - d, rect.Y, d, d, 270, 90);
  path->AddArc(rect.GetRight() - d, rect.GetBottom() - d, d, d, 0, 90);
  path->AddArc(rect.X, rect.GetBottom() - d, d, d, 90, 90);
  path->CloseFigure();
}

Gdiplus::Color GdiColor(COLORREF color, BYTE alpha = 255) {
  return Gdiplus::Color(alpha, GetRValue(color), GetGValue(color), GetBValue(color));
}

void Text(HDC dc, const std::wstring& value, RECT rect, HFONT font, COLORREF color,
          UINT flags = DT_LEFT | DT_SINGLELINE | DT_VCENTER) {
  SetBkMode(dc, TRANSPARENT);
  SetTextColor(dc, color);
  HGDIOBJ old = SelectObject(dc, font);
  DrawTextW(dc, value.c_str(), static_cast<int>(value.size()), &rect, flags | DT_NOPREFIX);
  SelectObject(dc, old);
}

void PaintVisual(const DRAWITEMSTRUCT& item) {
  Visual* visual = FindVisual(item.hwndItem);
  if (!visual) return;
  const int id = static_cast<int>(item.CtlID);
  const bool enabled = IsWindowEnabled(item.hwndItem) != FALSE;
  const float hover = enabled ? visual->hover : 0;
  const float press = enabled ? visual->press : 0;
  Gdiplus::Graphics graphics(item.hDC);
  graphics.SetSmoothingMode(Gdiplus::SmoothingModeAntiAlias);
  RECT bounds = item.rcItem;
  const bool onShell = GetParent(item.hwndItem) == g_window;
  Gdiplus::SolidBrush backdrop(GdiColor(onShell ? kSurface : kBackground));
  graphics.FillRectangle(&backdrop, Gdiplus::Rect(bounds.left, bounds.top,
                                                  bounds.right - bounds.left, bounds.bottom - bounds.top));
  Gdiplus::RectF rect(0.5f, 0.5f, static_cast<float>(bounds.right - bounds.left - 1),
                      static_cast<float>(bounds.bottom - bounds.top - 1));
  rect.Inflate(-press, -press);
  Gdiplus::GraphicsPath path;
  AddRoundRect(&path, rect, static_cast<float>(Scale(visual->kind == VisualKind::Nav ? 9 : 11)));

  if (visual->kind == VisualKind::Nav) {
    const bool selected = g_page == id - kNavBase;
    const COLORREF color = selected ? kAccent : kCard;
    Gdiplus::SolidBrush fill(GdiColor(color, static_cast<BYTE>(selected ? 34 + hover * 20 : hover * 100)));
    graphics.FillPath(&fill, &path);
    if (selected) {
      Gdiplus::SolidBrush indicator(GdiColor(kAccent));
      Gdiplus::GraphicsPath stripe;
      AddRoundRect(&stripe, Gdiplus::RectF(0, static_cast<float>(Scale(12)), static_cast<float>(Scale(3)),
                                          static_cast<float>(bounds.bottom - Scale(24))), 1.5f);
      graphics.FillPath(&indicator, &stripe);
    }
    RECT icon{Scale(15), 0, Scale(45), bounds.bottom};
    Text(item.hDC, visual->icon, icon, g_font.icon, selected ? kAccent : kMuted,
         DT_CENTER | DT_SINGLELINE | DT_VCENTER);
    RECT title{Scale(48), 0, bounds.right - Scale(12), bounds.bottom};
    Text(item.hDC, visual->title, title, g_font.medium, selected || !enabled ? kText : kMuted);
    return;
  }

  if (visual->kind == VisualKind::Stage) {
    const int index = id - kStageBase;
    const StageState state = g_stages[index];
    const COLORREF color = state == StageState::Done ? kMint : state == StageState::Failed ? kRed :
        state == StageState::Warning ? kAmber : state == StageState::Active ? kAccent : kMuted;
    Gdiplus::SolidBrush fill(GdiColor(kCard, static_cast<BYTE>(180 + hover * 30)));
    graphics.FillPath(&fill, &path);
    Gdiplus::Pen pen(GdiColor(color, state == StageState::Idle ? 60 : 130), 1);
    graphics.DrawPath(&pen, &path);
    Gdiplus::SolidBrush dot(GdiColor(color));
    graphics.FillEllipse(&dot, static_cast<float>(Scale(16)), static_cast<float>(Scale(19)),
                         static_cast<float>(Scale(8)), static_cast<float>(Scale(8)));
    RECT title{Scale(32), Scale(7), bounds.right - Scale(10), Scale(30)};
    Text(item.hDC, visual->title, title, g_font.small, kMuted);
    RECT value{Scale(16), Scale(29), bounds.right - Scale(10), bounds.bottom - Scale(5)};
    Text(item.hDC, g_stageText[index], value, g_font.medium, state == StageState::Idle ? kMuted : kText);
    return;
  }

  if (visual->kind == VisualKind::Target) {
    const bool selected = g_targets[id - kTargetBase].selected;
    Gdiplus::SolidBrush fill(GdiColor(selected ? kAccent : kCard,
                                     static_cast<BYTE>(selected ? 24 + hover * 20 : 160 + hover * 70)));
    graphics.FillPath(&fill, &path);
    Gdiplus::Pen pen(GdiColor(selected ? kAccent : kBorder,
                              static_cast<BYTE>(selected ? 170 + hover * 60 : 180 + hover * 50)),
                     selected ? 1.25f : 1.0f);
    graphics.DrawPath(&pen, &path);
    const float box = static_cast<float>(Scale(19));
    Gdiplus::RectF check(static_cast<float>(Scale(15)), (rect.Height - box) / 2 + 0.5f, box, box);
    Gdiplus::GraphicsPath checkPath;
    AddRoundRect(&checkPath, check, static_cast<float>(Scale(5)));
    Gdiplus::SolidBrush checkFill(GdiColor(selected ? kAccent : kBackground));
    graphics.FillPath(&checkFill, &checkPath);
    Gdiplus::Pen checkPen(GdiColor(selected ? kAccent : kBorder), 1);
    graphics.DrawPath(&checkPen, &checkPath);
    if (selected) {
      Gdiplus::Pen tick(GdiColor(kText), static_cast<float>(Scale(1.8)));
      tick.SetLineCap(Gdiplus::LineCapRound, Gdiplus::LineCapRound, Gdiplus::DashCapRound);
      graphics.DrawLine(&tick, check.X + Scale(4), check.Y + Scale(10),
                        check.X + Scale(8), check.Y + Scale(14));
      graphics.DrawLine(&tick, check.X + Scale(8), check.Y + Scale(14),
                        check.X + Scale(15), check.Y + Scale(5));
    }
    RECT title{Scale(47), Scale(8), bounds.right - Scale(12), Scale(30)};
    Text(item.hDC, visual->title, title, g_font.medium, enabled ? kText : kMuted);
    RECT subtitle{Scale(47), Scale(30), bounds.right - Scale(12), bounds.bottom - Scale(5)};
    Text(item.hDC, visual->subtitle, subtitle, g_font.small, kMuted);
    return;
  }

  if (visual->primary) {
    const COLORREF start = enabled ? RGB(139 + hover * 18, 105 + hover * 18, 255) : kBorder;
    const COLORREF end = enabled ? RGB(91 + hover * 18, 160 + hover * 18, 248) : kBorder;
    Gdiplus::LinearGradientBrush fill(rect, GdiColor(start), GdiColor(end),
                                      Gdiplus::LinearGradientModeHorizontal);
    graphics.FillPath(&fill, &path);
  } else {
    Gdiplus::SolidBrush fill(GdiColor(visual->danger ? kRed : kCard,
        static_cast<BYTE>(visual->danger ? 20 + hover * 35 : 175 + hover * 65)));
    graphics.FillPath(&fill, &path);
    Gdiplus::Pen pen(GdiColor(visual->danger ? kRed : kBorder, visual->danger ? 120 : 210), 1);
    graphics.DrawPath(&pen, &path);
  }
  RECT title{Scale(12), 0, bounds.right - Scale(12), bounds.bottom};
  Text(item.hDC, visual->title, title, g_font.medium,
       !enabled ? kMuted : visual->danger ? kRed : kText, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
}

void Animate() {
  bool active = false;
  for (auto& visual : g_visuals) {
    const float hoverTarget = visual.hovered && IsWindowEnabled(visual.hwnd) ? 1.0f : 0.0f;
    const float pressTarget = visual.pressed ? 1.0f : 0.0f;
    const float step = g_reduceMotion ? 1.0f : 0.24f;
    const float oldHover = visual.hover, oldPress = visual.press;
    visual.hover += (hoverTarget - visual.hover) * step;
    visual.press += (pressTarget - visual.press) * step;
    if (std::abs(hoverTarget - visual.hover) < 0.01f) visual.hover = hoverTarget;
    if (std::abs(pressTarget - visual.press) < 0.01f) visual.press = pressTarget;
    if (oldHover != visual.hover || oldPress != visual.press) InvalidateVisual(&visual);
    if (visual.hover != hoverTarget || visual.press != pressTarget) active = true;
  }
  if (g_pageSlide > 0) {
    g_pageSlide *= g_reduceMotion ? 0.0f : 0.72f;
    if (g_pageSlide < 0.025f) g_pageSlide = 0;
    SetWindowPos(g_pages[g_page], nullptr, Scale(kPageX),
        Scale(kPageY + static_cast<int>(kPageSlideDistance * g_pageSlide)), 0, 0,
        SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
    if (g_pageSlide > 0) active = true;
  }
  if (!active && g_animationTimer) {
    KillTimer(g_window, kAnimationTimer);
    g_animationTimer = 0;
  }
}

std::wstring Now() {
  SYSTEMTIME time{};
  GetLocalTime(&time);
  wchar_t result[32];
  swprintf_s(result, L"%04u-%02u-%02u %02u:%02u:%02u", time.wYear, time.wMonth,
             time.wDay, time.wHour, time.wMinute, time.wSecond);
  return result;
}

void SetControlFont(HWND control, HFONT font) {
  SendMessageW(control, WM_SETFONT, reinterpret_cast<WPARAM>(font), TRUE);
}

HWND Control(DWORD style, const wchar_t* className, const wchar_t* text, HWND parent,
             int id = 0, DWORD exStyle = 0) {
  HWND control = CreateWindowExW(exStyle, className, text, style | WS_CHILD | WS_VISIBLE,
      0, 0, 10, 10, parent, reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),
      GetModuleHandleW(nullptr), nullptr);
  if (control) SetControlFont(control, g_font.regular);
  return control;
}

std::wstring WindowText(HWND control) {
  const int size = GetWindowTextLengthW(control);
  std::wstring text(size, 0);
  GetWindowTextW(control, text.data(), size + 1);
  return text;
}

void AppendActivity(const std::wstring& text, bool history = true) {
  g_activity += text;
  if (GetWindowTextLengthW(g_log) > 250000) {
    SendMessageW(g_log, EM_SETSEL, 0, 50000);
    SendMessageW(g_log, EM_REPLACESEL, FALSE, reinterpret_cast<LPARAM>(L""));
  }
  const int end = GetWindowTextLengthW(g_log);
  SendMessageW(g_log, EM_SETSEL, end, end);
  SendMessageW(g_log, EM_REPLACESEL, FALSE, reinterpret_cast<LPARAM>(text.c_str()));
  SendMessageW(g_log, EM_SCROLLCARET, 0, 0);
  SendMessageW(g_log, EM_SETSEL, -1, -1);
  if (history) {
    std::wstring line = L"[" + Now() + L"]  " + text;
    const size_t newline = line.find(L"\r\n");
    if (newline != std::wstring::npos) line.resize(newline);
    SendMessageW(g_history, LB_ADDSTRING, 0, reinterpret_cast<LPARAM>(line.c_str()));
    const int count = static_cast<int>(SendMessageW(g_history, LB_GETCOUNT, 0, 0));
    SendMessageW(g_history, LB_SETTOPINDEX, std::max(0, count - 1), 0);
  }
}

std::wstring ModulePath() {
  std::vector<wchar_t> buffer(1024);
  for (;;) {
    const DWORD size = GetModuleFileNameW(nullptr, buffer.data(), buffer.size());
    if (!size) return L"";
    if (size < buffer.size() - 1) return std::wstring(buffer.data(), size);
    buffer.resize(buffer.size() * 2);
  }
}

std::wstring ModuleDir() {
  const std::wstring path = ModulePath();
  const size_t slash = path.find_last_of(L"\\/");
  return slash == std::wstring::npos ? L"" : path.substr(0, slash);
}

std::wstring FindLoader() {
  const std::wstring dir = ModuleDir();
  for (const std::wstring& path : {dir + L"\\HwidLoader.exe",
                                   dir + L"\\..\\HwidLoader.exe",
                                   dir + L"\\..\\Release\\HwidLoader.exe"}) {
    const DWORD attributes = GetFileAttributesW(path.c_str());
    if (attributes != INVALID_FILE_ATTRIBUTES && !(attributes & FILE_ATTRIBUTE_DIRECTORY)) return path;
  }
  return L"";
}

std::wstring Quote(const std::wstring& value) { return L"\"" + value + L"\""; }

void SetPage(int index) {
  index = std::clamp(index, 0, 4);
  const bool changed = g_page != index;
  g_page = index;
  g_pageSlide = changed && !g_reduceMotion ? 1.0f : 0.0f;
  for (int i = 0; i < 5; ++i) {
    if (i != index) ShowWindow(g_pages[i], SW_HIDE);
    InvalidateVisual(FindVisual(GetDlgItem(g_window, kNavBase + i)));
  }
  const wchar_t* titles[] = {L"Identity workspace", L"Driver & advanced", L"Devices & profiles",
                             L"Diagnostics", L"Activity log"};
  const wchar_t* subtitles[] = {
      L"Configure your lab profile with a clear, reversible workflow.",
      L"Service controls and isolated virtual-machine utilities.",
      L"Choose exactly which physical devices and values to work with.",
      L"Inspect compatibility first, then verify the actual result.",
      L"A complete, exportable record of every command and response."};
  SetWindowTextW(g_pageTitle, titles[index]);
  SetWindowTextW(g_pageSubtitle, subtitles[index]);
  SetWindowPos(g_pages[index], HWND_TOP, Scale(kPageX),
      Scale(kPageY + static_cast<int>(kPageSlideDistance * g_pageSlide)), 0, 0,
      SWP_NOSIZE | SWP_NOACTIVATE);
  ShowWindow(g_pages[index], SW_SHOWNA);
  RedrawWindow(g_pages[index], nullptr, nullptr, RDW_INVALIDATE | RDW_ALLCHILDREN);
  StartAnimation();
}

void SetStage(int index, StageState state, const std::wstring& text) {
  g_stages[index] = state;
  g_stageText[index] = text;
  InvalidateVisual(FindVisual(GetDlgItem(g_window, kStageBase + index)));
}

void ResetOperationStages(const std::wstring& name, bool verification, bool expected) {
  g_hasVerification = verification;
  g_verificationPassed = false;
  g_verificationExpected = expected || verification;
  SetWindowTextW(g_operationTitle, name.c_str());
  SetStage(0, StageState::Active, L"Sending");
  SetStage(1, StageState::Idle, L"Waiting");
  SetStage(2, verification ? StageState::Idle : g_verificationExpected ? StageState::Warning : StageState::Idle,
             verification ? L"Waiting" : g_verificationExpected ? L"Required" : L"Not required");
  SetWindowTextW(g_operationHint, verification ? L"Verification is included in this request." :
      g_verificationExpected ? L"Completion is not verification. Run Verify to check the result." :
      L"No identity changes are requested by this operation.");
}

void NoteCommandResult(const std::wstring& command, const std::wstring& output, DWORD exitCode) {
  if (command == L"verify") {
    const bool report = output.find(L"VERIFY END") != std::wstring::npos;
    g_hasVerification = true;
    g_verificationPassed = report && exitCode == 0 &&
        output.find(L"VERIFY END failures=0") != std::wstring::npos;
    SetStage(1, report ? StageState::Done : StageState::Failed, report ? L"Completed" : L"Failed");
    SetStage(2, g_verificationPassed ? StageState::Done : StageState::Failed,
             g_verificationPassed ? L"Passed" : L"Failed");
    SetWindowTextW(g_operationHint, g_verificationPassed ?
        L"Live values match the recorded configuration." :
        L"Verification reported differences or unavailable state. See diagnostics.");
    return;
  }
  if (exitCode == 0) {
    SetStage(1, StageState::Done, L"Completed");
    if (g_verificationExpected && !g_hasVerification) SetStage(2, StageState::Warning, L"Required");
  } else {
    SetStage(1, StageState::Failed, L"Failed");
  }
}

void RefreshAdapters(const std::wstring& output) {
  SendMessageW(g_adapterList, CB_RESETCONTENT, 0, 0);
  g_adapterIds.clear();
  std::wistringstream lines(output);
  std::wstring line, description, guid;
  auto append = [&]() {
    if (description.empty() || guid.empty()) return;
    SendMessageW(g_adapterList, CB_ADDSTRING, 0,
                 reinterpret_cast<LPARAM>((description + L" — " + guid).c_str()));
    g_adapterIds.push_back(guid);
  };
  while (std::getline(lines, line)) {
    if (line.size() > 2 && line[0] == L' ' && line[1] == L' ' && line[2] != L' ') {
      append(); description = line.substr(2); guid.clear();
    } else if (line.find(L"    guid   : ") == 0) guid = line.substr(15);
  }
  append();
  if (!g_adapterIds.empty()) SendMessageW(g_adapterList, CB_SETCURSEL, 0, 0);
}

void RefreshStorage(const std::wstring& output) {
  SendMessageW(g_storageList, CB_RESETCONTENT, 0, 0);
  g_storagePaths.clear();
  std::wistringstream lines(output);
  std::wstring line;
  while (std::getline(lines, line)) {
    if (line.rfind(L"DEVICE ", 0) != 0) continue;
    SendMessageW(g_storageList, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(line.c_str()));
    const size_t end = line.find(L" ", 7);
    g_storagePaths.push_back(line.substr(7, end - 7));
  }
  if (!g_storagePaths.empty()) SendMessageW(g_storageList, CB_SETCURSEL, 0, 0);
}

std::wstring SelectedAdapter() {
  const int index = static_cast<int>(SendMessageW(g_adapterList, CB_GETCURSEL, 0, 0));
  return index >= 0 && static_cast<size_t>(index) < g_adapterIds.size() ? g_adapterIds[index] : L"";
}

void UpdateSummary() {
  int count = 0;
  std::wstring preview;
  for (const auto& target : g_targets) {
    if (target.selected) {
      ++count;
      preview += std::wstring(L"[x] ") + target.title + L"    HwidLoader spoof " + target.command + L"\r\n";
    }
  }
  SetWindowTextW(g_preview, preview.empty() ? L"No identity modules selected." : preview.c_str());
  std::wstring label = std::to_wstring(count) + L" selected";
  SetDlgItemTextW(g_pages[0], kSelectAll + 50, label.c_str());
  if (g_selectionLabel)
    SetWindowTextW(g_selectionLabel, (std::to_wstring(count) + L" / 8 modules enabled").c_str());
}

void SetBusy(bool busy, const std::wstring& status) {
  g_busy = busy;
  SetWindowTextW(g_statusLabel, status.c_str());
  SendMessageW(g_progress, PBM_SETMARQUEE, busy, 40);
  for (auto& visual : g_visuals)
    if (visual.kind == VisualKind::Button) EnableWindow(visual.hwnd, !busy);
  for (const auto& target : g_targets) EnableWindow(target.checkbox, !busy);
  InvalidateRect(g_window, nullptr, FALSE);
}

void DecodeOutput(const std::string& bytes, std::wstring* output) {
  if (bytes.empty()) return;
  UINT codePage = CP_UTF8;
  int size = MultiByteToWideChar(codePage, MB_ERR_INVALID_CHARS, bytes.data(),
                                 static_cast<int>(bytes.size()), nullptr, 0);
  if (!size) {
    codePage = CP_ACP;
    size = MultiByteToWideChar(codePage, 0, bytes.data(), static_cast<int>(bytes.size()), nullptr, 0);
  }
  if (!size) return;
  std::wstring text(size, 0);
  MultiByteToWideChar(codePage, codePage == CP_UTF8 ? MB_ERR_INVALID_CHARS : 0,
                      bytes.data(), static_cast<int>(bytes.size()), text.data(), size);
  std::wstring normalized;
  normalized.reserve(text.size() + 32);
  for (size_t i = 0; i < text.size(); ++i) {
    if (text[i] == L'\n' && (i == 0 || text[i - 1] != L'\r')) normalized += L'\r';
    normalized += text[i];
  }
  *output += normalized;
}

void WorkerLoop(std::vector<std::wstring> commands) {
  bool allSucceeded = true;
  for (const auto& arguments : commands) {
    auto result = std::make_unique<WorkerResult>();
    result->command = arguments;
    result->exitCode = 1;
    SECURITY_ATTRIBUTES security{sizeof(security), nullptr, TRUE};
    HANDLE readPipe = nullptr, writePipe = nullptr;
    if (!CreatePipe(&readPipe, &writePipe, &security, 0)) {
      result->output = L"ERROR: cannot create process output pipe.\r\n";
    } else {
      SetHandleInformation(readPipe, HANDLE_FLAG_INHERIT, 0);
      STARTUPINFOW startup{};
      startup.cb = sizeof(startup);
      startup.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
      startup.wShowWindow = SW_HIDE;
      startup.hStdOutput = writePipe;
      startup.hStdError = writePipe;
      startup.hStdInput = GetStdHandle(STD_INPUT_HANDLE);
      PROCESS_INFORMATION process{};
      std::wstring command = Quote(g_loader) + L" " + arguments;
      std::vector<wchar_t> mutableCommand(command.begin(), command.end());
      mutableCommand.push_back(0);
      const BOOL created = CreateProcessW(nullptr, mutableCommand.data(), nullptr, nullptr,
          TRUE, CREATE_NO_WINDOW, nullptr, ModuleDir().c_str(), &startup, &process);
      CloseHandle(writePipe);
      if (!created) {
        CloseHandle(readPipe);
        result->output = L"ERROR: process could not be started (code " +
            std::to_wstring(GetLastError()) + L").\r\n";
      } else {
        std::string bytes;
        char buffer[4096];
        DWORD count = 0;
        while (ReadFile(readPipe, buffer, sizeof(buffer), &count, nullptr) && count) {
          bytes.append(buffer, count);
        }
        CloseHandle(readPipe);
        WaitForSingleObject(process.hProcess, INFINITE);
        GetExitCodeProcess(process.hProcess, &result->exitCode);
        CloseHandle(process.hThread);
        CloseHandle(process.hProcess);
        DecodeOutput(bytes, &result->output);
      }
    }
    if (result->exitCode != 0) allSucceeded = false;
    {
      std::lock_guard<std::mutex> lock(g_queue.mutex);
      g_queue.results.push_back(std::move(result));
    }
    if (g_window) PostMessageW(g_window, kWorkerMessage, 0, 0);
    if (!allSucceeded) break;
  }
  {
    std::lock_guard<std::mutex> lock(g_queue.mutex);
    auto result = std::make_unique<WorkerResult>();
    result->completed = true;
    result->exitCode = allSucceeded ? 0 : 1;
    g_queue.results.push_back(std::move(result));
  }
  if (g_window) PostMessageW(g_window, kWorkerMessage, 0, 0);
}

void RunCommands(std::vector<std::wstring> commands) {
  if (g_busy.exchange(true)) return;
  if (g_loader.empty()) {
    AppendActivity(L"[ERROR] HwidLoader.exe was not found beside the GUI.\r\n");
    SetWindowTextW(g_statusLabel, L"Loader unavailable");
    g_busy = false;
    return;
  }
  const bool verification = std::find(commands.begin(), commands.end(), L"verify") != commands.end();
  const std::wstring first = commands.front();
  const std::wstring name = first == L"verify" ? L"Result verification" :
      first == L"preflight" ? L"Hardware preflight" : first == L"show" ? L"Device inventory" :
      first.rfind(L"rollback", 0) == 0 || first == L"restore" ? L"Restore workflow" :
      first == L"set-value" || first.rfind(L"spoof ", 0) == 0 ? L"Apply selected profile" :
      L"Requested operation";
  const bool expected = first == L"set-value" || first.rfind(L"spoof ", 0) == 0 ||
      first.rfind(L"restore", 0) == 0 || first.rfind(L"rollback", 0) == 0 ||
      first.rfind(L"net-", 0) == 0;
  ResetOperationStages(name, verification, expected);
  if (g_worker.joinable()) g_worker.join();
  SetBusy(true, L"Request in progress");
  AppendActivity(L"\r\n> HwidLoader " + commands.front() + L"\r\n");
  try {
    g_worker = std::thread(WorkerLoop, std::move(commands));
    SetStage(0, StageState::Done, L"Sent");
    SetStage(1, StageState::Active, L"Running");
  } catch (...) {
    AppendActivity(L"[ERROR] Could not start worker thread.\r\n");
    SetStage(0, StageState::Failed, L"Not sent");
    SetStage(1, StageState::Idle, L"Not run");
    SetStage(2, StageState::Warning, L"Not run");
    SetBusy(false, L"Ready");
  }
}

void ParseStatus(const std::wstring& output) {
  const size_t marker = output.find(L"service :");
  if (marker == std::wstring::npos) return;
  const size_t end = output.find(L"\r\n", marker);
  g_service = output.substr(marker, end == std::wstring::npos ? end : end - marker);
  SetWindowTextW(g_serviceLabel, g_service.c_str());
}

void DrainWorkerResults() {
  std::vector<std::unique_ptr<WorkerResult>> results;
  {
    std::lock_guard<std::mutex> lock(g_queue.mutex);
    results.swap(g_queue.results);
  }
  for (const auto& result : results) {
    if (result->completed) {
      if (g_worker.joinable()) g_worker.join();
      const bool success = result->exitCode == 0;
      if (!success && !g_hasVerification && g_stages[1] != StageState::Failed)
        SetStage(1, StageState::Failed, L"Failed");
      if (!success && g_hasVerification && g_stages[2] == StageState::Idle)
        SetStage(2, StageState::Warning, L"Not run");
      SetBusy(false, !success ? L"Operation needs attention" :
          g_verificationPassed ? L"Result verified" :
          g_verificationExpected ? L"Commands completed — verify required" : L"Operation completed");
      AppendActivity(!success ? L"[FAILED] Operation returned an error.\r\n" :
          g_verificationPassed ? L"[VERIFIED] Live state matches the recorded values.\r\n" :
          g_verificationExpected ? L"[DONE] Commands completed; result verification has not been performed.\r\n" :
          L"[DONE] Operation completed.\r\n");
    } else {
      if (!result->output.empty()) AppendActivity(result->output);
      NoteCommandResult(result->command, result->output, result->exitCode);
      if (result->command == L"show") ParseStatus(result->output);
      if (result->command == L"show") RefreshAdapters(result->output);
      if (result->command == L"show" || result->command == L"storage-list") RefreshStorage(result->output);
      if (result->command == L"sessions") {
        SendMessageW(g_sessions, CB_RESETCONTENT, 0, 0);
        std::wistringstream lines(result->output);
        std::wstring line;
        while (std::getline(lines, line)) if (line.rfind(L"SESSION ", 0) == 0) {
          const size_t end = line.find(L" ", 8);
          const std::wstring id = line.substr(8, end - 8);
          SendMessageW(g_sessions, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(id.c_str()));
        }
        if (SendMessageW(g_sessions, CB_GETCOUNT, 0, 0)) SendMessageW(g_sessions, CB_SETCURSEL, 0, 0);
      }
      if (result->command == L"preflight" || result->command == L"verify")
        SetWindowTextW(g_diagnostics, result->output.c_str());
      if (result->command.rfind(L"spoof ", 0) == 0) {
        const size_t marker = result->output.find(L"SESSION ");
        if (marker != std::wstring::npos) {
          const size_t end = result->output.find(L" ", marker + 8);
          g_lastSession = result->output.substr(marker + 8, end - marker - 8);
        }
      }
      if (result->exitCode != 0) {
        AppendActivity(L"[ERROR] Command exit code " + std::to_wstring(result->exitCode) + L"\r\n");
      }
    }
  }
}

std::wstring ProfileDirectory() {
  wchar_t path[MAX_PATH]{};
  DWORD size = MAX_PATH;
  if (!GetEnvironmentVariableW(L"LOCALAPPDATA", path, size)) return L"";
  std::wstring directory = std::wstring(path) + L"\\HwidLab";
  CreateDirectoryW(directory.c_str(), nullptr);
  return directory;
}

bool SafeProfileName(const std::wstring& name) {
  return !name.empty() && name.size() <= 48 &&
      name.find_first_of(L"\\/:*?\"<>|\r\n") == std::wstring::npos;
}

void RefreshProfiles() {
  SendMessageW(g_profiles, CB_RESETCONTENT, 0, 0);
  const std::wstring directory = ProfileDirectory();
  WIN32_FIND_DATAW data{};
  HANDLE find = FindFirstFileW((directory + L"\\*.profile").c_str(), &data);
  if (find != INVALID_HANDLE_VALUE) {
    do {
      std::wstring name = data.cFileName;
      name.resize(name.size() - 8);
      SendMessageW(g_profiles, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(name.c_str()));
    } while (FindNextFileW(find, &data));
    FindClose(find);
  }
  if (!SendMessageW(g_profiles, CB_GETCOUNT, 0, 0)) SendMessageW(g_profiles, CB_SETCURSEL, -1, 0);
}

void SaveProfile() {
  const std::wstring name = WindowText(g_profileName);
  if (!SafeProfileName(name)) {
    MessageBoxW(g_window, L"Enter a short profile name without \\ / : * ? \" < > |.",
                L"Invalid profile name", MB_OK | MB_ICONINFORMATION);
    return;
  }
  std::string bits;
  for (const auto& target : g_targets) bits += target.selected ? L'1' : L'0';
  HANDLE handle = CreateFileW((ProfileDirectory() + L"\\" + name + L".profile").c_str(),
      GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (handle == INVALID_HANDLE_VALUE) {
    AppendActivity(L"[ERROR] Could not save profile.\r\n");
    return;
  }
  DWORD written = 0;
  const BOOL saved = WriteFile(handle, bits.data(), static_cast<DWORD>(bits.size()), &written, nullptr);
  const std::wstring custom = WindowText(g_customValue);
  const int customField = static_cast<int>(SendMessageW(g_customField, CB_GETCURSEL, 0, 0));
  wchar_t customName[64]{};
  SendMessageW(g_customField, CB_GETLBTEXT, std::max(0, customField), reinterpret_cast<LPARAM>(customName));
  DWORD customWritten = 0;
  WriteFile(handle, L"\n", sizeof(wchar_t), &customWritten, nullptr);
  WriteFile(handle, customName, static_cast<DWORD>(wcslen(customName) * sizeof(wchar_t)), &customWritten, nullptr);
  WriteFile(handle, L"=", sizeof(wchar_t), &customWritten, nullptr);
  WriteFile(handle, custom.data(), static_cast<DWORD>(custom.size() * sizeof(wchar_t)), &customWritten, nullptr);
  CloseHandle(handle);
  if (!saved || written != bits.size()) {
    AppendActivity(L"[ERROR] Could not save profile.\r\n");
    return;
  }
  RefreshProfiles();
  const int index = static_cast<int>(SendMessageW(g_profiles, CB_FINDSTRINGEXACT, -1,
                                                  reinterpret_cast<LPARAM>(name.c_str())));
  if (index >= 0) SendMessageW(g_profiles, CB_SETCURSEL, index, 0);
  AppendActivity(L"[PROFILE] Saved '" + name + L"'.\r\n");
}

void LoadProfile() {
  const int selected = static_cast<int>(SendMessageW(g_profiles, CB_GETCURSEL, 0, 0));
  if (selected < 0) return;
  wchar_t name[64]{};
  SendMessageW(g_profiles, CB_GETLBTEXT, selected, reinterpret_cast<LPARAM>(name));
  if (!SafeProfileName(name)) return;
  HANDLE handle = CreateFileW((ProfileDirectory() + L"\\" + name + L".profile").c_str(),
      GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (handle == INVALID_HANDLE_VALUE) return;
  std::string bits;
  char buffer[256];
  DWORD count = 0;
  const BOOL loaded = ReadFile(handle, buffer, sizeof(buffer), &count, nullptr);
  CloseHandle(handle);
  if (loaded) bits.assign(buffer, count);
  const size_t separator = bits.find('\n');
  const std::string selection = bits.substr(0, separator);
  if (selection.size() != g_targets.size() || selection.find_first_not_of("01") != std::string::npos) {
    AppendActivity(L"[ERROR] Profile has an invalid format.\r\n");
    return;
  }
  for (size_t i = 0; i < g_targets.size(); ++i) {
    g_targets[i].selected = selection[i] == '1';
    InvalidateRect(g_targets[i].checkbox, nullptr, FALSE);
  }
  SetWindowTextW(g_profileName, name);
  if (separator != std::string::npos && sizeof(wchar_t) == 2) {
    const std::wstring custom(reinterpret_cast<const wchar_t*>(bits.data() + separator + 1));
    const size_t equals = custom.find(L'=');
    if (equals != std::wstring::npos) {
      const std::wstring field = custom.substr(0, equals);
      const int index = static_cast<int>(SendMessageW(g_customField, CB_FINDSTRINGEXACT, -1,
          reinterpret_cast<LPARAM>(field.c_str())));
      if (index >= 0) SendMessageW(g_customField, CB_SETCURSEL, index, 0);
      SetWindowTextW(g_customValue, custom.substr(equals + 1).c_str());
    }
  }
  UpdateSummary();
  AppendActivity(L"[PROFILE] Loaded '" + std::wstring(name) + L"'.\r\n");
}

void DeleteProfile() {
  const int selected = static_cast<int>(SendMessageW(g_profiles, CB_GETCURSEL, 0, 0));
  if (selected < 0) return;
  wchar_t name[64]{};
  SendMessageW(g_profiles, CB_GETLBTEXT, selected, reinterpret_cast<LPARAM>(name));
  if (!SafeProfileName(name)) return;
  if (MessageBoxW(g_window, L"Delete the selected saved profile?", L"HwidLab profiles",
                  MB_YESNO | MB_ICONQUESTION) == IDYES) {
    DeleteFileW((ProfileDirectory() + L"\\" + name + L".profile").c_str());
    RefreshProfiles();
  }
}

void Move(HWND control, int x, int y, int width, int height) {
  SetWindowPos(control, nullptr, Scale(x), Scale(y), Scale(width), Scale(height),
               SWP_NOZORDER | SWP_NOACTIVATE);
}

void Layout() {
  if (!g_window) return;
  RECT client{};
  GetClientRect(g_window, &client);
  const int width = client.right / static_cast<double>(g_dpi) * 96;
  const int height = client.bottom / static_cast<double>(g_dpi) * 96;
  const int contentX = kPageX;
  const int contentWidth = std::max(480, width - contentX - 28);
  const int pageY = kPageY;
  const int pageHeight = std::max(390, height - pageY - 164);
  Move(GetDlgItem(g_window, 2300), 26, 28, 184, 36);
  Move(GetDlgItem(g_window, 2301), 27, 66, 180, 20);
  Move(GetDlgItem(g_window, 2307), 27, 110, 170, 20);
  for (int i = 0; i < 5; ++i)
    Move(GetDlgItem(g_window, kNavBase + i), 18, 142 + i * 56, 200, 46);
  Move(GetDlgItem(g_window, 2305), 26, height - 84, 184, 20);
  Move(GetDlgItem(g_window, 2306), 26, height - 60, 184, 36);
  Move(g_pageTitle, contentX, 24, contentWidth - 230, 36);
  Move(g_pageSubtitle, contentX, 62, contentWidth - 230, 22);
  Move(g_statusLabel, width - 220, 32, 192, 44);
  Move(g_progress, contentX, 96, contentWidth, 3);
  for (int i = 0; i < 5; ++i)
    Move(g_pages[i], contentX, pageY + (i == g_page ?
        static_cast<int>(kPageSlideDistance * g_pageSlide) : 0), contentWidth, pageHeight);
  Move(g_operationTitle, contentX, height - 148, 300, 24);
  Move(g_operationHint, contentX + 310, height - 146, contentWidth - 310, 22);
  const int stageGap = 12;
  const int stageWidth = (contentWidth - stageGap * 2) / 3;
  for (int i = 0; i < 3; ++i)
    Move(GetDlgItem(g_window, kStageBase + i), contentX + i * (stageWidth + stageGap),
         height - 112, stageWidth, 62);

  const int w = contentWidth, h = pageHeight;
  Move(g_selectionLabel, 0, 0, w - 150, 24);
  Move(GetDlgItem(g_pages[0], kSelectAll), w - 130, -4, 130, 34);
  const int columns = w >= 680 ? 2 : 1;
  const int gap = 14;
  const int cardWidth = (w - gap * (columns - 1)) / columns;
  const int rows = (static_cast<int>(g_targets.size()) + columns - 1) / columns;
  for (size_t i = 0; i < g_targets.size(); ++i) {
    const int x = (i % columns) * (cardWidth + gap);
    const int y = 42 + (i / columns) * 66;
    Move(g_targets[i].checkbox, x, y, cardWidth, 56);
  }
  const int bottom = 42 + rows * 66 + 4;
  Move(GetDlgItem(g_pages[0], 2002), 0, bottom, w, 22);
  Move(g_preview, 0, bottom + 28, w, std::max(76, h - bottom - 86));
  Move(GetDlgItem(g_pages[0], kApply), w - 248, h - 46, 248, 42);
  Move(GetDlgItem(g_pages[0], kRestore), 0, h - 46, 184, 42);

  const int half = (w - 24) / 2, right = half + 24;
  Move(GetDlgItem(g_pages[1], 2101), 0, 0, half, 22);
  Move(g_serviceLabel, 0, 32, half, 26);
  Move(g_loaderLabel, 0, 62, half, 40);
  Move(GetDlgItem(g_pages[1], kInstall), 0, 116, half, 40);
  Move(GetDlgItem(g_pages[1], kStart), 0, 166, (half - 12) / 2, 38);
  Move(GetDlgItem(g_pages[1], kStop), (half + 12) / 2, 166, (half - 12) / 2, 38);
  Move(GetDlgItem(g_pages[1], kRefresh), 0, 214, half, 38);
  Move(GetDlgItem(g_pages[1], 2102), 0, 282, half, 42);
  Move(GetDlgItem(g_pages[1], kClearLogs), 0, 334, half, 42);
  Move(GetDlgItem(g_pages[1], 2103), right, 0, half, 58);
  Move(GetDlgItem(g_pages[1], kResetTpm), right, 70, half, 40);
  Move(GetDlgItem(g_pages[1], 2106), right, 140, half, 22);
  Move(g_vmxPath, right, 170, half, 34);
  Move(g_snapshotName, right, 216, half, 34);
  Move(GetDlgItem(g_pages[1], kVmwareSnapshot), right, 264, (half - 12) / 2, 38);
  Move(GetDlgItem(g_pages[1], kVmwareRevert), right + (half + 12) / 2, 264, (half - 12) / 2, 38);
  Move(GetDlgItem(g_pages[1], 2107), right, 334, half, 22);
  Move(GetDlgItem(g_pages[1], kNdisInstall), right, 366, (half - 12) / 2, 38);
  Move(GetDlgItem(g_pages[1], kNdisRemove), right + (half + 12) / 2, 366, (half - 12) / 2, 38);

  Move(GetDlgItem(g_pages[2], 2401), 0, 0, half, 42);
  Move(g_adapterList, 0, 52, half - 104, 240);
  Move(GetDlgItem(g_pages[2], kAdapterRefresh), half - 94, 52, 94, 34);
  Move(GetDlgItem(g_pages[2], kAdapterMac), 0, 100, (half - 12) / 2, 38);
  Move(GetDlgItem(g_pages[2], kAdapterGuid), (half + 12) / 2, 100, (half - 12) / 2, 38);
  Move(GetDlgItem(g_pages[2], kAdapterRestoreMac), 0, 148, (half - 12) / 2, 38);
  Move(GetDlgItem(g_pages[2], kAdapterRestoreGuid), (half + 12) / 2, 148, (half - 12) / 2, 38);
  Move(GetDlgItem(g_pages[2], 2402), 0, 224, half, 22);
  Move(g_customField, 0, 254, half, 200);
  Move(g_customValue, 0, 298, half, 34);
  Move(GetDlgItem(g_pages[2], kCustomSave), 0, 344, (half - 12) / 2, 38);
  Move(GetDlgItem(g_pages[2], kRegenerate), (half + 12) / 2, 344, (half - 12) / 2, 38);
  Move(GetDlgItem(g_pages[2], 2302), right, 0, half, 22);
  Move(g_profileName, right, 30, half - 110, 34);
  Move(GetDlgItem(g_pages[2], kSaveProfile), right + half - 100, 30, 100, 34);
  Move(g_profiles, right, 76, half, 200);
  Move(GetDlgItem(g_pages[2], kLoadProfile), right, 120, (half - 12) / 2, 36);
  Move(GetDlgItem(g_pages[2], kDeleteProfile), right + (half + 12) / 2, 120, (half - 12) / 2, 36);
  Move(GetDlgItem(g_pages[2], 2403), right, 190, half, 22);
  Move(g_storageList, right, 220, half, 180);
  Move(GetDlgItem(g_pages[2], kStorageSelect), right, 264, (half - 12) / 2, 38);
  Move(GetDlgItem(g_pages[2], kStorageAll), right + (half + 12) / 2, 264, (half - 12) / 2, 38);
  Move(g_sessions, right, 324, half, 140);
  Move(GetDlgItem(g_pages[2], kRollbackSession), right, 368, (half - 12) / 2, 38);
  Move(GetDlgItem(g_pages[2], kRollbackFailed), right + (half + 12) / 2, 368, (half - 12) / 2, 38);

  Move(GetDlgItem(g_pages[3], 2501), 0, 0, w, 40);
  Move(GetDlgItem(g_pages[3], kPreflight), 0, 52, (w - 14) / 2, 42);
  Move(GetDlgItem(g_pages[3], kVerify), (w + 14) / 2, 52, (w - 14) / 2, 42);
  Move(g_diagnostics, 0, 112, w, std::max(180, h - 112));
  Move(GetDlgItem(g_pages[4], 2201), 0, 0, w, 24);
  Move(GetDlgItem(g_pages[4], 2303), w * 2 / 3 + 20, 34, w / 3 - 20, 22);
  Move(g_log, 0, 34, w * 2 / 3, std::max(160, h - 88));
  Move(g_history, w * 2 / 3 + 20, 62, w / 3 - 20, std::max(130, h - 116));
  Move(GetDlgItem(g_pages[4], kCopyLog), 0, h - 42, 124, 38);
  Move(GetDlgItem(g_pages[4], kExportLog), 136, h - 42, 124, 38);
  Move(GetDlgItem(g_pages[4], kClearActivity), w - 124, h - 42, 124, 38);
  InvalidateRect(g_window, nullptr, TRUE);
}

void CreateFonts() {
  auto make = [](int size, int weight, const wchar_t* family) {
    return CreateFontW(-Scale(size), 0, 0, 0, weight, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
        OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
        DEFAULT_PITCH | FF_DONTCARE, family);
  };
  g_font.regular = make(15, FW_NORMAL, L"Segoe UI");
  g_font.medium = make(15, FW_SEMIBOLD, L"Segoe UI");
  g_font.title = make(24, FW_SEMIBOLD, L"Segoe UI");
  g_font.small = make(12, FW_NORMAL, L"Segoe UI");
  g_font.mono = make(13, FW_NORMAL, L"Cascadia Mono");
  g_font.display = make(32, FW_SEMIBOLD, L"Segoe UI");
  g_font.icon = make(12, FW_SEMIBOLD, L"Segoe UI");
}

HWND VisualControl(HWND parent, int id, VisualKind kind, const wchar_t* title,
                   const wchar_t* subtitle = L"", bool primary = false, bool danger = false,
                   const wchar_t* icon = L"") {
  HWND hwnd = Control(SS_OWNERDRAW | SS_NOTIFY | SS_CENTER | WS_TABSTOP,
                      WC_STATICW, title, parent, id);
  Visual visual;
  visual.hwnd = hwnd;
  visual.kind = kind;
  visual.title = title;
  visual.subtitle = subtitle;
  visual.icon = icon;
  visual.primary = primary;
  visual.danger = danger;
  g_visuals.push_back(visual);
  SetWindowSubclass(hwnd, VisualProc, 0, 0);
  return hwnd;
}

void CreateInterface() {
  auto label = [](HWND parent, const wchar_t* text, int id, HFONT font = nullptr) {
    HWND result = Control(SS_LEFT | SS_NOPREFIX, WC_STATICW, text, parent, id);
    SetControlFont(result, font ? font : g_font.regular);
    return result;
  };
  auto button = [](HWND parent, const wchar_t* text, int id, bool primary = false,
                   bool danger = false) {
    return VisualControl(parent, id, VisualKind::Button, text, L"", primary, danger);
  };

  label(g_window, L"HWID / LAB", 2300, g_font.title);
  label(g_window, L"CONTROL CENTER  •  4.0", 2301, g_font.small);
  label(g_window, L"W O R K S P A C E", 2307, g_font.small);
  const wchar_t* nav[] = {L"Identity", L"Drivers", L"Devices", L"Diagnostics", L"Activity"};
  for (int i = 0; i < 5; ++i)
    VisualControl(g_window, kNavBase + i, VisualKind::Nav, nav[i], L"", false, false,
                  (L"0" + std::to_wstring(i + 1)).c_str());
  label(g_window, L"●  LOCAL LAB", 2305, g_font.small);
  label(g_window, L"Owned test systems only\r\nPhysical PC edition", 2306, g_font.small);
  g_pageTitle = label(g_window, L"Identity workspace", 2310, g_font.title);
  g_pageSubtitle = label(g_window, L"", 2311);
  g_statusLabel = Control(SS_RIGHT, WC_STATICW, L"Ready for configuration", g_window, 2304);
  SetControlFont(g_statusLabel, g_font.medium);
  g_progress = Control(PBS_MARQUEE | PBS_SMOOTH, PROGRESS_CLASSW, L"", g_window);
  SendMessageW(g_progress, PBM_SETBARCOLOR, 0, kAccent);
  g_operationTitle = label(g_window, L"No operation running", 2312, g_font.medium);
  g_operationHint = label(g_window, L"Select modules or open Diagnostics to run preflight.", 2313, g_font.small);
  const wchar_t* stages[] = {L"01  REQUESTED", L"02  COMPLETED", L"03  VERIFIED"};
  for (int i = 0; i < 3; ++i)
    VisualControl(g_window, kStageBase + i, VisualKind::Stage, stages[i]);

  // Layered child windows require Windows 8 compatibility in the manifest.
  for (HWND& page : g_pages)
  {
    page = Control(WS_CLIPCHILDREN, L"HwidLabPage", L"", g_window);
    ShowWindow(page, SW_HIDE);
  }

  g_selectionLabel = label(g_pages[0], L"6 / 8 modules enabled", 2001, g_font.medium);
  button(g_pages[0], L"Select all", kSelectAll);
  for (size_t i = 0; i < g_targets.size(); ++i)
    g_targets[i].checkbox = VisualControl(g_pages[0], kTargetBase + static_cast<int>(i),
        VisualKind::Target, g_targets[i].title, g_targets[i].description);
  label(g_pages[0], L"C O M M A N D   P R E V I E W", 2002, g_font.small);
  g_preview = Control(ES_MULTILINE | ES_READONLY | WS_VSCROLL, WC_EDITW, L"", g_pages[0], 0);
  SetControlFont(g_preview, g_font.mono);
  button(g_pages[0], L"Restore originals", kRestore);
  button(g_pages[0], L"Review & apply selected   →", kApply, true);

  label(g_pages[1], L"D R I V E R   S E R V I C E", 2101, g_font.small);
  g_serviceLabel = label(g_pages[1], g_service.c_str(), 2104, g_font.medium);
  g_loaderLabel = label(g_pages[1], L"Loader: searching...", 2105, g_font.small);
  button(g_pages[1], L"Install driver (.sys) and start", kInstall, true);
  button(g_pages[1], L"Start service", kStart);
  button(g_pages[1], L"Stop service", kStop, false, true);
  button(g_pages[1], L"Refresh actual status", kRefresh);
  label(g_pages[1], L"EVENT LOG MAINTENANCE\r\nSeparate explicit action; never runs automatically.", 2102, g_font.small);
  button(g_pages[1], L"Clear selected Windows event logs", kClearLogs, false, true);
  label(g_pages[1], L"HYPER-V vTPM  •  VIRTUAL MACHINES ONLY\r\nPhysical TPM is not modified. Requires a powered-off VM;\r\ncreates a checkpoint and leaves the VM off.", 2103, g_font.small);
  button(g_pages[1], L"Reset Hyper-V vTPM...", kResetTpm);
  label(g_pages[1], L"V M W A R E   W O R K S T A T I O N", 2106, g_font.small);
  g_vmxPath = Control(ES_AUTOHSCROLL, WC_EDITW, L"C:\\VMs\\Test\\Test.vmx", g_pages[1], kVmxPath);
  g_snapshotName = Control(ES_AUTOHSCROLL, WC_EDITW, L"Before-HwidLab", g_pages[1], kSnapshotName);
  button(g_pages[1], L"Create snapshot", kVmwareSnapshot);
  button(g_pages[1], L"Revert snapshot", kVmwareRevert);
  label(g_pages[1], L"N D I S   F I L T E R", 2107, g_font.small);
  button(g_pages[1], L"Install filter", kNdisInstall);
  button(g_pages[1], L"Remove filter", kNdisRemove, false, true);

  label(g_pages[2], L"NETWORK ADAPTER\r\nChanges briefly interrupt connectivity.", 2401, g_font.small);
  g_adapterList = Control(CBS_DROPDOWNLIST | WS_VSCROLL, WC_COMBOBOXW, L"", g_pages[2], kAdapterList);
  button(g_pages[2], L"Refresh", kAdapterRefresh);
  button(g_pages[2], L"Apply MAC", kAdapterMac);
  button(g_pages[2], L"New GUID", kAdapterGuid);
  button(g_pages[2], L"Restore MAC", kAdapterRestoreMac);
  button(g_pages[2], L"Restore GUID", kAdapterRestoreGuid);
  label(g_pages[2], L"C U S T O M   V A L U E", 2402, g_font.small);
  g_customField = Control(CBS_DROPDOWNLIST, WC_COMBOBOXW, L"", g_pages[2], kCustomField);
  for (const wchar_t* name : {L"SmBiosSerial", L"SmBiosManufacturer", L"BiosSerial", L"Uuid",
           L"DiskSerial", L"VolumeId", L"MachineGuid", L"HwProfileId", L"Mac"})
    SendMessageW(g_customField, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(name));
  SendMessageW(g_customField, CB_SETCURSEL, 0, 0);
  g_customValue = Control(ES_AUTOHSCROLL, WC_EDITW, L"", g_pages[2], kCustomValue);
  button(g_pages[2], L"Save value", kCustomSave);
  button(g_pages[2], L"Regenerate next apply", kRegenerate);
  label(g_pages[2], L"S E L E C T I O N   P R O F I L E S", 2302, g_font.small);
  g_profileName = Control(ES_AUTOHSCROLL, WC_EDITW, L"Lab profile", g_pages[2], kProfileName);
  button(g_pages[2], L"Save", kSaveProfile);
  g_profiles = Control(CBS_DROPDOWNLIST | WS_VSCROLL, WC_COMBOBOXW, L"", g_pages[2], kProfiles);
  button(g_pages[2], L"Load profile", kLoadProfile);
  button(g_pages[2], L"Delete", kDeleteProfile, false, true);
  label(g_pages[2], L"P H Y S I C A L   D I S K", 2403, g_font.small);
  g_storageList = Control(CBS_DROPDOWNLIST | WS_VSCROLL, WC_COMBOBOXW, L"", g_pages[2], kStorageList);
  button(g_pages[2], L"Select disk", kStorageSelect);
  button(g_pages[2], L"All disks", kStorageAll);
  g_sessions = Control(CBS_DROPDOWNLIST | WS_VSCROLL, WC_COMBOBOXW, L"", g_pages[2], kSessions);
  button(g_pages[2], L"Rollback selected", kRollbackSession);
  button(g_pages[2], L"Rollback last", kRollbackFailed);

  label(g_pages[3], L"Preflight checks compatibility. Verify compares live values with recorded state.\r\nA completed command is never presented as a verified result.", 2501);
  button(g_pages[3], L"Run preflight checks", kPreflight);
  button(g_pages[3], L"Verify actual result   →", kVerify, true);
  g_diagnostics = Control(ES_MULTILINE | ES_READONLY | WS_VSCROLL, WC_EDITW,
      L"READY FOR PREFLIGHT\r\n\r\nRun preflight before making changes. Verification requires recorded state and an available driver.\r\nPhysical TPM is not modified by this edition.", g_pages[3], 0);
  SetControlFont(g_diagnostics, g_font.mono);

  label(g_pages[4], L"Complete operation output", 2201, g_font.medium);
  g_log = Control(ES_MULTILINE | ES_READONLY | WS_VSCROLL | WS_HSCROLL | ES_AUTOVSCROLL,
                  WC_EDITW, L"", g_pages[4], kLog);
  SendMessageW(g_log, EM_SETLIMITTEXT, 1000000, 0);
  SetControlFont(g_log, g_font.mono);
  label(g_pages[4], L"HISTORY", 2303, g_font.small);
  g_history = Control(LBS_NOINTEGRALHEIGHT | WS_VSCROLL, WC_LISTBOXW, L"", g_pages[4], kHistory);
  SetControlFont(g_history, g_font.small);
  button(g_pages[4], L"Copy all", kCopyLog);
  button(g_pages[4], L"Export .log", kExportLog);
  button(g_pages[4], L"Clear display", kClearActivity);

  BOOL animations = TRUE;
  SystemParametersInfoW(SPI_GETCLIENTAREAANIMATION, 0, &animations, 0);
  g_reduceMotion = !animations;
  EnumChildWindows(g_window, [](HWND child, LPARAM) -> BOOL {
    wchar_t className[24]{};
    GetClassNameW(child, className, static_cast<int>(std::size(className)));
    if (!_wcsicmp(className, L"Edit") || !_wcsicmp(className, L"ComboBox") ||
        !_wcsicmp(className, L"ListBox"))
      SetWindowTheme(child, L"DarkMode_Explorer", nullptr);
    return TRUE;
  }, 0);
  RefreshProfiles();
  UpdateSummary();
  SetPage(0);
}

void InstallDriver() {
  wchar_t path[MAX_PATH]{};
  OPENFILENAMEW dialog{};
  dialog.lStructSize = sizeof(dialog);
  dialog.hwndOwner = g_window;
  dialog.lpstrFilter = L"HwidCore driver (*.sys)\0*.sys\0All files (*.*)\0*.*\0";
  dialog.lpstrFile = path;
  dialog.nMaxFile = MAX_PATH;
  dialog.lpstrTitle = L"Select the built HwidCore.sys";
  dialog.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
  if (GetOpenFileNameW(&dialog)) RunCommands({L"install " + Quote(path), L"start", L"show"});
}

void ResetVirtualTpm() {
  HWND dialog = CreateWindowExW(WS_EX_DLGMODALFRAME, L"HwidLabDialog", L"Reset Hyper-V vTPM",
      WS_POPUP | WS_CAPTION | WS_SYSMENU | WS_VISIBLE, 0, 0, Scale(470), Scale(230), g_window,
      nullptr, GetModuleHandleW(nullptr), nullptr);
  if (!dialog) return;
  EnableWindow(g_window, FALSE);
  RECT owner{};
  GetWindowRect(g_window, &owner);
  SetWindowPos(dialog, nullptr, owner.left + (owner.right - owner.left - Scale(470)) / 2,
      owner.top + (owner.bottom - owner.top - Scale(230)) / 2, 0, 0,
      SWP_NOSIZE | SWP_NOZORDER);
  HWND text = Control(SS_LEFT, WC_STATICW,
      L"Exact powered-off VM name. A checkpoint is created before vTPM rotation:", dialog);
  HWND edit = Control(ES_AUTOHSCROLL, WC_EDITW, L"", dialog, 4000, WS_EX_CLIENTEDGE);
  HWND ok = Control(BS_DEFPUSHBUTTON, WC_BUTTONW, L"Create checkpoint && reset", dialog, IDOK);
  HWND cancel = Control(BS_PUSHBUTTON, WC_BUTTONW, L"Cancel", dialog, IDCANCEL);
  MoveWindow(text, Scale(20), Scale(18), Scale(410), Scale(40), FALSE);
  MoveWindow(edit, Scale(20), Scale(66), Scale(410), Scale(32), FALSE);
  MoveWindow(ok, Scale(20), Scale(115), Scale(260), Scale(36), FALSE);
  MoveWindow(cancel, Scale(292), Scale(115), Scale(138), Scale(36), FALSE);
  SetControlFont(ok, g_font.medium);
  SetFocus(edit);
  MSG message;
  bool accepted = false;
  std::wstring name;
  while (IsWindow(dialog) && GetMessageW(&message, nullptr, 0, 0) > 0) {
    if (message.hwnd == dialog || IsChild(dialog, message.hwnd)) {
      if (message.message == WM_KEYDOWN && message.wParam == VK_ESCAPE) {
        DestroyWindow(dialog);
        break;
      }
      if (message.message == WM_COMMAND && (LOWORD(message.wParam) == IDOK ||
                                            LOWORD(message.wParam) == IDCANCEL)) {
        name = WindowText(edit);
        accepted = LOWORD(message.wParam) == IDOK && !name.empty();
        DestroyWindow(dialog);
        break;
      }
    }
    TranslateMessage(&message);
    DispatchMessageW(&message);
  }
  EnableWindow(g_window, TRUE);
  SetForegroundWindow(g_window);
  if (accepted && MessageBoxW(g_window,
      (L"Create a checkpoint and rotate vTPM for '" + name + L"'?\n\nSave BitLocker recovery keys first. The VM must be powered off and will remain off.").c_str(),
      L"Confirm Hyper-V vTPM reset", MB_YESNO | MB_ICONWARNING) == IDYES) {
    RunCommands({L"tpm " + Quote(name)});
  }
}

void ApplySelected() {
  std::vector<std::wstring> commands;
  std::wstring review;
  const std::wstring custom = WindowText(g_customValue);
  if (!custom.empty()) {
    const int field = static_cast<int>(SendMessageW(g_customField, CB_GETCURSEL, 0, 0));
    wchar_t name[64]{};
    SendMessageW(g_customField, CB_GETLBTEXT, std::max(0, field), reinterpret_cast<LPARAM>(name));
    commands.push_back(L"set-value " + std::wstring(name) + L" " + Quote(custom));
  }
  for (const auto& target : g_targets) {
    if (target.selected) {
      commands.push_back(L"spoof " + std::wstring(target.command));
      review += std::wstring(L"• ") + target.title + L"\r\n";
    }
  }
  if (commands.empty()) {
    MessageBoxW(g_window, L"Select at least one identity module.", L"HwidLab",
                MB_OK | MB_ICONINFORMATION);
    return;
  }
  review += L"\r\nRegistry MAC and adapter GUID operations restart NICs.\r\nBackups are created before changes. Continue?";
  if (MessageBoxW(g_window, review.c_str(), L"Confirm selected operations",
                  MB_YESNO | MB_ICONQUESTION) == IDYES) {
    RunCommands(std::move(commands));
  }
}

void ExportActivity() {
  wchar_t path[MAX_PATH] = L"HwidLab-activity.log";
  OPENFILENAMEW dialog{};
  dialog.lStructSize = sizeof(dialog);
  dialog.hwndOwner = g_window;
  dialog.lpstrFilter = L"Log files (*.log)\0*.log\0All files (*.*)\0*.*\0";
  dialog.lpstrFile = path;
  dialog.nMaxFile = MAX_PATH;
  dialog.lpstrDefExt = L"log";
  dialog.Flags = OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;
  if (!GetSaveFileNameW(&dialog)) return;
  const std::wstring text = WindowText(g_log);
  HANDLE handle = CreateFileW(path, GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS,
                              FILE_ATTRIBUTE_NORMAL, nullptr);
  if (handle == INVALID_HANDLE_VALUE) return;
  const DWORD bom = 0xFEFF;
  DWORD written = 0;
  WriteFile(handle, &bom, sizeof(bom), &written, nullptr);
  const BOOL saved = WriteFile(handle, text.data(), static_cast<DWORD>(text.size() * sizeof(wchar_t)),
                               &written, nullptr);
  CloseHandle(handle);
  if (saved) AppendActivity(L"[EXPORT] Activity saved to " + std::wstring(path) + L"\r\n");
}

void CopyActivity() {
  const std::wstring text = WindowText(g_log);
  if (!OpenClipboard(g_window)) return;
  EmptyClipboard();
  const SIZE_T bytes = (text.size() + 1) * sizeof(wchar_t);
  HGLOBAL memory = GlobalAlloc(GMEM_MOVEABLE, bytes);
  if (memory) {
    void* target = GlobalLock(memory);
    std::copy(text.c_str(), text.c_str() + text.size() + 1, static_cast<wchar_t*>(target));
    GlobalUnlock(memory);
    if (!SetClipboardData(CF_UNICODETEXT, memory)) GlobalFree(memory);
  }
  CloseClipboard();
}

void PaintShell(HWND window) {
  PAINTSTRUCT paint{};
  HDC original = BeginPaint(window, &paint);
  RECT client{};
  GetClientRect(window, &client);
  HDC dc = CreateCompatibleDC(original);
  HBITMAP bitmap = CreateCompatibleBitmap(original, client.right, client.bottom);
  HGDIOBJ oldBitmap = SelectObject(dc, bitmap);
  FillRect(dc, &client, g_backgroundBrush);
  RECT side{0, 0, Scale(236), client.bottom};
  FillRect(dc, &side, g_surfaceBrush);
  HPEN pen = CreatePen(PS_SOLID, 1, kBorder);
  HGDIOBJ oldPen = SelectObject(dc, pen);
  MoveToEx(dc, Scale(235), 0, nullptr);
  LineTo(dc, Scale(235), client.bottom);
  MoveToEx(dc, Scale(260), Scale(103), nullptr);
  LineTo(dc, client.right - Scale(28), Scale(103));
  MoveToEx(dc, Scale(260), client.bottom - Scale(162), nullptr);
  LineTo(dc, client.right - Scale(28), client.bottom - Scale(162));
  SelectObject(dc, oldPen);
  DeleteObject(pen);
  Gdiplus::Graphics graphics(dc);
  Gdiplus::LinearGradientBrush accentLine(
      Gdiplus::Rect(Scale(236), 0, std::max(1, static_cast<int>(client.right) - Scale(236)), Scale(2)),
      GdiColor(kAccent, 0), GdiColor(kCyan, 190), Gdiplus::LinearGradientModeHorizontal);
  graphics.FillRectangle(&accentLine, Gdiplus::Rect(Scale(236), 0,
      std::max(1, static_cast<int>(client.right) - Scale(236)), Scale(2)));
  BitBlt(original, 0, 0, client.right, client.bottom, dc, 0, 0, SRCCOPY);
  SelectObject(dc, oldBitmap);
  DeleteObject(bitmap);
  DeleteDC(dc);
  EndPaint(window, &paint);
}

LRESULT CALLBACK WindowProc(HWND window, UINT message, WPARAM wparam, LPARAM lparam) {
  switch (message) {
    case WM_CREATE:
      g_window = window;
      g_dpi = GetDpiForWindow(window);
      DeleteObject(g_font.regular); DeleteObject(g_font.medium); DeleteObject(g_font.title);
      DeleteObject(g_font.small); DeleteObject(g_font.mono);
      DeleteObject(g_font.display); DeleteObject(g_font.icon);
      CreateFonts();
      g_loader = FindLoader();
      CreateInterface();
      SetWindowTextW(g_loaderLabel, g_loader.empty() ? L"Loader: NOT FOUND beside GUI"
                                                    : (L"Loader: " + g_loader).c_str());
      return 0;
    case WM_SIZE:
      Layout();
      return 0;
    case WM_DPICHANGED: {
      g_dpi = HIWORD(wparam);
      const RECT* suggested = reinterpret_cast<const RECT*>(lparam);
      SetWindowPos(window, nullptr, suggested->left, suggested->top,
          suggested->right - suggested->left, suggested->bottom - suggested->top,
          SWP_NOZORDER | SWP_NOACTIVATE);
      DeleteObject(g_font.regular); DeleteObject(g_font.medium); DeleteObject(g_font.title);
      DeleteObject(g_font.small); DeleteObject(g_font.mono);
      DeleteObject(g_font.display); DeleteObject(g_font.icon);
      CreateFonts();
      EnumChildWindows(window, [](HWND child, LPARAM) -> BOOL {
        SetControlFont(child, g_font.regular);
        const int id = GetDlgCtrlID(child);
        if (id == 2300 || id == 2310) SetControlFont(child, g_font.title);
        if (id == 2001 || id == 2104 || id == 2201 || id == 2304 || id == 2312)
          SetControlFont(child, g_font.medium);
        for (int small : {2002, 2101, 2102, 2103, 2105, 2106, 2107, 2301, 2302,
                          2303, 2305, 2306, 2307, 2313, 2401, 2402, 2403})
          if (id == small) SetControlFont(child, g_font.small);
        return TRUE;
      }, 0);
      SetControlFont(g_log, g_font.mono); SetControlFont(g_preview, g_font.mono);
      SetControlFont(g_diagnostics, g_font.mono);
      SetControlFont(g_history, g_font.small);
      Layout();
      return 0;
    }
    case WM_PAINT:
      PaintShell(window);
      return 0;
    case WM_DRAWITEM:
      PaintVisual(*reinterpret_cast<DRAWITEMSTRUCT*>(lparam));
      return 0;
    case WM_TIMER:
      if (wparam == kAnimationTimer) Animate();
      return 0;
    case WM_GETMINMAXINFO: {
      auto* limits = reinterpret_cast<MINMAXINFO*>(lparam);
      limits->ptMinTrackSize.x = Scale(1120);
      limits->ptMinTrackSize.y = Scale(760);
      return 0;
    }
    case WM_ERASEBKGND:
      return 1;
    case WM_CTLCOLORSTATIC: {
      HDC dc = reinterpret_cast<HDC>(wparam);
      HWND control = reinterpret_cast<HWND>(lparam);
      const int id = GetDlgCtrlID(control);
      const bool content = id >= 2310 || id == 2304;
      HFONT font = reinterpret_cast<HFONT>(SendMessageW(control, WM_GETFONT, 0, 0));
      SetBkColor(dc, content ? kBackground : kSurface);
      SetTextColor(dc, id == 2305 ? kMint :
          (font == g_font.medium || font == g_font.title || font == g_font.display) ? kText : kMuted);
      SetBkMode(dc, TRANSPARENT);
      return reinterpret_cast<LRESULT>(content ? g_backgroundBrush : g_surfaceBrush);
    }
    case WM_CTLCOLOREDIT:
    case WM_CTLCOLORLISTBOX: {
      HDC dc = reinterpret_cast<HDC>(wparam);
      SetBkColor(dc, kCard);
      SetTextColor(dc, kText);
      return reinterpret_cast<LRESULT>(g_cardBrush);
    }
    case WM_COMMAND: {
      const int id = LOWORD(wparam);
      Visual* source = FindVisual(reinterpret_cast<HWND>(lparam));
      if (source && HIWORD(wparam) != STN_CLICKED) return 0;
      if (id >= kNavBase && id < kNavBase + 5) {
        SetPage(id - kNavBase);
      } else if (id >= kTargetBase && id < kTargetBase + 8) {
        auto& target = g_targets[id - kTargetBase];
        target.selected = !target.selected;
        InvalidateRect(target.checkbox, nullptr, FALSE);
        UpdateSummary();
      } else if (id == kSelectAll) {
        const bool all = std::all_of(g_targets.begin(), g_targets.end(), [](const Target& t) { return t.selected; });
        for (auto& target : g_targets) {
          target.selected = !all;
          InvalidateRect(target.checkbox, nullptr, FALSE);
        }
        UpdateSummary();
      } else if (id == kApply) ApplySelected();
      else if (id == kRestore && MessageBoxW(window,
          L"Restore all saved Windows and network adapter values and reset the driver?", L"Confirm restore",
          MB_YESNO | MB_ICONQUESTION) == IDYES) RunCommands({L"restore", L"show"});
      else if (id == kInstall) InstallDriver();
      else if (id == kStart) RunCommands({L"start", L"show"});
      else if (id == kStop && MessageBoxW(window, L"Stop the HwidLab kernel service?", L"HwidLab",
          MB_YESNO | MB_ICONQUESTION) == IDYES) RunCommands({L"stop", L"show"});
      else if (id == kRefresh) RunCommands({L"show"});
      else if (id == kClearLogs && MessageBoxW(window,
          L"Permanently clear Application, Security, Setup and System event logs?\n\nThis is a separate destructive operation and is never run automatically.",
          L"Confirm event log cleanup", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) == IDYES) RunCommands({L"clear-logs"});
      else if (id == kResetTpm) ResetVirtualTpm();
      else if (id == kSaveProfile) SaveProfile();
      else if (id == kLoadProfile) LoadProfile();
      else if (id == kDeleteProfile) DeleteProfile();
      else if (id == kClearActivity) SetWindowTextW(g_log, L"");
      else if (id == kExportLog) ExportActivity();
      else if (id == kCopyLog) CopyActivity();
      else if (id == kPreflight) RunCommands({L"preflight"});
      else if (id == kVerify) RunCommands({L"verify"});
      else if (id == kAdapterRefresh || id == kSessions) RunCommands({L"show", L"sessions"});
      else if (id == kAdapterMac || id == kAdapterGuid || id == kAdapterRestoreMac || id == kAdapterRestoreGuid) {
        const std::wstring adapter = SelectedAdapter();
        if (adapter.empty()) MessageBoxW(window, L"Refresh and select an adapter first.", L"HwidLab", MB_OK);
        else {
          const wchar_t* command = id == kAdapterMac ? L"net-mac " : id == kAdapterGuid ? L"net-guid " :
              id == kAdapterRestoreMac ? L"restore-net-mac " : L"restore-net-guid ";
          RunCommands({command + Quote(adapter)});
        }
      }
      else if (id == kCustomSave) {
        const int field = static_cast<int>(SendMessageW(g_customField, CB_GETCURSEL, 0, 0));
        wchar_t name[64]{};
        SendMessageW(g_customField, CB_GETLBTEXT, std::max(0, field), reinterpret_cast<LPARAM>(name));
        RunCommands({L"set-value " + std::wstring(name) + L" " + Quote(WindowText(g_customValue))});
      }
      else if (id == kRegenerate) RunCommands({L"regenerate"});
      else if (id == kStorageAll) RunCommands({L"storage-select ALL"});
      else if (id == kStorageSelect) {
        const int selected = static_cast<int>(SendMessageW(g_storageList, CB_GETCURSEL, 0, 0));
        if (selected >= 0 && static_cast<size_t>(selected) < g_storagePaths.size())
          RunCommands({L"storage-select " + std::to_wstring(selected)});
      }
      else if (id == kRollbackSession || id == kRollbackFailed) {
        std::wstring session = g_lastSession;
        if (id == kRollbackSession) {
          const int selected = static_cast<int>(SendMessageW(g_sessions, CB_GETCURSEL, 0, 0));
          wchar_t text[128]{};
          SendMessageW(g_sessions, CB_GETLBTEXT, std::max(0, selected), reinterpret_cast<LPARAM>(text));
          const std::wstring row = text;
          const size_t space = row.find(L" ");
          session = row.substr(0, space);
        }
        if (!session.empty()) RunCommands({L"rollback-session " + session});
      }
      else if (id == kVmwareSnapshot || id == kVmwareRevert) {
        RunCommands({std::wstring(id == kVmwareSnapshot ? L"vmware-snapshot " : L"vmware-revert ") +
            Quote(WindowText(g_vmxPath)) + L" " + Quote(WindowText(g_snapshotName))});
      }
      else if (id == kNdisInstall || id == kNdisRemove) {
        RunCommands({id == kNdisInstall ? L"ndis-install" : L"ndis-remove"});
      }
      return 0;
    }
    case kWorkerMessage:
      DrainWorkerResults();
      return 0;
    case kRefreshMessage:
      if (!g_busy) RunCommands({L"show"});
      return 0;
    case WM_CLOSE:
      if (g_busy && MessageBoxW(window, L"An operation is still running. Exit after it finishes?",
          L"HwidLab", MB_YESNO | MB_ICONQUESTION) != IDYES) return 0;
      g_closing = true;
      if (g_worker.joinable()) g_worker.join();
      DestroyWindow(window);
      return 0;
    case WM_DESTROY:
      DrainWorkerResults();
      PostQuitMessage(0);
      return 0;
  }
  return DefWindowProcW(window, message, wparam, lparam);
}

LRESULT CALLBACK PageProc(HWND page, UINT message, WPARAM wparam, LPARAM lparam) {
  if (message == WM_ERASEBKGND) {
    RECT client{};
    GetClientRect(page, &client);
    FillRect(reinterpret_cast<HDC>(wparam), &client, g_backgroundBrush);
    return 1;
  }
  if (message == WM_CTLCOLORSTATIC || message == WM_CTLCOLOREDIT || message == WM_CTLCOLORLISTBOX) {
    HDC dc = reinterpret_cast<HDC>(wparam);
    SetBkColor(dc, message == WM_CTLCOLORSTATIC ? kBackground : kCard);
    HFONT font = reinterpret_cast<HFONT>(SendMessageW(reinterpret_cast<HWND>(lparam), WM_GETFONT, 0, 0));
    SetTextColor(dc, message != WM_CTLCOLORSTATIC || font == g_font.medium || font == g_font.title ? kText : kMuted);
    return reinterpret_cast<LRESULT>(message == WM_CTLCOLORSTATIC ? g_backgroundBrush : g_cardBrush);
  }
  if (message == WM_COMMAND || message == WM_NOTIFY || message == WM_DRAWITEM)
    return SendMessageW(g_window, message, wparam, lparam);
  return DefWindowProcW(page, message, wparam, lparam);
}

}  // namespace

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int show) {
  Gdiplus::GdiplusStartupInput gdiplusInput;
  if (Gdiplus::GdiplusStartup(&g_gdiplus, &gdiplusInput, nullptr) != Gdiplus::Ok) return 1;
  INITCOMMONCONTROLSEX controls{sizeof(controls), ICC_STANDARD_CLASSES | ICC_TAB_CLASSES | ICC_PROGRESS_CLASS};
  InitCommonControlsEx(&controls);
  g_dpi = GetDpiForSystem();
  g_backgroundBrush = CreateSolidBrush(kBackground);
  g_surfaceBrush = CreateSolidBrush(kSurface);
  g_cardBrush = CreateSolidBrush(kCard);
  CreateFonts();
  WNDCLASSEXW wc{};
  wc.cbSize = sizeof(wc);
  wc.hInstance = instance;
  wc.lpfnWndProc = WindowProc;
  wc.lpszClassName = L"HwidLabControlCenter";
  wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
  wc.hIcon = LoadIcon(nullptr, IDI_APPLICATION);
  RegisterClassExW(&wc);
  wc.lpfnWndProc = PageProc;
  wc.lpszClassName = L"HwidLabPage";
  wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
  wc.hbrBackground = g_backgroundBrush;
  RegisterClassExW(&wc);
  wc.lpszClassName = L"HwidLabDialog";
  RegisterClassExW(&wc);
  HWND window = CreateWindowExW(0, L"HwidLabControlCenter", L"HwidLab — Control Center",
      WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN, CW_USEDEFAULT, CW_USEDEFAULT, Scale(1380), Scale(900),
      nullptr, nullptr, instance, nullptr);
  if (!window) return 1;
  ShowWindow(window, show);
  UpdateWindow(window);
  AppendActivity(L"[READY] HwidLab Control Center started. Select modules or refresh driver status.\r\n");
  PostMessageW(window, kRefreshMessage, 0, 0);
  MSG message;
  while (GetMessageW(&message, nullptr, 0, 0) > 0) {
    if (!IsDialogMessageW(window, &message)) {
      TranslateMessage(&message);
      DispatchMessageW(&message);
    }
  }
  DeleteObject(g_font.regular); DeleteObject(g_font.medium); DeleteObject(g_font.title);
  DeleteObject(g_font.small); DeleteObject(g_font.mono);
  DeleteObject(g_font.display); DeleteObject(g_font.icon);
  DeleteObject(g_backgroundBrush); DeleteObject(g_surfaceBrush); DeleteObject(g_cardBrush);
  Gdiplus::GdiplusShutdown(g_gdiplus);
  return static_cast<int>(message.wParam);
}
