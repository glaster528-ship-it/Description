#pragma once

#include "HwidProtocol.h"
#include "util.h"

namespace hwid {

// Opens \\.\HwidLab with read/write access; returns false when the driver is
// not installed or not started.
bool OpenHwidDevice(UniqueWinHandle& out);
bool SendSetConfig(HANDLE device, const HwidConfig& config);
bool GetHwidConfig(HANDLE device, HwidConfig* config);
bool SendRestore(HANDLE device);

}  // namespace hwid
