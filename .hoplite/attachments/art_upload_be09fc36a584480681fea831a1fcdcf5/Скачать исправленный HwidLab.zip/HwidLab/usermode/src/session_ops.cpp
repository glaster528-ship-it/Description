#include "session_ops.h"

#include "registry_ops.h"
#include "device_io.h"
#include "network_ops.h"
#include "util.h"

#include <windows.h>

#include <cstdio>
#include <iostream>
#include <string>
#include <vector>

namespace hwid {
namespace {

std::wstring SessionKey(const char* id) {
  return std::wstring(kStateKey) + L"\\Sessions\\" + Widen(id);
}

std::wstring HexEncode(const std::wstring& raw) {
  const auto* bytes = reinterpret_cast<const unsigned char*>(raw.data());
  const size_t count = raw.size() * sizeof(wchar_t);
  std::wstring result(count * 2, L'0');
  for (size_t i = 0; i < count; ++i) swprintf_s(&result[i * 2], 3, L"%02X", bytes[i]);
  return result;
}

bool HexDecode(const std::wstring& text, std::vector<unsigned char>* bytes) {
  if (text.size() % 2) return false;
  bytes->resize(text.size() / 2);
  for (size_t i = 0; i < bytes->size(); ++i) {
    wchar_t pair[3] = {text[i * 2], text[i * 2 + 1], 0};
    wchar_t* end = nullptr;
    const unsigned long value = wcstoul(pair, &end, 16);
    if (!end || *end) return false;
    (*bytes)[i] = static_cast<unsigned char>(value);
  }
  return true;
}

}  // namespace

void RecordSession(const char* target, bool driver, bool machineGuid, bool hwProfile,
                   const std::wstring& previousDriver, const std::wstring& networkId,
                   bool networkMac, bool networkGuid) {
  char id[40]{};
  static LONG sequence = 0;
  FILETIME time{};
  GetSystemTimeAsFileTime(&time);
  const unsigned long long stamp =
      ((static_cast<unsigned long long>(time.dwHighDateTime) << 32) | time.dwLowDateTime) / 10000ULL;
  std::snprintf(id, sizeof(id), "%llu%03u", stamp,
                static_cast<unsigned>(InterlockedIncrement(&sequence) % 1000));
  const std::wstring key = SessionKey(id);
  WriteSz(key.c_str(), L"Target", Widen(target));
  WriteQword(key.c_str(), L"Driver", driver ? 1 : 0);
  WriteQword(key.c_str(), L"MachineGuid", machineGuid ? 1 : 0);
  WriteQword(key.c_str(), L"HwProfile", hwProfile ? 1 : 0);
  WriteSz(key.c_str(), L"DriverConfigHex", HexEncode(previousDriver));
  WriteSz(key.c_str(), L"NetworkId", networkId);
  WriteQword(key.c_str(), L"NetworkMac", networkMac ? 1 : 0);
  WriteQword(key.c_str(), L"NetworkGuid", networkGuid ? 1 : 0);
  std::cout << "SESSION " << id << " target=" << target << "\n";
}

int RunSessionList() {
  HKEY raw = nullptr;
  if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, (std::wstring(kStateKey) + L"\\Sessions").c_str(),
                    0, KEY_READ, &raw) != ERROR_SUCCESS) {
    std::cout << "No recorded apply sessions\n";
    return 0;
  }
  UniqueRegKey key(raw);
  for (DWORD i = 0;; ++i) {
    wchar_t id[64]{};
    DWORD length = static_cast<DWORD>(std::size(id));
    if (RegEnumKeyExW(key.get(), i, id, &length, nullptr, nullptr, nullptr, nullptr) != ERROR_SUCCESS) break;
    std::wstring target;
    ReadSz(HKEY_LOCAL_MACHINE, SessionKey(Narrow(id).c_str()).c_str(), L"Target", &target);
    std::wcout << L"SESSION " << id << L" target=" << target << L"\n";
  }
  return 0;
}

int RunSessionRollback(const char* id) {
  if (!RequireElevated() || !id) return 1;
  for (const char* c = id; *c; ++c) if (*c < '0' || *c > '9') return 1;
  const std::wstring key = SessionKey(id);
  unsigned long long driver = 0, guid = 0, profile = 0;
  if (!ReadQword(HKEY_LOCAL_MACHINE, key.c_str(), L"Driver", &driver) &&
      !ReadQword(HKEY_LOCAL_MACHINE, key.c_str(), L"MachineGuid", &guid) &&
      !ReadQword(HKEY_LOCAL_MACHINE, key.c_str(), L"HwProfile", &profile)) {
    std::cerr << "[!] Session not found\n";
    return 1;
  }
  int rc = 0;
  unsigned long long networkMac = 0, networkGuid = 0;
  ReadQword(HKEY_LOCAL_MACHINE, key.c_str(), L"NetworkMac", &networkMac);
  ReadQword(HKEY_LOCAL_MACHINE, key.c_str(), L"NetworkGuid", &networkGuid);
  if (networkMac || networkGuid) {
    std::wstring id;
    ReadSz(HKEY_LOCAL_MACHINE, key.c_str(), L"NetworkId", &id);
    if (networkMac && RunNetworkRestore(NetworkTarget::Mac, id) != 0) rc = 1;
    if (networkGuid && RunNetworkRestore(NetworkTarget::InstanceGuid, id) != 0) rc = 1;
  }
  if (guid) {
    const auto result = RestoreString(kMachineGuidKey, kMachineGuidValue);
    if (result == RestoreResult::Error) rc = 1;
  }
  if (profile) {
    const auto result = RestoreString(kHwProfileKey, kHwProfileValue);
    if (result == RestoreResult::Error) rc = 1;
  }
  if (driver) {
    UniqueWinHandle device;
    std::wstring raw;
    std::vector<unsigned char> config;
    if (!ReadSz(HKEY_LOCAL_MACHINE, key.c_str(), L"DriverConfigHex", &raw) ||
        !HexDecode(raw, &config) || config.size() != sizeof(HwidConfig) ||
        !OpenHwidDevice(device) ||
        !SendSetConfig(device.get(), *reinterpret_cast<const HwidConfig*>(config.data()))) {
      std::cerr << "[!] Could not restore the previous driver configuration\n";
      rc = 1;
    }
  }
  if (!rc) {
    RegDeleteTreeW(HKEY_LOCAL_MACHINE, key.c_str());
    std::cout << "[+] Session rolled back\n";
  }
  return rc;
}

}  // namespace hwid
