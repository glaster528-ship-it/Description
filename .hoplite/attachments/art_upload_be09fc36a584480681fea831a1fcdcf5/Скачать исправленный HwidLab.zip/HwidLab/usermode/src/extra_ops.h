#pragma once

#include <string>

namespace hwid {

int RunClearEventLogs();
int RunResetVirtualTpm(const std::wstring& vmName);
int RunVmwareSnapshot(const std::wstring& vmx, const std::wstring& name, bool revert);
int RunHyperVCheckpoint(const std::wstring& vmName, const std::wstring& name, bool revert);
int RunNdisSetup(bool install);

}  // namespace hwid
