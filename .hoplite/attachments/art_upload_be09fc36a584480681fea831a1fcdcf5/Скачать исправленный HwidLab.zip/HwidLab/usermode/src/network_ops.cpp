#include "network_ops.h"

#include "registry_ops.h"
#include "identity_values.h"
#include "session_ops.h"
#include "util.h"

#include <cfgmgr32.h>
#include <bcrypt.h>
#include <objbase.h>

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <iostream>
#include <string>
#include <vector>

namespace hwid {
namespace {

constexpr wchar_t kClassKey[] =
    L"SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e972-e325-11ce-bfc1-08002be10318}";
constexpr wchar_t kMacState[] = L"NetworkMacCount";
constexpr wchar_t kGuidState[] = L"NetworkGuidCount";

struct Adapter {
  std::wstring subkey;
  std::wstring instanceId;
  std::wstring deviceId;
  std::wstring description;
};

bool IsGuid(const std::wstring& value) {
  CLSID id{};
  return SUCCEEDED(CLSIDFromString(value.c_str(), &id));
}

std::vector<Adapter> EnumerateAdapters() {
  std::vector<Adapter> result;
  HKEY rawRoot = nullptr;
  if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, kClassKey, 0, KEY_READ, &rawRoot) !=
      ERROR_SUCCESS) {
    ReportWinError("open network adapter class key");
    return result;
  }
  UniqueRegKey root(rawRoot);
  for (DWORD index = 0;; ++index) {
    wchar_t name[256];
    DWORD size = static_cast<DWORD>(std::size(name));
    const LONG error = RegEnumKeyExW(root.get(), index, name, &size, nullptr, nullptr,
                                     nullptr, nullptr);
    if (error == ERROR_NO_MORE_ITEMS) break;
    if (error != ERROR_SUCCESS) continue;
    Adapter adapter;
    adapter.subkey = std::wstring(kClassKey) + L"\\" + name;
    if (!ReadSz(HKEY_LOCAL_MACHINE, adapter.subkey.c_str(), L"NetCfgInstanceId",
                &adapter.instanceId) ||
        !IsGuid(adapter.instanceId) ||
        !ReadSz(HKEY_LOCAL_MACHINE, adapter.subkey.c_str(), L"MatchingDeviceId",
                &adapter.deviceId) ||
        _wcsnicmp(adapter.deviceId.c_str(), L"root\\", 5) == 0) {
      continue;
    }
    ReadSz(HKEY_LOCAL_MACHINE, adapter.subkey.c_str(), L"DriverDesc", &adapter.description);
    if (adapter.description.empty()) adapter.description = adapter.deviceId;
    result.push_back(std::move(adapter));
  }
  return result;
}

std::wstring BackupName(const wchar_t* value, const std::wstring& id) {
  return std::wstring(value) + L"@" + id;
}

std::wstring StableId(const Adapter& adapter) {
  return adapter.subkey.substr(adapter.subkey.find_last_of(L'\\') + 1);
}

std::wstring NewGuid() {
  GUID guid{};
  if (FAILED(CoCreateGuid(&guid))) return L"";
  wchar_t text[40]{};
  if (!StringFromGUID2(guid, text, static_cast<int>(std::size(text)))) return L"";
  return text;
}

std::wstring NewMac(const std::wstring& custom) {
  if (!custom.empty()) return custom;
  unsigned char bytes[6]{};
  const NTSTATUS status = BCryptGenRandom(nullptr, bytes, sizeof(bytes),
                                          BCRYPT_USE_SYSTEM_PREFERRED_RNG);
  if (status < 0) {
    ReportWinError("BCryptGenRandom");
    return L"";
  }
  bytes[0] = static_cast<unsigned char>((bytes[0] & 0xFE) | 0x02);
  wchar_t text[13]{};
  swprintf_s(text, L"%02X%02X%02X%02X%02X%02X", bytes[0], bytes[1], bytes[2],
             bytes[3], bytes[4], bytes[5]);
  return text;
}

bool RestartAdapter(const Adapter& adapter) {
  DEVINST device = 0;
  CONFIGRET result = CM_Locate_DevNodeW(&device,
      const_cast<DEVINSTID_W>(adapter.deviceId.c_str()), CM_LOCATE_DEVNODE_NORMAL);
  if (result != CR_SUCCESS) {
    std::cerr << "[!] Cannot locate adapter " << Narrow(adapter.description)
              << " (CM error " << result << ")\n";
    return false;
  }
  ULONG status = 0, problem = 0;
  if (CM_Get_DevNode_Status(&status, &problem, device, 0) == CR_SUCCESS &&
      !(status & DN_STARTED)) {
    std::cout << "[i] Adapter is not started; registry value will be read on next start\n";
    return true;
  }
  result = CM_Disable_DevNode(device, 0);
  if (result != CR_SUCCESS) {
    std::cerr << "[!] Cannot disable adapter (CM error " << result << ")\n";
    return false;
  }
  result = CM_Enable_DevNode(device, 0);
  if (result != CR_SUCCESS) {
    std::cerr << "[!] Cannot re-enable adapter (CM error " << result
              << "); re-enable it in Device Manager\n";
    return false;
  }
  return true;
}

void PrintAdapter(const Adapter& adapter) {
  std::wstring mac, guid;
  ReadSz(HKEY_LOCAL_MACHINE, adapter.subkey.c_str(), L"NetworkAddress", &mac);
  ReadSz(HKEY_LOCAL_MACHINE, adapter.subkey.c_str(), L"NetCfgInstanceId", &guid);
  std::cout << "  " << Narrow(adapter.description) << "\n"
            << "    device : " << Narrow(adapter.deviceId) << "\n"
            << "    guid   : " << Narrow(guid) << "\n"
            << "    mac    : " << (mac.empty() ? "(hardware default)" : Narrow(mac)) << "\n";
}

}  // namespace

int RunNetworkSpoof(NetworkTarget target, const std::wstring& adapterId) {
  if (!RequireElevated()) return 1;
  const auto adapters = EnumerateAdapters();
  if (adapters.empty()) {
    std::cerr << "[!] No supported physical network adapters found\n";
    return 1;
  }
  const wchar_t* value = target == NetworkTarget::Mac ? L"NetworkAddress" : L"NetCfgInstanceId";

  // Complete every backup before changing any adapter.
  const std::wstring selected = adapterId.empty() ? L"" : NormalizeMac(adapterId);
  auto matches = [&](const Adapter& adapter) {
    return selected.empty() || NormalizeMac(adapter.instanceId) == selected;
  };
  if (!selected.empty() && std::none_of(adapters.begin(), adapters.end(), matches)) {
    std::cerr << "[!] Selected network adapter was not found\n";
    return 1;
  }
  for (const auto& adapter : adapters) {
    if (!matches(adapter)) continue;
    const std::wstring backup = BackupName(value, StableId(adapter));
    if (!BackupString(adapter.subkey.c_str(), value, backup.c_str())) {
      ReportWinError("back up network adapter");
      return 1;
    }
  }

  int changed = 0;
  std::wstring custom;
  if (target == NetworkTarget::Mac) ReadIdentityValue(L"Mac", &custom);
  if (!custom.empty()) custom = NormalizeMac(custom);
  for (const auto& adapter : adapters) {
    if (!matches(adapter)) continue;
    const std::wstring replacement = target == NetworkTarget::Mac ? NewMac(custom) : NewGuid();
    if (replacement.empty()) return 1;
    std::cout << "[+] " << Narrow(adapter.description) << " -> " << Narrow(replacement) << "\n";
    if (!WriteSz(adapter.subkey.c_str(), value, replacement)) {
      ReportWinError("write network adapter identity");
      return 1;
    }
    ++changed;
    if (!RestartAdapter(adapter)) {
      std::cerr << "[!] Registry was changed but adapter restart failed\n";
      return 1;
    }
    std::wstring rollbackId = adapter.instanceId;
    if (target == NetworkTarget::InstanceGuid)
      ReadSz(HKEY_LOCAL_MACHINE, adapter.subkey.c_str(), L"NetCfgInstanceId", &rollbackId);
    RecordSession(target == NetworkTarget::Mac ? "NETMAC" : "NETGUID", false, false, false,
                  L"", rollbackId, target == NetworkTarget::Mac, target == NetworkTarget::InstanceGuid);
  }
  WriteQword(kStateKey, target == NetworkTarget::Mac ? kMacState : kGuidState, changed);
  std::cout << "[+] Updated " << changed << " adapter(s); reboot if a driver caches its identity\n";
  return 0;
}

int RunNetworkRestore() {
  if (!RequireElevated()) return 1;
  const auto adapters = EnumerateAdapters();
  int restored = 0, errors = 0;
  for (const auto& adapter : adapters) {
    bool touched = false;
    for (const wchar_t* value : {L"NetworkAddress", L"NetCfgInstanceId"}) {
      const std::wstring backup = BackupName(value, StableId(adapter));
      const RestoreResult result = RestoreString(adapter.subkey.c_str(), value, backup.c_str());
      if (result == RestoreResult::Error) {
        ReportWinError("restore network adapter");
        ++errors;
      } else if (result == RestoreResult::Restored) {
        touched = true;
      }
    }
    if (touched) {
      ++restored;
      std::cout << "[+] Restored " << Narrow(adapter.description) << "\n";
      RestartAdapter(adapter);
    }
  }
  if (!restored && !errors) std::cout << "[i] No network adapter backups found\n";
  if (restored && !errors) ClearNetworkState();
  return errors ? 1 : 0;
}

int RunNetworkRestore(NetworkTarget target, const std::wstring& adapterId) {
  if (!RequireElevated()) return 1;
  const wchar_t* value = target == NetworkTarget::Mac ? L"NetworkAddress" : L"NetCfgInstanceId";
  const std::wstring wanted = NormalizeMac(adapterId);
  for (const auto& adapter : EnumerateAdapters()) {
    if (NormalizeMac(adapter.instanceId) != wanted) continue;
    const std::wstring backup = BackupName(value, StableId(adapter));
    const RestoreResult result = RestoreString(adapter.subkey.c_str(), value, backup.c_str());
    if (result == RestoreResult::NoBackup) {
      std::cerr << "[!] No backup for the selected adapter\n";
      return 1;
    }
    if (result == RestoreResult::Error || !RestartAdapter(adapter)) return 1;
    std::cout << "[+] Restored selected network adapter\n";
    return 0;
  }
  std::cerr << "[!] Selected network adapter was not found\n";
  return 1;
}

void PrintNetworkStatus() {
  const auto adapters = EnumerateAdapters();
  std::cout << "\nnetwork adapters (" << adapters.size() << "):\n";
  for (const auto& adapter : adapters) PrintAdapter(adapter);
}

void ClearNetworkState() {
  DeleteValue(kStateKey, kMacState);
  DeleteValue(kStateKey, kGuidState);
}

}  // namespace hwid
