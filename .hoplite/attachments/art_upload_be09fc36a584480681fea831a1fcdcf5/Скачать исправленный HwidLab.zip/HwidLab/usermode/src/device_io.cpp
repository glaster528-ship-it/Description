#include "device_io.h"

#include "util.h"

namespace hwid {

bool OpenHwidDevice(UniqueWinHandle& out) {
  HANDLE raw = CreateFileW(HWID_DEVICE_DOS_NAME, GENERIC_READ | GENERIC_WRITE, 0,
                           nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
  if (raw == INVALID_HANDLE_VALUE) return false;
  out.reset(raw);
  return true;
}

bool SendSetConfig(HANDLE device, const HwidConfig& config) {
  HwidConfig reply{};
  DWORD returned = 0;
  if (!DeviceIoControl(device, IOCTL_HWID_SET_CONFIG,
                       const_cast<HwidConfig*>(&config), sizeof(config), &reply,
                       sizeof(reply), &returned, nullptr)) {
    return false;
  }
  return returned == sizeof(reply);
}

bool GetHwidConfig(HANDLE device, HwidConfig* config) {
  DWORD returned = 0;
  return config && DeviceIoControl(device, IOCTL_HWID_GET_CONFIG, nullptr, 0, config,
                                   sizeof(*config), &returned, nullptr) &&
      returned == sizeof(*config);
}

bool SendRestore(HANDLE device) {
  HwidRestoreRequest request{};
  HwidConfig reply{};
  request.Magic = HWID_CONFIG_MAGIC;
  request.Version = HWID_CONFIG_VERSION;
  request.StructSize = sizeof(request);
  DWORD returned = 0;
  if (!DeviceIoControl(device, IOCTL_HWID_RESTORE, &request, sizeof(request), &reply,
                       sizeof(reply), &returned, nullptr)) {
    return false;
  }
  return returned == sizeof(reply);
}

}  // namespace hwid
