#include "diagnostics.h"

#include "device_io.h"
#include "identity_values.h"
#include "registry_ops.h"
#include "storage_ops.h"
#include "util.h"

#include <windows.h>
#include <bcrypt.h>
#include <objbase.h>

#include <array>
#include <algorithm>
#include <cctype>
#include <iostream>
#include <string>

namespace hwid {
namespace {

void Check(const wchar_t* name, bool ok, const std::wstring& detail) {
  std::wcout << L"CHECK " << name << L"=" << (ok ? L"PASS" : L"FAIL")
             << L" | " << detail << L"\n";
}

bool ReadOS(RTL_OSVERSIONINFOW* info) {
  using Function = LONG(WINAPI*)(PRTL_OSVERSIONINFOW);
  auto function = reinterpret_cast<Function>(reinterpret_cast<ULONG_PTR>(
      GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "RtlGetVersion")));
  if (!function) return false;
  info->dwOSVersionInfoSize = sizeof(*info);
  return function(info) == 0;
}

bool TestSigningEnabled() {
  struct CodeIntegrityInfo { ULONG size; ULONG options; };
  CodeIntegrityInfo info{sizeof(info), 0};
  using Function = LONG(NTAPI*)(ULONG, PVOID, ULONG, PULONG);
  auto function = reinterpret_cast<Function>(reinterpret_cast<ULONG_PTR>(
      GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "NtQuerySystemInformation")));
  return function && function(103, &info, sizeof(info), nullptr) >= 0 && (info.options & 0x02) != 0;
}

std::wstring Virtualization() {
  std::wstring model;
  ReadSz(HKEY_LOCAL_MACHINE, L"HARDWARE\\DESCRIPTION\\System\\BIOS", L"SystemProductName", &model);
  if (model.empty()) return L"unknown";
  return model;
}

}  // namespace

int RunPreflight() {
  std::wcout << L"PREFLIGHT BEGIN\n";
  RTL_OSVERSIONINFOW os{};
  const bool osOk = ReadOS(&os) && os.dwMajorVersion >= 10 && sizeof(void*) == 8;
  Check(L"windows", osOk, L"Windows 10/11 x64; detected " + std::to_wstring(os.dwMajorVersion) +
       L"." + std::to_wstring(os.dwMinorVersion) + L" build " + std::to_wstring(os.dwBuildNumber));
  Check(L"administrator", IsElevated(), IsElevated() ? L"elevated" : L"restart as administrator");
  const std::wstring vm = Virtualization();
  Check(L"physical-pc", vm.find(L"VMware") == std::wstring::npos && vm.find(L"Virtual") == std::wstring::npos, vm);
  Check(L"test-signing", TestSigningEnabled(), TestSigningEnabled() ? L"enabled" : L"disabled or query denied");
  UniqueSvcHandle scm(OpenSCManagerW(nullptr, nullptr, SC_MANAGER_CONNECT));
  UniqueSvcHandle service;
  SERVICE_STATUS status{};
  bool installed = false, running = false;
  if (scm.valid()) {
    service.reset(OpenServiceW(scm.get(), HWID_SERVICE_NAME, SERVICE_QUERY_STATUS));
    installed = service.valid() && QueryServiceStatus(service.get(), &status);
    running = installed && status.dwCurrentState == SERVICE_RUNNING;
  }
  Check(L"core-service", installed, installed ? L"installed" : L"not installed");
  Check(L"core-running", running, running ? L"running" : L"not running");
  UniqueWinHandle device;
  const bool accessible = OpenHwidDevice(device);
  Check(L"core-device", accessible, accessible ? L"IOCTL device accessible" : L"device not available");
  SYSTEM_INFO system{};
  GetSystemInfo(&system);
  Check(L"architecture", system.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64,
        system.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64 ? L"x64" : L"not x64");
  std::wcout << L"NOTE Secure Boot/HVCI/VBS must be assessed before enabling the optional SMBIOS hook.\n";
  BOOL secureBoot = FALSE;
  Check(L"secure-boot", !GetFirmwareEnvironmentVariableW(L"SecureBoot",
          L"{fallladiesarea}", &secureBoot, sizeof(secureBoot)) || !secureBoot,
          secureBoot ? L"enabled" : L"disabled or not reported");
  unsigned long long vbs = 0, hvci = 0;
  ReadQword(HKEY_LOCAL_MACHINE, L"SYSTEM\\CurrentControlSet\\Control\\DeviceGuard",
            L"EnableVirtualizationBasedSecurity", &vbs);
  ReadQword(HKEY_LOCAL_MACHINE,
            L"SYSTEM\\CurrentControlSet\\Control\\DeviceGuard\\Scenarios\\HypervisorEnforcedCodeIntegrity",
            L"Enabled", &hvci);
  Check(L"vbs", vbs == 0, vbs ? L"enabled; optional kernel hook is not supported" : L"not reported enabled");
  Check(L"hvci", hvci == 0, hvci ? L"enabled; optional kernel hook is not supported" : L"not reported enabled");
  std::wcout << L"NOTE BitLocker was not queried. Save recovery keys before any TPM change.\n";
  std::wstring manufacturer, product, bios;
  ReadSz(HKEY_LOCAL_MACHINE, L"HARDWARE\\DESCRIPTION\\System\\BIOS", L"SystemManufacturer", &manufacturer);
  ReadSz(HKEY_LOCAL_MACHINE, L"HARDWARE\\DESCRIPTION\\System\\BIOS", L"SystemProductName", &product);
  ReadSz(HKEY_LOCAL_MACHINE, L"HARDWARE\\DESCRIPTION\\System\\BIOS", L"BIOSVersion", &bios);
  std::wcout << L"HARDWARE board=" << manufacturer << L" " << product << L" bios=" << bios << L"\n";
  std::wcout << L"PREFLIGHT END\n";
  PrintStorageStatus();
  return osOk && IsElevated() ? 0 : 1;
}

int RunVerify() {
  std::wcout << L"VERIFY BEGIN\n";
  int failures = 0;
  UniqueWinHandle device;
  if (!OpenHwidDevice(device)) {
    std::wcout << L"VERIFY driver=NOT_AVAILABLE | no live configuration\n";
    ++failures;
  } else {
    HwidConfig config{};
    if (!GetHwidConfig(device.get(), &config)) {
      std::wcout << L"VERIFY driver=ERROR | IOCTL_GET_CONFIG failed\n";
      ++failures;
    } else {
      auto compare = [&](const wchar_t* module, const char* actual, const wchar_t* state) {
        std::wstring expected;
        ReadSz(HKEY_LOCAL_MACHINE, kStateKey, state, &expected);
        const bool pass = !expected.empty() && expected == Widen(actual);
        std::wcout << L"VERIFY " << module << L"=" << (pass ? L"MATCH" : L"DIFF")
                   << L" | recorded=" << expected << L" live=" << Widen(actual) << L"\n";
        if (!pass) ++failures;
      };
      if (config.Flags & HWID_SPOOF_DISK) compare(L"disk", config.DiskSerial, L"DiskSerial");
      if (config.Flags & HWID_SPOOF_VOLUME) compare(L"volume", config.VolumeId, L"VolumeId");
      if (config.Flags & HWID_SPOOF_SMBIOS) compare(L"smbios", config.SmBiosSerial, L"SmBiosSerial");
      std::wcout << L"VERIFY driver=READ | flags=" << config.Flags << L"\n";
    }
  }
  auto registryCheck = [&](const wchar_t* module, const wchar_t* key, const wchar_t* value,
                           const wchar_t* state) {
    std::wstring expected, actual;
    ReadSz(HKEY_LOCAL_MACHINE, kStateKey, state, &expected);
    ReadSz(HKEY_LOCAL_MACHINE, key, value, &actual);
    const bool pass = !expected.empty() && expected == actual;
    std::wcout << L"VERIFY " << module << L"=" << (pass ? L"MATCH" : L"DIFF")
               << L" | recorded=" << expected << L" live=" << actual << L"\n";
    if (!pass) ++failures;
  };
  registryCheck(L"machineguid", kMachineGuidKey, kMachineGuidValue, L"MachineGuid");
  registryCheck(L"hwprofile", kHwProfileKey, kHwProfileValue, L"HwProfileId");
  std::wcout << L"VERIFY END failures=" << failures << L"\n";
  return failures ? 1 : 0;
}

int RunSetValue(const char* name, const char* value) {
  if (!RequireElevated() || !name || !value) return 1;
  const std::wstring field = Widen(name);
  const std::array<const wchar_t*, 8> allowed = {L"SmBiosManufacturer", L"SmBiosSerial",
      L"BiosSerial", L"Uuid", L"DiskSerial", L"VolumeId", L"MachineGuid", L"HwProfileId"};
  bool known = std::any_of(allowed.begin(), allowed.end(), [&](const wchar_t* item) { return field == item; });
  if (field == L"Uuid" || field == L"MachineGuid" || field == L"HwProfileId") {
    GUID guid{};
    known = SUCCEEDED(CLSIDFromString(Widen(value).c_str(), &guid));
  }
  if (field == L"Mac") {
    const std::wstring mac = NormalizeMac(Widen(value));
    known = mac.size() == 12 && mac.find_first_not_of(L"0123456789abcdefABCDEF") == std::wstring::npos &&
            (wcstoul(mac.substr(0, 2).c_str(), nullptr, 16) & 1) == 0;
  }
  if (!known || std::string(value).size() > 63) {
    std::cerr << "[!] Unknown field or invalid value length/MAC format\n";
    return 1;
  }
  if (!WriteIdentityValue(field, Widen(value))) return 1;
  std::cout << "[+] Custom value saved for " << name << "\n";
  return 0;
}

int RunRegenerateValues() {
  if (!RequireElevated()) return 1;
  for (const wchar_t* name : {L"Seed", L"SmBiosManufacturer", L"SmBiosSerial", L"Uuid",
           L"BiosSerial", L"Mac", L"DiskSerial", L"VolumeId", L"MachineGuid", L"HwProfileId"}) {
    if (!DeleteValue(kStateKey, name)) return 1;
  }
  std::cout << "[+] Next spoof operation will generate a new identity set; backups are preserved\n";
  return 0;
}

}  // namespace hwid
