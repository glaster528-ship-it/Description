#include "registry_ops.h"

#include "util.h"

namespace hwid {

bool ReadSz(HKEY root, const wchar_t* subkey, const wchar_t* value, std::wstring* out) {
  DWORD type = 0;
  DWORD size = 0;
  LONG rc = RegGetValueW(root, subkey, value, RRF_RT_REG_SZ, &type, nullptr, &size);
  if (rc != ERROR_SUCCESS) {
    SetLastError(rc);
    return false;
  }
  std::wstring buffer(size / sizeof(wchar_t), L'\0');
  rc = RegGetValueW(root, subkey, value, RRF_RT_REG_SZ, &type, buffer.data(), &size);
  if (rc != ERROR_SUCCESS) {
    SetLastError(rc);
    return false;
  }
  while (!buffer.empty() && buffer.back() == L'\0') buffer.pop_back();
  *out = buffer;
  return true;
}

bool ReadQword(HKEY root, const wchar_t* subkey, const wchar_t* value,
               unsigned long long* out) {
  DWORD type = 0;
  DWORD size = sizeof(unsigned long long);
  unsigned long long tmp = 0;
  LONG rc = RegGetValueW(root, subkey, value, RRF_RT_REG_QWORD, &type, &tmp, &size);
  if (rc != ERROR_SUCCESS) {
    SetLastError(rc);
    return false;
  }
  *out = tmp;
  return true;
}

bool WriteSz(const wchar_t* subkey, const wchar_t* value, const std::wstring& data) {
  HKEY raw = nullptr;
  DWORD disposition = 0;
  LONG rc = RegCreateKeyExW(HKEY_LOCAL_MACHINE, subkey, 0, nullptr,
                            REG_OPTION_NON_VOLATILE, KEY_READ | KEY_WRITE, nullptr,
                            &raw, &disposition);
  if (rc != ERROR_SUCCESS) {
    SetLastError(rc);
    return false;
  }
  UniqueRegKey key(raw);
  rc = RegSetValueExW(key.get(), value, 0, REG_SZ,
                      reinterpret_cast<const BYTE*>(data.c_str()),
                      static_cast<DWORD>((data.size() + 1) * sizeof(wchar_t)));
  if (rc != ERROR_SUCCESS) {
    SetLastError(rc);
    return false;
  }
  return true;
}

bool WriteQword(const wchar_t* subkey, const wchar_t* value, unsigned long long data) {
  HKEY raw = nullptr;
  DWORD disposition = 0;
  LONG rc = RegCreateKeyExW(HKEY_LOCAL_MACHINE, subkey, 0, nullptr,
                            REG_OPTION_NON_VOLATILE, KEY_READ | KEY_WRITE, nullptr,
                            &raw, &disposition);
  if (rc != ERROR_SUCCESS) {
    SetLastError(rc);
    return false;
  }
  UniqueRegKey key(raw);
  rc = RegSetValueExW(key.get(), value, 0, REG_QWORD,
                      reinterpret_cast<const BYTE*>(&data), sizeof(data));
  if (rc != ERROR_SUCCESS) {
    SetLastError(rc);
    return false;
  }
  return true;
}

bool DeleteValue(const wchar_t* subkey, const wchar_t* valueName) {
  HKEY raw = nullptr;
  LONG rc = RegOpenKeyExW(HKEY_LOCAL_MACHINE, subkey, 0, KEY_READ | KEY_SET_VALUE, &raw);
  if (rc == ERROR_FILE_NOT_FOUND) return true;
  if (rc != ERROR_SUCCESS) {
    SetLastError(rc);
    return false;
  }
  UniqueRegKey key(raw);
  rc = RegDeleteValueW(key.get(), valueName);
  if (rc == ERROR_SUCCESS || rc == ERROR_FILE_NOT_FOUND) return true;
  SetLastError(rc);
  return false;
}

bool BackupString(const wchar_t* srcSubKey, const wchar_t* valueName,
                  const wchar_t* backupName) {
  if (!backupName) backupName = valueName;
  const std::wstring existedName = std::wstring(backupName) + L".Existed";
  unsigned long long already = 0;
  if (ReadQword(HKEY_LOCAL_MACHINE, kBackupKey, existedName.c_str(), &already)) {
    return true;  // original already stored, keep it
  }

  std::wstring current;
  if (!ReadSz(HKEY_LOCAL_MACHINE, srcSubKey, valueName, &current)) {
    if (GetLastError() != ERROR_FILE_NOT_FOUND) return false;
    return WriteQword(kBackupKey, existedName.c_str(), 0);
  }
  if (!WriteSz(kBackupKey, backupName, current)) return false;
  return WriteQword(kBackupKey, existedName.c_str(), 1);
}

RestoreResult RestoreString(const wchar_t* dstSubKey, const wchar_t* valueName,
                            const wchar_t* backupName) {
  if (!backupName) backupName = valueName;
  const std::wstring existedName = std::wstring(backupName) + L".Existed";
  unsigned long long existed = 0;
  if (!ReadQword(HKEY_LOCAL_MACHINE, kBackupKey, existedName.c_str(), &existed)) {
    return RestoreResult::NoBackup;
  }
  if (existed != 0) {
    std::wstring original;
    if (!ReadSz(HKEY_LOCAL_MACHINE, kBackupKey, backupName, &original)) {
      return RestoreResult::Error;
    }
    if (!WriteSz(dstSubKey, valueName, original)) return RestoreResult::Error;
  } else if (!DeleteValue(dstSubKey, valueName)) {
    return RestoreResult::Error;
  }
  DeleteValue(kBackupKey, existedName.c_str());
  DeleteValue(kBackupKey, backupName);
  return RestoreResult::Restored;
}

}  // namespace hwid
