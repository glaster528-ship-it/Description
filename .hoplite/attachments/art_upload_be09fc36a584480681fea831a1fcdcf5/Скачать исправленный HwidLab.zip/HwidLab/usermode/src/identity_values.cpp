#include "identity_values.h"

#include "registry_ops.h"

#include <windows.h>

#include <algorithm>
#include <cctype>

namespace hwid {

bool ReadIdentityValue(const std::wstring& name, std::wstring* value) {
  return ReadSz(HKEY_LOCAL_MACHINE, kStateKey, (L"Custom." + name).c_str(), value);
}

bool WriteIdentityValue(const std::wstring& name, const std::wstring& value) {
  return WriteSz(kStateKey, (L"Custom." + name).c_str(), value);
}

bool DeleteIdentityValue(const std::wstring& name) {
  return DeleteValue(kStateKey, (L"Custom." + name).c_str());
}

std::wstring NormalizeMac(const std::wstring& value) {
  std::wstring result;
  for (wchar_t c : value) if (c != L':' && c != L'-' && !iswspace(c)) result += c;
  return result;
}

}  // namespace hwid
