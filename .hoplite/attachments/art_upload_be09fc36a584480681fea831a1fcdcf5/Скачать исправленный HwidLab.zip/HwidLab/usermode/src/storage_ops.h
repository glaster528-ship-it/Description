#pragma once

#include <string>

namespace hwid {

int RunStorageList();
void SelectStorageDevice(const std::wstring& deviceName);
void PrintStorageStatus();

}  // namespace hwid
