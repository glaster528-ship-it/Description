#include "spoof.h"

#include "device_io.h"
#include "network_ops.h"
#include "identity_values.h"
#include "session_ops.h"
#include "storage_ops.h"
#include "registry_ops.h"
#include "util.h"

#include <windows.h>

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <initializer_list>
#include <iostream>
#include <random>
#include <string>
#include <utility>

namespace hwid {
namespace {

constexpr char kAlnum[] = "0123456789ABCDEFGHJKLMNPQRSTUVWXYZ";

std::string RandomString(std::mt19937_64& rng, size_t length) {
  std::uniform_int_distribution<size_t> dist(0, sizeof(kAlnum) - 2);
  std::string out;
  out.reserve(length);
  for (size_t i = 0; i < length; ++i) out += kAlnum[dist(rng)];
  return out;
}

std::string FormatGuid(uint32_t a, uint16_t b, uint16_t c, const uint8_t* d) {
  char buf[40] = {};
  std::snprintf(buf, sizeof(buf), "%08x-%04x-%04x-%02x%02x-%02x%02x%02x%02x%02x%02x", a,
                b, c, d[0], d[1], d[2], d[3], d[4], d[5], d[6], d[7]);
  return buf;
}

std::string RandomGuidString(std::mt19937_64& rng) {
  std::uniform_int_distribution<unsigned> byteDist(0, 255);
  uint8_t raw[16];
  for (uint8_t& byte : raw) byte = static_cast<uint8_t>(byteDist(rng));
  raw[6] = static_cast<uint8_t>((raw[6] & 0x0F) | 0x40);  // UUID v4
  raw[8] = static_cast<uint8_t>((raw[8] & 0x3F) | 0x80);  // RFC 4122 variant
  const uint32_t a = (static_cast<uint32_t>(raw[0]) << 24) |
                     (static_cast<uint32_t>(raw[1]) << 16) |
                     (static_cast<uint32_t>(raw[2]) << 8) | raw[3];
  const uint16_t b = static_cast<uint16_t>((static_cast<uint16_t>(raw[4]) << 8) | raw[5]);
  const uint16_t c = static_cast<uint16_t>((static_cast<uint16_t>(raw[6]) << 8) | raw[7]);
  return FormatGuid(a, b, c, raw + 8);
}

std::string FormatMac(const uint8_t mac[6]) {
  char buf[20] = {};
  std::snprintf(buf, sizeof(buf), "%02X:%02X:%02X:%02X:%02X:%02X", mac[0], mac[1],
                mac[2], mac[3], mac[4], mac[5]);
  return buf;
}

struct SpoofValues {
  uint64_t seed = 0;
  std::string smbiosManufacturer;
  std::string smbiosSerial;
  std::string uuid;
  uint8_t uuidBytes[16] = {};
  std::string biosSerial;
  uint8_t mac[6] = {};
  std::string macText;
  std::string diskSerial;
  std::string volumeId;
  std::string machineGuid;
  std::string hwProfileId;
};

SpoofValues GenerateValues(uint64_t seed) {
  std::mt19937_64 rng(seed);
  SpoofValues v;
  v.seed = seed;
  v.smbiosManufacturer = "HWLAB-" + RandomString(rng, 4);
  v.smbiosSerial = RandomString(rng, 12);
  v.biosSerial = "BIOS-" + RandomString(rng, 8);

  std::uniform_int_distribution<unsigned> byteDist(0, 255);
  for (int i = 0; i < 16; ++i) v.uuidBytes[i] = static_cast<uint8_t>(byteDist(rng));
  v.uuidBytes[6] = static_cast<uint8_t>((v.uuidBytes[6] & 0x0F) | 0x40);
  v.uuidBytes[8] = static_cast<uint8_t>((v.uuidBytes[8] & 0x3F) | 0x80);
  {
    const uint32_t a = (static_cast<uint32_t>(v.uuidBytes[0]) << 24) |
                       (static_cast<uint32_t>(v.uuidBytes[1]) << 16) |
                       (static_cast<uint32_t>(v.uuidBytes[2]) << 8) | v.uuidBytes[3];
    const uint16_t b = static_cast<uint16_t>((static_cast<uint16_t>(v.uuidBytes[4]) << 8) |
                                             v.uuidBytes[5]);
    const uint16_t c = static_cast<uint16_t>((static_cast<uint16_t>(v.uuidBytes[6]) << 8) |
                                             v.uuidBytes[7]);
    v.uuid = FormatGuid(a, b, c, v.uuidBytes + 8);
  }

  // Microsoft/Hyper-V OUI, unicast; randomize the three NIC-specific bytes.
  v.mac[0] = 0x00;
  v.mac[1] = 0x15;
  v.mac[2] = 0x5D;
  for (int i = 3; i < 6; ++i) v.mac[i] = static_cast<uint8_t>(byteDist(rng));
  v.macText = FormatMac(v.mac);

  v.diskSerial = RandomString(rng, 20);

  std::uniform_int_distribution<uint32_t> wordDist(0, 0xFFFFFFFFu);
  const uint32_t volume = wordDist(rng);
  char volumeBuf[16] = {};
  std::snprintf(volumeBuf, sizeof(volumeBuf), "%04X-%04X", volume >> 16, volume & 0xFFFFu);
  v.volumeId = volumeBuf;

  v.machineGuid = RandomGuidString(rng);
  v.hwProfileId = RandomGuidString(rng);
  auto custom = [&](const wchar_t* name, std::string* destination) {
    std::wstring value;
    if (ReadIdentityValue(name, &value) && !value.empty()) *destination = Narrow(value);
  };
  custom(L"SmBiosManufacturer", &v.smbiosManufacturer);
  custom(L"SmBiosSerial", &v.smbiosSerial);
  custom(L"BiosSerial", &v.biosSerial);
  custom(L"Uuid", &v.uuid);
  custom(L"DiskSerial", &v.diskSerial);
  custom(L"VolumeId", &v.volumeId);
  custom(L"MachineGuid", &v.machineGuid);
  custom(L"HwProfileId", &v.hwProfileId);
  if (v.uuid.size() == 36) {
    const size_t offsets[16] = {0, 2, 4, 6, 9, 11, 14, 16, 19, 21, 24, 26, 28, 30, 32, 34};
    bool valid = true;
    uint8_t bytes[16]{};
    for (size_t i = 0; i < 16 && valid; ++i) {
      const std::string pair = v.uuid.substr(offsets[i], 2);
      if (!std::all_of(pair.begin(), pair.end(), [](char c) { return std::isxdigit(static_cast<unsigned char>(c)) != 0; })) {
        valid = false;
        break;
      }
      bytes[i] = static_cast<uint8_t>(std::stoul(pair, nullptr, 16));
    }
    if (valid) std::copy(std::begin(bytes), std::end(bytes), v.uuidBytes);
  }
  std::wstring customMac;
  if (ReadIdentityValue(L"Mac", &customMac)) {
    customMac = NormalizeMac(customMac);
    if (customMac.size() == 12) {
      for (size_t i = 0; i < 6; ++i) {
        wchar_t pair[3] = {customMac[i * 2], customMac[i * 2 + 1], 0};
        v.mac[i] = static_cast<uint8_t>(wcstoul(pair, nullptr, 16));
      }
      v.macText = FormatMac(v.mac);
    }
  }
  return v;
}

uint64_t MakeSeed() {
  std::random_device rd;
  return (static_cast<uint64_t>(rd()) << 32) ^ static_cast<uint64_t>(rd()) ^
         (GetTickCount64() * 1099511628211ULL);
}

// Seed is stored on first use so repeat spoof runs regenerate the same values.
uint64_t LoadOrCreateSeed() {
  unsigned long long stored = 0;
  if (ReadQword(HKEY_LOCAL_MACHINE, kStateKey, L"Seed", &stored)) return stored;
  const uint64_t seed = MakeSeed();
  WriteQword(kStateKey, L"Seed", seed);
  return seed;
}

void PutFixed(char* dst, size_t cap, const std::string& src) {
  const size_t n = std::min(src.size(), cap - 1);
  std::memcpy(dst, src.data(), n);
  dst[n] = '\0';
}

bool ApplyDriverFlags(unsigned long flags, const SpoofValues& values) {
  HwidConfig config{};
  config.Magic = HWID_CONFIG_MAGIC;
  config.Version = HWID_CONFIG_VERSION;
  config.StructSize = sizeof(config);
  config.Flags = static_cast<UINT32>(flags);
  PutFixed(config.SmBiosManufacturer, sizeof(config.SmBiosManufacturer),
           values.smbiosManufacturer);
  PutFixed(config.SmBiosSerial, sizeof(config.SmBiosSerial), values.smbiosSerial);
  std::memcpy(config.SmBiosUuid, values.uuidBytes, sizeof(config.SmBiosUuid));
  PutFixed(config.BiosSerial, sizeof(config.BiosSerial), values.biosSerial);
  std::memcpy(config.MacAddress, values.mac, sizeof(config.MacAddress));
  PutFixed(config.DiskSerial, sizeof(config.DiskSerial), values.diskSerial);
  PutFixed(config.VolumeId, sizeof(config.VolumeId), values.volumeId);
  std::wstring selected;
  ReadIdentityValue(L"StorageDevice", &selected);
  wcsncpy_s(config.DeviceName, selected.c_str(), _TRUNCATE);

  UniqueWinHandle device;
  if (!OpenHwidDevice(device)) {
    std::cerr << "[!] Cannot open " << Narrow(HWID_DEVICE_DOS_NAME)
              << " (is the HwidLab driver started? try: HwidLoader.exe start)\n";
    return false;
  }
  if (!SendSetConfig(device.get(), config)) {
    ReportWinError("DeviceIoControl(IOCTL_HWID_SET_CONFIG)");
    return false;
  }
  return true;
}

bool SpoofRegistryValue(const wchar_t* subkey, const wchar_t* value,
                        const std::wstring& newValue) {
  if (!BackupString(subkey, value)) {
    ReportWinError("backup current value");
    return false;
  }
  if (!WriteSz(subkey, value, newValue)) {
    ReportWinError("write new value");
    return false;
  }
  return true;
}

void PersistState(const SpoofValues& values) {
  WriteSz(kStateKey, L"SmBiosManufacturer", Widen(values.smbiosManufacturer));
  WriteSz(kStateKey, L"SmBiosSerial", Widen(values.smbiosSerial));
  WriteSz(kStateKey, L"Uuid", Widen(values.uuid));
  WriteSz(kStateKey, L"BiosSerial", Widen(values.biosSerial));
  WriteSz(kStateKey, L"Mac", Widen(values.macText));
  WriteSz(kStateKey, L"DiskSerial", Widen(values.diskSerial));
  WriteSz(kStateKey, L"VolumeId", Widen(values.volumeId));
  WriteSz(kStateKey, L"MachineGuid", Widen(values.machineGuid));
  WriteSz(kStateKey, L"HwProfileId", Widen(values.hwProfileId));
}

void PrintValues(const SpoofValues& values) {
  std::cout << "[+] Spoofed values (seed 0x" << std::hex << values.seed << std::dec
            << "):\n";
  std::cout << "  SmBiosManufacturer : " << values.smbiosManufacturer << "\n";
  std::cout << "  SmBiosSerial       : " << values.smbiosSerial << "\n";
  std::cout << "  SmBiosUuid         : " << values.uuid << "\n";
  std::cout << "  BiosSerial         : " << values.biosSerial << "\n";
  std::cout << "  Mac                : " << values.macText << "\n";
  std::cout << "  DiskSerial         : " << values.diskSerial << "\n";
  std::cout << "  VolumeId           : " << values.volumeId << "\n";
  std::cout << "  MachineGuid        : " << values.machineGuid << "\n";
  std::cout << "  HwProfileId        : " << values.hwProfileId << "\n";
}

const char* ServiceStateText(DWORD state) {
  switch (state) {
    case SERVICE_STOPPED: return "STOPPED";
    case SERVICE_START_PENDING: return "START_PENDING";
    case SERVICE_STOP_PENDING: return "STOP_PENDING";
    case SERVICE_RUNNING: return "RUNNING";
    case SERVICE_CONTINUE_PENDING: return "CONTINUE_PENDING";
    case SERVICE_PAUSE_PENDING: return "PAUSE_PENDING";
    case SERVICE_PAUSED: return "PAUSED";
    default: return "UNKNOWN";
  }
}

}  // namespace

bool ParseSpoofTarget(const std::string& name, SpoofTarget* out) {
  std::string upper;
  upper.reserve(name.size());
  for (char c : name) upper += static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
  if (upper == "ALL") { *out = SpoofTarget::All; return true; }
  if (upper == "DISK") { *out = SpoofTarget::Disk; return true; }
  if (upper == "SMBIOS") { *out = SpoofTarget::SmBios; return true; }
  if (upper == "MAC") { *out = SpoofTarget::Mac; return true; }
  if (upper == "VOLUME") { *out = SpoofTarget::Volume; return true; }
  if (upper == "MACHINEGUID") { *out = SpoofTarget::MachineGuid; return true; }
  if (upper == "HWPROFILE") { *out = SpoofTarget::HwProfile; return true; }
  if (upper == "NETMAC") { *out = SpoofTarget::NetworkMac; return true; }
  if (upper == "NETGUID") { *out = SpoofTarget::NetworkGuid; return true; }
  return false;
}

int RunSpoof(SpoofTarget target) {
  if (!RequireElevated()) return 1;

  bool wantDriver = false;
  bool wantMachineGuid = false;
  bool wantHwProfile = false;
  bool wantNetworkMac = false;
  bool wantNetworkGuid = false;
  unsigned long driverFlags = HWID_SPOOF_NONE;
  switch (target) {
    case SpoofTarget::All:
      wantDriver = wantMachineGuid = wantHwProfile = true;
      driverFlags = HWID_SPOOF_ALL_DRIVER;
      break;
    case SpoofTarget::Disk:
      wantDriver = true;
      driverFlags = HWID_SPOOF_DISK;
      break;
    case SpoofTarget::SmBios:
      wantDriver = true;
      driverFlags = HWID_SPOOF_SMBIOS;
      break;
    case SpoofTarget::Mac:
      wantDriver = true;
      driverFlags = HWID_SPOOF_MAC;
      break;
    case SpoofTarget::Volume:
      wantDriver = true;
      driverFlags = HWID_SPOOF_VOLUME;
      break;
    case SpoofTarget::MachineGuid:
      wantMachineGuid = true;
      break;
    case SpoofTarget::HwProfile:
      wantHwProfile = true;
      break;
    case SpoofTarget::NetworkMac:
      wantNetworkMac = true;
      break;
    case SpoofTarget::NetworkGuid:
      wantNetworkGuid = true;
      break;
  }

  const SpoofValues values = GenerateValues(LoadOrCreateSeed());

  std::wstring previousDriver;
  if (wantDriver) {
    UniqueWinHandle device;
    HwidConfig previous{};
    if (OpenHwidDevice(device) && GetHwidConfig(device.get(), &previous))
      previousDriver.assign(reinterpret_cast<const wchar_t*>(&previous), sizeof(previous) / sizeof(wchar_t));
    if (previousDriver.empty()) {
      std::cerr << "[!] Cannot snapshot the current driver configuration; update/start the ABI v2 driver first\n";
      return 1;
    }
  }

  bool ok = true;
  if (wantDriver && !ApplyDriverFlags(driverFlags, values)) ok = false;
  if (wantMachineGuid &&
      !SpoofRegistryValue(kMachineGuidKey, kMachineGuidValue, Widen(values.machineGuid))) {
    ok = false;
  }
  if (wantHwProfile &&
      !SpoofRegistryValue(kHwProfileKey, kHwProfileValue, Widen(values.hwProfileId))) {
    ok = false;
  }
  if (wantNetworkMac && RunNetworkSpoof(NetworkTarget::Mac) != 0) ok = false;
  if (wantNetworkGuid && RunNetworkSpoof(NetworkTarget::InstanceGuid) != 0) ok = false;

  if (!ok) {
    std::cerr << "[!] One or more operations failed; state was not recorded\n";
    return 1;
  }

  PersistState(values);
  RecordSession(Narrow(std::wstring(wantNetworkMac ? L"NETMAC" : wantNetworkGuid ? L"NETGUID" : L"IDENTITY")).c_str(),
                wantDriver, wantMachineGuid, wantHwProfile, previousDriver);
  PrintValues(values);
  std::cout << "[i] Registry changes take effect after reboot\n";
  return 0;
}

int RunShow() {
  UniqueSvcHandle scm(OpenSCManagerW(nullptr, nullptr, SC_MANAGER_CONNECT));
  if (!scm.valid()) {
    ReportWinError("OpenSCManagerW");
  } else {
    UniqueSvcHandle service(
        OpenServiceW(scm.get(), HWID_SERVICE_NAME, SERVICE_QUERY_STATUS));
    if (!service.valid()) {
      std::cout << "service : " << Narrow(HWID_SERVICE_NAME) << " not installed\n";
    } else {
      SERVICE_STATUS status{};
      if (QueryServiceStatus(service.get(), &status)) {
        std::cout << "service : " << Narrow(HWID_SERVICE_NAME) << " "
                  << ServiceStateText(status.dwCurrentState) << "\n";
      } else {
        ReportWinError("QueryServiceStatus");
      }
    }
  }

  std::cout << "\nspoof state (" << Narrow(kStateKey) << "):\n";
  bool anyState = false;
  unsigned long long seed = 0;
  if (ReadQword(HKEY_LOCAL_MACHINE, kStateKey, L"Seed", &seed)) {
    std::cout << "  seed    : 0x" << std::hex << seed << std::dec << "\n";
    anyState = true;
  }
  const std::pair<const char*, const wchar_t*> entries[] = {
      {"manufacturer", L"SmBiosManufacturer"}, {"smbios serial", L"SmBiosSerial"},
      {"uuid", L"Uuid"},         {"bios serial", L"BiosSerial"},
      {"mac", L"Mac"},           {"disk serial", L"DiskSerial"},
      {"volume id", L"VolumeId"}, {"machineguid", L"MachineGuid"},
      {"hwprofileid", L"HwProfileId"}};
  for (const auto& entry : entries) {
    std::wstring value;
    if (ReadSz(HKEY_LOCAL_MACHINE, kStateKey, entry.second, &value)) {
      std::cout << "  " << entry.first << " : " << Narrow(value) << "\n";
      anyState = true;
    }
  }
  if (!anyState) std::cout << "  (no spoof recorded)\n";

  std::wstring live;
  if (ReadSz(HKEY_LOCAL_MACHINE, kMachineGuidKey, kMachineGuidValue, &live)) {
    std::cout << "\nlive MachineGuid : " << Narrow(live) << "\n";
  }

  std::cout << "\nbackups (" << Narrow(kBackupKey) << "):\n";
  bool anyBackup = false;
  for (const wchar_t* name : {kMachineGuidValue, kHwProfileValue}) {
    std::wstring value;
    if (ReadSz(HKEY_LOCAL_MACHINE, kBackupKey, name, &value)) {
      std::cout << "  " << Narrow(name) << " : " << Narrow(value) << "\n";
      anyBackup = true;
    }
  }
  if (!anyBackup) std::cout << "  (none)\n";
  PrintNetworkStatus();
  PrintStorageStatus();
  return 0;
}

int RunRestore() {
  if (!RequireElevated()) return 1;

  int rc = 0;
  bool restoredAny = false;

  const RestoreResult guidResult =
      RestoreString(kMachineGuidKey, kMachineGuidValue);
  if (guidResult == RestoreResult::Restored) {
    std::cout << "[+] Restored MachineGuid\n";
    restoredAny = true;
  } else if (guidResult == RestoreResult::Error) {
    ReportWinError("restore MachineGuid");
    rc = 1;
  }

  const RestoreResult profileResult = RestoreString(kHwProfileKey, kHwProfileValue);
  if (profileResult == RestoreResult::Restored) {
    std::cout << "[+] Restored HardwareProfileId\n";
    restoredAny = true;
  } else if (profileResult == RestoreResult::Error) {
    ReportWinError("restore HardwareProfileId");
    rc = 1;
  }
  if (RunNetworkRestore() != 0) rc = 1;

  UniqueWinHandle device;
  if (OpenHwidDevice(device)) {
    if (SendRestore(device.get())) {
      std::cout << "[+] Driver restore requested\n";
      restoredAny = true;
    } else {
      ReportWinError("DeviceIoControl(IOCTL_HWID_RESTORE)");
      rc = 1;
    }
  } else {
    std::cerr << "[i] Driver device not available; driver-level spoof state is managed by the driver\n";
  }

  if (restoredAny) {
    for (const wchar_t* name : {L"Seed", L"SmBiosManufacturer", L"SmBiosSerial",
                                L"Uuid", L"BiosSerial", L"Mac", L"DiskSerial",
                                L"VolumeId", L"MachineGuid", L"HwProfileId"}) {
      DeleteValue(kStateKey, name);
    }
    ClearNetworkState();
    std::cout << "[i] Recorded spoof state cleared\n";
  } else if (rc == 0) {
    std::cerr << "[i] Nothing to restore (no backups found)\n";
  }
  return rc;
}

}  // namespace hwid
