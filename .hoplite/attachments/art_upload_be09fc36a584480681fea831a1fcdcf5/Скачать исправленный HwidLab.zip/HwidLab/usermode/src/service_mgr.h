#pragma once

#include <string>

namespace hwid {

int RunInstall(const std::wstring& sysPath);
int RunStart();
int RunStop();
int RunUninstall();

}  // namespace hwid
