#pragma once

#include <windows.h>

#include <string>

namespace hwid {

enum class NetworkTarget { Mac, InstanceGuid };

int RunNetworkSpoof(NetworkTarget target, const std::wstring& adapterId = L"");
int RunNetworkRestore();
int RunNetworkRestore(NetworkTarget target, const std::wstring& adapterId);
void PrintNetworkStatus();
void ClearNetworkState();

}  // namespace hwid
