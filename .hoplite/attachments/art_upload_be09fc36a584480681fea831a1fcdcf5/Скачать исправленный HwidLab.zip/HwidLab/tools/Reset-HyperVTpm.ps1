[CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'High')]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$VMName
)

$ErrorActionPreference = 'Stop'
Import-Module Hyper-V -ErrorAction Stop

$vm = @(Get-VM -Name $VMName -ErrorAction Stop)
if ($vm.Count -ne 1) {
    throw "Expected exactly one Hyper-V VM named '$VMName'."
}
$vm = $vm[0]
if ($vm.State -ne 'Off') {
    throw "VM '$VMName' must be shut down. Current state: $($vm.State). Save BitLocker recovery keys before changing vTPM state."
}

$checkpointName = 'HwidLab before vTPM reset ' + (Get-Date -Format 'yyyy-MM-dd HH-mm-ss')
Write-Host "Creating checkpoint: $checkpointName"
Checkpoint-VM -VM $vm -SnapshotName $checkpointName -ErrorAction Stop

$wasEnabled = (Get-VMSecurity -VM $vm).TpmEnabled
try {
    if ($wasEnabled) {
        Disable-VMTPM -VM $vm -Confirm:$false -ErrorAction Stop
    }
    Set-VMKeyProtector -VM $vm -NewLocalKeyProtector -ErrorAction Stop
    if ($wasEnabled) {
        Enable-VMTPM -VM $vm -Confirm:$false -ErrorAction Stop
    }
} catch {
    Write-Error "vTPM rotation failed. VM '$VMName' is still off; checkpoint '$checkpointName' is available. $_"
    exit 1
}

Write-Host "Rotated vTPM key protector for '$VMName'. The VM remains off."
Write-Host "vTPM is not a physical TPM emulator; guest measured-boot and disk-encryption state must be validated in your test lab."
